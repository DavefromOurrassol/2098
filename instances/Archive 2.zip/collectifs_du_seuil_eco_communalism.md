---
name: Les Veilleurs du Seuil
type: instance
slug: collectifs_du_seuil_eco_communalism
entite: collectifs_du_seuil
scenario: eco_communalism
statut: officialise_enrichi
localisation:
  zone: cevennes_interieure
  lieu: Cévennes Intérieure et plateaux du Massif Central
  type_lieu: region
type_dans_scenario: réseau

role_dans_scenario: >
  Dans un monde éco-communaliste où la fragmentation est déjà advenue, les Veilleurs du Seuil occupent une position paradoxale : ils annonçaient l'effondrement, et l'effondrement est en partie arrivé — sans toutefois ressembler à leur prophétie. Présents dans les interstices des communautés autonomes, ils fonctionnent comme un réseau de communes ritualisées qui interprètent la régénération écologique en cours non pas comme une victoire, mais comme le signe avant-coureur d'un effondrement plus profond, encore à venir. Leur rôle systémique est ambigu : tantôt catalyseurs de résilience locale, tantôt facteurs de résistance aux dynamiques de reconstruction collective.

responsabilites: >
  Les Veilleurs organisent des enclaves de préparation au 'Second Seuil', stockant des semences, des savoirs techniques et des archives rituelles dans des structures semi-enterrées appelées 'Sillons'. Ils maintiennent des circuits d'échange parallèles entre communautés rurales isolées, refusant toute intégration dans les réseaux de coopération inter-communautaires officiels. Ils pratiquent une forme d'écologie radicale fondée sur le retrait intentionnel : réduire l'empreinte jusqu'à l'invisibilité systémique.

impact_local: 3
impact_systemique_global: 1
variables_influencees:
    - valeurs_culture_tempo_sociale
    - organisation_territoires
    - demographie_mobilite_humaine

zone_geographique:
    - locale
    - régionale

zone_systemique:
    - société
    - gouvernance
    - énergie

alliances:
- communautes_rurales_dissidentes_anti_cooperation_regionale_eco_communalism
- cooperatives_semencieres_et_d_archives_agronomiques_eco_communalism
- fraternites_ecospiritualistes_des_anciens_survivalistes_eco_communalism
- oracle_des_seuils_eco_communalism
- universite_nomade_eco_communalism
- zones_extractivistes_corridors_eco_communalism
oppositions:
- conseils_de_bassin_versant_eco_communalistes_eco_communalism
- directive_kontinuum_eco_communalism
- mouvement_des_archives_vivantes_du_savoir_partage_eco_communalism
- reseaux_de_reconstruction_cooperative_inter_communautes_eco_communalism
type_relation_dominante: rivalité

annee_debut: 2031
annee_fin: 

etat_temporel: actif
age_historique: marginal
generation: post-effondrement

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  On les trouve aux lisières — là où les chemins forestiers cessent d'être entretenus et où les panneaux de coopération régionale n'ont jamais été plantés. Les Veilleurs du Seuil sont ces communautés qui ont eu raison trop tôt, et qui ne s'en sont jamais remises. Dans les vallées de la Cévenne intérieure ou les plateaux désertés du Massif Central, leurs Sillons — ces longues bâtisses mi-enterrées tapissées de graines et de schémas techniques — ressemblent moins à des refuges qu'à des tombeaux anticipatoires. Ils ne contestent pas la renaissance éco-communaliste : ils la jugent insuffisante, provisoire, aveugle à la vague suivante. 'Vous reconstruisez sur le bord du gouffre', répètent leurs Porteurs de mémoire lors des rares échanges avec les délégués des bassins versants. En 2098, ils sont à la fois une énigme et un reproche vivant pour les bâtisseurs du monde nouveau.

signes_distinctifs: >
  Vêtements uniformément ternis aux tons de terre et de cendre, marqués d'un liseré noir à l'ourlet signifiant 'le bord'. Les Sillons sont reconnaissables à leurs toits végétalisés arasés au niveau du sol, quasi invisibles depuis les sentiers. Leur signe de reconnaissance est un geste de la main — la paume ouverte retournée vers le bas, 'ce qui tombe'.

tensions_narratives: >
  La tension centrale est théologique autant que politique : si la régénération éco-communaliste réussit, les Veilleurs sont condamnés à l'insignifiance — prophètes d'une apocalypse qui n'a pas eu lieu. Mais si le système fragile des communautés autonomes se disloque face à une nouvelle crise climatique ou conflictuelle, leur crédibilité explose et leur réseau de Sillons devient soudainement stratégique. Une deuxième ligne de tension concerne les jeunes générations nées dans les communautés éco-communalistes : certains, déçus par la lenteur de la reconstruction, sont attirés par la radicalité du retrait des Veilleurs. Enfin, la question des archives : les Sillons contiennent des savoirs techniques précieux que les réseaux coopératifs voudraient intégrer — mais à quel prix, et selon quelles conditions d'accès ?

date_creation: 2026-06-15
---

# Les Veilleurs du Seuil

## Rôle dans [[eco_communalism]]
Dans un monde éco-communaliste où la fragmentation est déjà advenue, les Veilleurs du Seuil occupent une position paradoxale : ils annonçaient l'effondrement, et l'effondrement est en partie arrivé — sans toutefois ressembler à leur prophétie. Présents dans les interstices des communautés autonomes, ils fonctionnent comme un réseau de communes ritualisées qui interprètent la régénération écologique en cours non pas comme une victoire, mais comme le signe avant-coureur d'un effondrement plus profond, encore à venir. Leur rôle systémique est ambigu : tantôt catalyseurs de résilience locale, tantôt facteurs de résistance aux dynamiques de reconstruction collective.

## Responsabilités
Les Veilleurs organisent des enclaves de préparation au 'Second Seuil', stockant des semences, des savoirs techniques et des archives rituelles dans des structures semi-enterrées appelées 'Sillons'. Ils maintiennent des circuits d'échange parallèles entre communautés rurales isolées, refusant toute intégration dans les réseaux de coopération inter-communautaires officiels. Ils pratiquent une forme d'écologie radicale fondée sur le retrait intentionnel : réduire l'empreinte jusqu'à l'invisibilité systémique.

## Variables influencées
- [[valeurs_culture_tempo_sociale]]
- [[organisation_territoires]]
- [[demographie_mobilite_humaine]]


## Description journalistique
On les trouve aux lisières — là où les chemins forestiers cessent d'être entretenus et où les panneaux de coopération régionale n'ont jamais été plantés. Les Veilleurs du Seuil sont ces communautés qui ont eu raison trop tôt, et qui ne s'en sont jamais remises. Dans les vallées de la Cévenne intérieure ou les plateaux désertés du Massif Central, leurs Sillons — ces longues bâtisses mi-enterrées tapissées de graines et de schémas techniques — ressemblent moins à des refuges qu'à des tombeaux anticipatoires. Ils ne contestent pas la renaissance éco-communaliste : ils la jugent insuffisante, provisoire, aveugle à la vague suivante. 'Vous reconstruisez sur le bord du gouffre', répètent leurs Porteurs de mémoire lors des rares échanges avec les délégués des bassins versants. En 2098, ils sont à la fois une énigme et un reproche vivant pour les bâtisseurs du monde nouveau.

## Tensions narratives
La tension centrale est théologique autant que politique : si la régénération éco-communaliste réussit, les Veilleurs sont condamnés à l'insignifiance — prophètes d'une apocalypse qui n'a pas eu lieu. Mais si le système fragile des communautés autonomes se disloque face à une nouvelle crise climatique ou conflictuelle, leur crédibilité explose et leur réseau de Sillons devient soudainement stratégique. Une deuxième ligne de tension concerne les jeunes générations nées dans les communautés éco-communalistes : certains, déçus par la lenteur de la reconstruction, sont attirés par la radicalité du retrait des Veilleurs. Enfin, la question des archives : les Sillons contiennent des savoirs techniques précieux que les réseaux coopératifs voudraient intégrer — mais à quel prix, et selon quelles conditions d'accès ?

## Relations
**Alliés :**
- [[communautes_rurales_dissidentes_anti_cooperation_regionale_eco_communalism]]
- [[cooperatives_semencieres_et_d_archives_agronomiques_eco_communalism]]
- [[fraternites_ecospiritualistes_des_anciens_survivalistes_eco_communalism]]
- [[oracle_des_seuils_eco_communalism]]
- [[universite_nomade_eco_communalism]]
- [[zones_extractivistes_corridors_eco_communalism]]
**Opposants :**
- [[conseils_de_bassin_versant_eco_communalistes_eco_communalism]]
- [[directive_kontinuum_eco_communalism]]
- [[mouvement_des_archives_vivantes_du_savoir_partage_eco_communalism]]
- [[reseaux_de_reconstruction_cooperative_inter_communautes_eco_communalism]]
