---
name: Arctic Passage Authority — Administration du Passage du Nord-Ouest
type: instance
slug: arctic_passage_authority_policy_reform
entite: arctic_passage_authority
scenario: policy_reform
statut: officialise_enrichi
localisation:
  zone: iqaluit_apa
  lieu: Iqaluit
  type_lieu: ville

type_dans_scenario: institution

role_dans_scenario: >
  Autorité intergouvernementale co-administrée par le Groenland, le Canada et les peuples Inuit, l'APA gère le Passage du Nord-Ouest devenu la route commerciale la plus fréquentée de l'hémisphère nord depuis la disparition de la banquise estivale. Dans le scénario policy_reform, elle incarne le modèle de gouvernance multi-niveaux à son stade le plus mature et le plus tendu : une institution pleinement opérationnelle, reconnue internationalement, mais traversée par des contradictions profondes entre sa légitimité autochtone affichée et les logiques de flux commerciaux qu'elle administre. Rivale directe de la NAT sur les corridors arctiques occidentaux, elle est à la fois vitrine du modèle technocratique de co-gouvernance et terrain d'une lutte sourde entre souveraineté inuit réelle et instrumentalisation institutionnelle. Son siège à Iqaluit et sa station avancée à Thulé-Reconvertie en font une présence physique et symbolique sur le territoire qu'elle prétend cogérer.

responsabilites: >
  L'APA régule le transit commercial, militaire et scientifique sur le Passage du Nord-Ouest via un système de permis, de péages environnementaux et de protocoles d'impact territorial négociés avec les communautés inuit. Elle administre les infrastructures portuaires, les corridors de sécurité maritime et les standards environnementaux applicables aux opérateurs privés et étatiques transitant par l'Arctique occidental. Elle est également chargée de la redistribution d'une fraction des redevances de transit aux fonds de développement des territoires inuit, clause centrale de son mandat de co-gouvernance.

impact_local: 5
impact_systemique_global: 4

variables_influencees:
    - geopolitique_conflits
    - gouvernance_institutions
    - energie_ressources_critiques
    - organisation_territoires

zone_geographique:
    - régionale
    - continentale
    - globale

zone_systemique:
    - gouvernance
    - infrastructure
    - énergie
    - économie

alliances:
- agence_internationale_de_l_energie_reformatee_aier_policy_reform
- conseil_de_regulation_climatique_global_policy_reform
- conseil_regulation_ressources_policy_reform
- fonds_mondial_de_resilience_infrastructurelle_policy_reform
- great_lakes_autonomous_compact_policy_reform
- kalaallit_nunaat_sovereign_fund_policy_reform
- observatoire_mondial_des_ressources_critiques_policy_reform
oppositions:
- coalition_des_operateurs_energetiques_prives_anti_quotas_policy_reform
- front_de_souverainete_biologique_eurasiatique_policy_reform
- front_des_souverainistes_energetiques_policy_reform
- front_souverainiste_des_blocs_non_signataires_policy_reform
- mouvement_pour_la_souverainete_territoriale_absolue_policy_reform
- syndicats_d_extraction_privee_non_regules_policy_reform
type_relation_dominante: alliance stratégique

annee_debut: 2041
annee_fin: 

etat_temporel: actif
age_historique: dominant
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  Depuis ses bureaux vitrés dominant la baie de Frobisher à Iqaluit, l'Arctic Passage Authority administre ce que beaucoup considèrent comme le couloir commercial le plus disputé du siècle : le Passage du Nord-Ouest, désormais navigable douze mois sur douze. Fondée en 2041 sur les décombres diplomatiques des guerres de positionnement arctique, elle est présentée à Genève et à Nairobi comme la preuve vivante que la co-gouvernance autochtone peut s'intégrer à la régulation globale sans se dissoudre. Mais à Iqaluit comme à Clyde River, les voix dissidentes se multiplient : les représentants inuit au sein du Conseil de Direction se plaignent d'être consultés après les décisions, jamais avant. La station avancée de Thulé-Reconvertie, inaugurée en 2057 sur les ruines de l'ancienne base militaire américaine, cristallise le paradoxe : vitrine de la réconciliation territoriale pour les brochures onusiennes, elle est aussi le hub opérationnel depuis lequel l'APA coordonne le transit de deux mille navires par an, dont une majorité d'opérateurs privés sous pavillon asiatique ou européen.

signes_distinctifs: >
  Le logo de l'APA représente une boussole dont l'aiguille nord est remplacée par une silhouette d'Inuksuk — choix iconographique unanimement salué lors du lancement, aujourd'hui régulièrement moqué par les militants autochtones comme symbole de l'esthétique de la dépossession. Les documents officiels sont publiés en inuktitut, en français, en anglais et en danois, mais les délibérations techniques se tiennent exclusivement en anglais. Les agents de terrain à Thulé portent des parkas à bande azur marquées du sigle APA, uniforme conçu par un designer inuit de Kuujjuaq — l'un des rares éléments de l'institution dont la paternité culturelle n'est pas contestée.

tensions_narratives: >
  La tension centrale de l'APA en 2098 est une question de fond : la représentation inuit au sein du Conseil de Direction (un tiers des sièges, garantie par le Traité d'Iqaluit de 2041) constitue-t-elle une souveraineté réelle ou une chambre d'enregistrement ornementale ? Le Kalaallit Nunaat Sovereign Fund pousse à élargir les prérogatives inuit sur la fixation des péages environnementaux, tandis que les États membres — Canada en tête — résistent à tout rééquilibrage qui réduirait leur contrôle sur un corridor d'intérêt stratégique national. En parallèle, la rivalité avec la NAT sur les corridors arctiques occidentaux prend une dimension de plus en plus ouverte : deux incidents de «superposition de juridiction» en 2096-2097 ont failli dégénérer en crise diplomatique formelle. Enfin, des fuites récentes dans la presse — relayées par le Réseau des Journalistes d'Investigation Énergétique — suggèrent que des opérateurs privés proches de la Coalition des Opérateurs Énergétiques Privés Anti-Quotas contournent les protocoles environnementaux via des pavillons de complaisance, avec la complicité passive de certains fonctionnaires canadiens au sein de l'APA.

date_creation: 2026-06-23
---

# Arctic Passage Authority — Administration du Passage du Nord-Ouest

## Rôle dans [[policy_reform]]
Autorité intergouvernementale co-administrée par le Groenland, le Canada et les peuples Inuit, l'APA gère le Passage du Nord-Ouest devenu la route commerciale la plus fréquentée de l'hémisphère nord depuis la disparition de la banquise estivale. Dans le scénario policy_reform, elle incarne le modèle de gouvernance multi-niveaux à son stade le plus mature et le plus tendu : une institution pleinement opérationnelle, reconnue internationalement, mais traversée par des contradictions profondes entre sa légitimité autochtone affichée et les logiques de flux commerciaux qu'elle administre. Rivale directe de la NAT sur les corridors arctiques occidentaux, elle est à la fois vitrine du modèle technocratique de co-gouvernance et terrain d'une lutte sourde entre souveraineté inuit réelle et instrumentalisation institutionnelle. Son siège à Iqaluit et sa station avancée à Thulé-Reconvertie en font une présence physique et symbolique sur le territoire qu'elle prétend cogérer.

## Responsabilités
L'APA régule le transit commercial, militaire et scientifique sur le Passage du Nord-Ouest via un système de permis, de péages environnementaux et de protocoles d'impact territorial négociés avec les communautés inuit. Elle administre les infrastructures portuaires, les corridors de sécurité maritime et les standards environnementaux applicables aux opérateurs privés et étatiques transitant par l'Arctique occidental. Elle est également chargée de la redistribution d'une fraction des redevances de transit aux fonds de développement des territoires inuit, clause centrale de son mandat de co-gouvernance.

## Variables influencées
- [[geopolitique_conflits]]
- [[gouvernance_institutions]]
- [[energie_ressources_critiques]]
- [[organisation_territoires]]


## Description journalistique
Depuis ses bureaux vitrés dominant la baie de Frobisher à Iqaluit, l'Arctic Passage Authority administre ce que beaucoup considèrent comme le couloir commercial le plus disputé du siècle : le Passage du Nord-Ouest, désormais navigable douze mois sur douze. Fondée en 2041 sur les décombres diplomatiques des guerres de positionnement arctique, elle est présentée à Genève et à Nairobi comme la preuve vivante que la co-gouvernance autochtone peut s'intégrer à la régulation globale sans se dissoudre. Mais à Iqaluit comme à Clyde River, les voix dissidentes se multiplient : les représentants inuit au sein du Conseil de Direction se plaignent d'être consultés après les décisions, jamais avant. La station avancée de Thulé-Reconvertie, inaugurée en 2057 sur les ruines de l'ancienne base militaire américaine, cristallise le paradoxe : vitrine de la réconciliation territoriale pour les brochures onusiennes, elle est aussi le hub opérationnel depuis lequel l'APA coordonne le transit de deux mille navires par an, dont une majorité d'opérateurs privés sous pavillon asiatique ou européen.

## Tensions narratives
La tension centrale de l'APA en 2098 est une question de fond : la représentation inuit au sein du Conseil de Direction (un tiers des sièges, garantie par le Traité d'Iqaluit de 2041) constitue-t-elle une souveraineté réelle ou une chambre d'enregistrement ornementale ? Le Kalaallit Nunaat Sovereign Fund pousse à élargir les prérogatives inuit sur la fixation des péages environnementaux, tandis que les États membres — Canada en tête — résistent à tout rééquilibrage qui réduirait leur contrôle sur un corridor d'intérêt stratégique national. En parallèle, la rivalité avec la NAT sur les corridors arctiques occidentaux prend une dimension de plus en plus ouverte : deux incidents de «superposition de juridiction» en 2096-2097 ont failli dégénérer en crise diplomatique formelle. Enfin, des fuites récentes dans la presse — relayées par le Réseau des Journalistes d'Investigation Énergétique — suggèrent que des opérateurs privés proches de la Coalition des Opérateurs Énergétiques Privés Anti-Quotas contournent les protocoles environnementaux via des pavillons de complaisance, avec la complicité passive de certains fonctionnaires canadiens au sein de l'APA.

## Relations
**Alliés :**
- [[agence_internationale_de_l_energie_reformatee_aier_policy_reform]]
- [[conseil_de_regulation_climatique_global_policy_reform]]
- [[conseil_regulation_ressources_policy_reform]]
- [[fonds_mondial_de_resilience_infrastructurelle_policy_reform]]
- [[great_lakes_autonomous_compact_policy_reform]]
- [[kalaallit_nunaat_sovereign_fund_policy_reform]]
- [[observatoire_mondial_des_ressources_critiques_policy_reform]]
**Opposants :**
- [[coalition_des_operateurs_energetiques_prives_anti_quotas_policy_reform]]
- [[front_de_souverainete_biologique_eurasiatique_policy_reform]]
- [[front_des_souverainistes_energetiques_policy_reform]]
- [[front_souverainiste_des_blocs_non_signataires_policy_reform]]
- [[mouvement_pour_la_souverainete_territoriale_absolue_policy_reform]]
- [[syndicats_d_extraction_privee_non_regules_policy_reform]]
