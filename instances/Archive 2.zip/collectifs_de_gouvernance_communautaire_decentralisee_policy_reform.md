---
name: Collectifs de Gouvernance Communautaire Décentralisée
type: instance
slug: collectifs_de_gouvernance_communautaire_decentralisee_policy_reform
entite: collectifs_de_gouvernance_communautaire_decentralisee
scenario: policy_reform
statut: officialise_enrichi
type_dans_scenario: réseau
role_dans_scenario: 'Dans le scénario policy_reform, les Collectifs de Gouvernance
  Communautaire Décentralisée incarnent la tension structurelle entre la réforme par
  le haut — portée par les institutions technocratiques de Genève, La Haye et Nairobi
  — et la transformation par le bas, ancrée dans les pratiques délibératives locales.
  Ils constituent à la fois un contre-pouvoir diffus, un réservoir d''innovations
  démocratiques et un révélateur des contradictions de la gouvernance régulatrice
  : capables de bloquer ou de contourner les réformes descendantes là où ils sont
  forts, ils peinent néanmoins à produire des alternatives scalables dans un monde
  où les crises systémiques exigent une coordination globale rapide.'
responsabilites: Les Collectifs de Gouvernance Communautaire Décentralisée coordonnent
  des expérimentations de démocratie directe à l'échelle locale et régionale, en concurrence
  avec les réformes institutionnelles portées par les grandes agences technocratiques.
  Ils documentent et diffusent des modèles de délibération participative alternatifs,
  servant de laboratoires politiques pour des populations qui rejettent la gouvernance
  algorithmique descendante. Dans le cadre du scénario policy_reform, ils exercent
  une pression constante sur les institutions régulatrices pour intégrer des mécanismes
  de participation citoyenne authentique dans les réformes en cours.
impact_local: 4
impact_systemique_global: 3
variables_influencees:
- gouvernance_institutions
- organisation_territoires
- valeurs_culture_tempo_sociale
zone_geographique:
- locale
- régionale
- continentale
zone_systemique:
- société
alliances:
- coalition_des_semences_libres_policy_reform
- coalition_des_villes_de_reconversion_policy_reform
- collectifs_citoyens_de_deliberation_augmentee_policy_reform
- collectifs_citoyens_pour_l_audit_algorithmique_ouvert_policy_reform
- collectifs_de_biohackers_agro_communautaires_policy_reform
- collectifs_de_defense_hydrique_saheliens_policy_reform
- collectifs_de_hackers_biospheriques_policy_reform
- collectifs_de_resistance_aux_relocalisations_forcees_policy_reform
- consortium_africain_de_biotechnologies_sociales_policy_reform
- consortium_amazonia_viva_policy_reform
- consortium_des_villes_etats_durables_policy_reform
- courants_post_technocratiques_de_reconquete_democratique_policy_reform
- factions_internes_pro_desaugmentation_totale_policy_reform
- front_des_autonomies_territoriales_radicales_policy_reform
- great_lakes_autonomous_compact_policy_reform
- internationale_decroissante_anti_planification_policy_reform
- les_veilleurs_du_fleuve_policy_reform
- mouvement_pour_la_justice_ecologique_communautaire_policy_reform
- mouvement_pour_la_souverainete_energetique_commune_msec_policy_reform
- reseau_des_auditeurs_algorithmiques_independants_raai_policy_reform
oppositions:
- agence_technocratique_pour_la_resilience_biospherique_atrb_policy_reform
- assemblee_territoires_policy_reform
- bureau_gouvernance_algorithmique_policy_reform
- conseil_intergouvernemental_de_regulation_technologique_policy_reform
- conseil_regulation_algorithmique_policy_reform
- consortiums_prives_de_gouvernance_algorithmique_policy_reform
- courant_autoritaire_recuperateur_du_vocabulaire_communautaire_policy_reform
- directive_kontinuum_policy_reform
- factions_technocratiques_de_la_marchandisation_hydrique_policy_reform
- front_techno_utopiste_de_la_decision_automatisee_policy_reform
- rede_paulista_de_distribuic_o_algor_tmica_policy_reform
- reseau_des_agences_sanitaires_regionales_policy_reform
type_relation_dominante: compétition
annee_debut: 2026
annee_fin: null
etat_temporel: actif
age_historique: émergent
generation: transition
injection:
  type: canonique
  annee_injection: null
  contexte_injection: null
  impact_sur_variables: null
  propagation:
    via_matrice: false
description_journalistique: Nés dans les marges du grand réformisme technocratique
  des années 2030, les Collectifs de Gouvernance Communautaire Décentralisée constituent
  aujourd'hui l'un des réseaux de contestation institutionnelle les plus structurés
  de la planète. Présents sur quatre continents, ils opposent à la rationalisation
  algorithmique des institutions mondiales une pratique tenace de l'assemblée, du
  consensus et de l'autogouvernement. À l'heure où Genève régule et La Haye juge,
  ces collectifs rappellent obstinément que la légitimité démocratique ne se télécharge
  pas.
signes_distinctifs: Leur marque de fabrique est le recours systématique aux assemblées
  délibératives à droit de veto local, une pratique qui tranche radicalement avec
  les plateformes de consultation citoyenne pilotées par les institutions globales.
  Ils publient régulièrement des contre-rapports de gouvernance documentant les angles
  morts des réformes technocratiques.
tensions_narratives: 'Ces collectifs sont tiraillés entre leur vocation radicalement
  locale et la nécessité de se coordonner à l''échelle transnationale pour peser sur
  les réformes globales, risquant ainsi de reproduire les structures hiérarchiques
  qu''ils entendent subvertir. Leur succès même les expose à une récupération institutionnelle
  : les grandes agences régulatrices cherchent à les intégrer comme instances consultatives,
  ce qui divise profondément leurs membres entre participation stratégique et préservation
  de l''indépendance. Enfin, leur fragmentation géographique et idéologique les rend
  vulnérables face aux crises climatiques et migratoires qui réclament des réponses
  coordonnées rapides.'
date_creation: 2026-06-20
localisation:
  zone: null
  lieu: null
  type_lieu: null
---

# Collectifs de Gouvernance Communautaire Décentralisée

## Rôle dans [[policy_reform]]
Dans le scénario policy_reform, les Collectifs de Gouvernance Communautaire Décentralisée incarnent la tension structurelle entre la réforme par le haut — portée par les institutions technocratiques de Genève, La Haye et Nairobi — et la transformation par le bas, ancrée dans les pratiques délibératives locales. Ils constituent à la fois un contre-pouvoir diffus, un réservoir d'innovations démocratiques et un révélateur des contradictions de la gouvernance régulatrice : capables de bloquer ou de contourner les réformes descendantes là où ils sont forts, ils peinent néanmoins à produire des alternatives scalables dans un monde où les crises systémiques exigent une coordination globale rapide.

## Responsabilités
Les Collectifs de Gouvernance Communautaire Décentralisée coordonnent des expérimentations de démocratie directe à l'échelle locale et régionale, en concurrence avec les réformes institutionnelles portées par les grandes agences technocratiques. Ils documentent et diffusent des modèles de délibération participative alternatifs, servant de laboratoires politiques pour des populations qui rejettent la gouvernance algorithmique descendante. Dans le cadre du scénario policy_reform, ils exercent une pression constante sur les institutions régulatrices pour intégrer des mécanismes de participation citoyenne authentique dans les réformes en cours.

## Description journalistique
Nés dans les marges du grand réformisme technocratique des années 2030, les Collectifs de Gouvernance Communautaire Décentralisée constituent aujourd'hui l'un des réseaux de contestation institutionnelle les plus structurés de la planète. Présents sur quatre continents, ils opposent à la rationalisation algorithmique des institutions mondiales une pratique tenace de l'assemblée, du consensus et de l'autogouvernement. À l'heure où Genève régule et La Haye juge, ces collectifs rappellent obstinément que la légitimité démocratique ne se télécharge pas.

## Signes distinctifs
Leur marque de fabrique est le recours systématique aux assemblées délibératives à droit de veto local, une pratique qui tranche radicalement avec les plateformes de consultation citoyenne pilotées par les institutions globales. Ils publient régulièrement des contre-rapports de gouvernance documentant les angles morts des réformes technocratiques.

## Tensions narratives
Ces collectifs sont tiraillés entre leur vocation radicalement locale et la nécessité de se coordonner à l'échelle transnationale pour peser sur les réformes globales, risquant ainsi de reproduire les structures hiérarchiques qu'ils entendent subvertir. Leur succès même les expose à une récupération institutionnelle : les grandes agences régulatrices cherchent à les intégrer comme instances consultatives, ce qui divise profondément leurs membres entre participation stratégique et préservation de l'indépendance. Enfin, leur fragmentation géographique et idéologique les rend vulnérables face aux crises climatiques et migratoires qui réclament des réponses coordonnées rapides.

## Variables influencées
- [[gouvernance_institutions]]
- [[organisation_territoires]]
- [[valeurs_culture_tempo_sociale]]


## Relations
**Alliés :**
- [[coalition_des_semences_libres_policy_reform]]
- [[coalition_des_villes_de_reconversion_policy_reform]]
- [[collectifs_citoyens_de_deliberation_augmentee_policy_reform]]
- [[collectifs_citoyens_pour_l_audit_algorithmique_ouvert_policy_reform]]
- [[collectifs_de_biohackers_agro_communautaires_policy_reform]]
- [[collectifs_de_defense_hydrique_saheliens_policy_reform]]
- [[collectifs_de_hackers_biospheriques_policy_reform]]
- [[collectifs_de_resistance_aux_relocalisations_forcees_policy_reform]]
- [[consortium_africain_de_biotechnologies_sociales_policy_reform]]
- [[consortium_amazonia_viva_policy_reform]]
- [[consortium_des_villes_etats_durables_policy_reform]]
- [[courants_post_technocratiques_de_reconquete_democratique_policy_reform]]
- [[factions_internes_pro_desaugmentation_totale_policy_reform]]
- [[front_des_autonomies_territoriales_radicales_policy_reform]]
- [[great_lakes_autonomous_compact_policy_reform]]
- [[internationale_decroissante_anti_planification_policy_reform]]
- [[les_veilleurs_du_fleuve_policy_reform]]
- [[mouvement_pour_la_justice_ecologique_communautaire_policy_reform]]
- [[mouvement_pour_la_souverainete_energetique_commune_msec_policy_reform]]
- [[reseau_des_auditeurs_algorithmiques_independants_raai_policy_reform]]
**Opposants :**
- [[agence_technocratique_pour_la_resilience_biospherique_atrb_policy_reform]]
- [[assemblee_territoires_policy_reform]]
- [[bureau_gouvernance_algorithmique_policy_reform]]
- [[conseil_intergouvernemental_de_regulation_technologique_policy_reform]]
- [[conseil_regulation_algorithmique_policy_reform]]
- [[consortiums_prives_de_gouvernance_algorithmique_policy_reform]]
- [[courant_autoritaire_recuperateur_du_vocabulaire_communautaire_policy_reform]]
- [[directive_kontinuum_policy_reform]]
- [[factions_technocratiques_de_la_marchandisation_hydrique_policy_reform]]
- [[front_techno_utopiste_de_la_decision_automatisee_policy_reform]]
- [[rede_paulista_de_distribuic_o_algor_tmica_policy_reform]]
- [[reseau_des_agences_sanitaires_regionales_policy_reform]]

## Notes
Fiche enrichie depuis officialise_minimal le 2026-06-27.
