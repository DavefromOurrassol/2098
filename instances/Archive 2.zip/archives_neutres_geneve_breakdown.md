---
name: Archives Neutres de Genève
type: instance
slug: archives_neutres_geneve_breakdown
entite: archives_neutres_geneve
scenario: breakdown
statut: officialise_enrichi
localisation:
  zone: archives_neutres_geneve
  lieu: Archives Neutres de Genève (sous-sols du Palais des Nations)
  type_lieu: infrastructure
type_dans_scenario: institution

role_dans_scenario: >
  Dans un monde où les États se sont fragmentés et où la légitimité documentaire est devenue une ressource aussi précieuse que l'eau ou l'énergie, les Archives Neutres de Genève font office d'arbitre silencieux de ce qui a existé. Installées dans les sous-sols renforcés de l'ancienne Palais des Nations — désormais zone tampon négociée entre plusieurs factions armées — elles conservent les traces des traités internationaux, des législations nationales effondrées, des actes de propriété, des constitutions dissoltes et des jurisprudences oubliées. Elles ne gouvernent pas, ne combattent pas : elles attestent, et cette attestation a un prix. Dans le chaos du breakdown, leur neutralité revendiquée est devenue une monnaie d'échange fragile qu'elles négocient quotidiennement contre des ressources physiques et des garanties de protection militaire.

responsabilites: >
  Authentifier et délivrer des copies certifiées de documents juridiques et institutionnels préexistants à l'effondrement, à destination des communautés locales, cités-états ou factions qui cherchent à légitimer une revendication territoriale, foncière ou normative. Négocier leur propre survie logistique — accès à l'électricité, à la nourriture, à la protection armée — contre l'accès contrôlé et gradué à leurs fonds documentaires. Maintenir un protocole d'accueil des archivistes itinérants qui rapportent des fragments documentaires rescapés des zones de conflit.

impact_local: 4
impact_systemique_global: 3

variables_influencees:
    - gouvernance_institutions
    - technologie_information

zone_geographique:
    - régionale
    - continentale

zone_systemique:
    - gouvernance
    - information
    - société

alliances:
- collectifs_de_gardiens_archivistes_itinerants_breakdown
- collectifs_de_hackers_archivistes_des_interstices_reseaux_breakdown
- enclaves_technologiques_survivantes_breakdown
- front_humanitaire_d_urgence_non_affilie_breakdown
- geneve_bunker_institutions_breakdown
- ligue_mediterraneenne_des_villes_etats_portuaires_breakdown
- reseau_des_courriers_nomades_sahelo_mediterraneens_breakdown
- tour_bcuc_geneve_breakdown
- tribunal_algorithmique_de_bruxelles_breakdown
oppositions:
- enclaves_corporatives_fortifiees_breakdown
- factions_propagandistes_des_archives_breakdown
- front_des_blocs_regionaux_du_recit_des_conflits_ressources_breakdown
- gouvernements_de_forteresse_anti_nairobi_breakdown
- milices_de_controle_territorial_breakdown
- reseau_des_anciens_financeurs_devenus_censeurs_breakdown
- seigneuries_logistiques_armees_breakdown
type_relation_dominante: neutralité

annee_debut: 2026
annee_fin: 

etat_temporel: actif
age_historique: résiduel
generation: post-effondrement

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  Dans les sous-sols humides de ce qui fut le Palais des Nations, entre des rayonnages métalliques rouillés et des serveurs alimentés par des panneaux solaires de récupération, une vingtaine d'archivistes en manteaux usés tamponnent encore des documents au nom de la neutralité helvétique. Les Archives Neutres de Genève survivent — à peine — en vendant leur mémoire fragment par fragment : un traité d'eau contre un bidon de gasoil, un acte de propriété cadastrale contre une semaine de protection armée assurée par telle ou telle milice. Leur directrice, une juriste genevoise d'une soixantaine d'années nommée Elsbeth Varner, répète que 'la mémoire ne se vend pas' mais chaque semaine, elle signe un nouvel accord de fourniture avec un nouveau seigneur local. Ceux qui viennent les consulter — délégués paysans, émissaires de cités-états, plénipotentiaires de factions en guerre — savent qu'ils entrent dans un espace où les règles de l'ancien monde ont encore une valeur, aussi étrange que cela paraisse en 2098.

signes_distinctifs: >
  Le sceau circulaire de la Confédération helvétique, frappé à froid sur papier vergé archivistique, reste le signe de reconnaissance ultime des documents certifiés — reconnu même par ceux qui ont combattu contre les États qui l'ont créé. Les archivistes portent un brassard blanc frappé d'un sablier noir, symbole autoproclamé de leur mission : garder le temps suspendu. Les accès aux fonds sont codifiés par des laisser-passer physiques numérotés à la main, distribués avec une parcimonie calculée.

tensions_narratives: >
  La tension centrale est existentielle : jusqu'où les Archives peuvent-elles négocier leur accès sans devenir l'instrument d'une faction plutôt que le bien commun de toutes ? Plusieurs blocs régionaux tentent activement de corrompre ou d'infiltrer le personnel pour obtenir un accès exclusif à des documents stratégiques — actes de concession minière préeffondrement, traités de délimitation de corridors d'eau. En parallèle, les collectifs hackers-archivistes itinérants pressent les Archives de numériser et diffuser librement leurs fonds, ce que Varner refuse au nom de la survie physique de l'institution. Une troisième tension sourd en interne : une faction minoritaire du personnel, épuisée et idéaliste, envisage une 'grande ouverture' sacrificielle — tout diffuser, tout publier, quitte à disparaître, plutôt que de continuer à attester pour ceux qui paient.

date_creation: 2026-06-27
---

# Archives Neutres de Genève

## Rôle dans [[breakdown]]
Dans un monde où les États se sont fragmentés et où la légitimité documentaire est devenue une ressource aussi précieuse que l'eau ou l'énergie, les Archives Neutres de Genève font office d'arbitre silencieux de ce qui a existé. Installées dans les sous-sols renforcés de l'ancienne Palais des Nations — désormais zone tampon négociée entre plusieurs factions armées — elles conservent les traces des traités internationaux, des législations nationales effondrées, des actes de propriété, des constitutions dissoltes et des jurisprudences oubliées. Elles ne gouvernent pas, ne combattent pas : elles attestent, et cette attestation a un prix. Dans le chaos du breakdown, leur neutralité revendiquée est devenue une monnaie d'échange fragile qu'elles négocient quotidiennement contre des ressources physiques et des garanties de protection militaire.

## Responsabilités
Authentifier et délivrer des copies certifiées de documents juridiques et institutionnels préexistants à l'effondrement, à destination des communautés locales, cités-états ou factions qui cherchent à légitimer une revendication territoriale, foncière ou normative. Négocier leur propre survie logistique — accès à l'électricité, à la nourriture, à la protection armée — contre l'accès contrôlé et gradué à leurs fonds documentaires. Maintenir un protocole d'accueil des archivistes itinérants qui rapportent des fragments documentaires rescapés des zones de conflit.

## Variables influencées
- [[gouvernance_institutions]]
- [[technologie_information]]


## Description journalistique
Dans les sous-sols humides de ce qui fut le Palais des Nations, entre des rayonnages métalliques rouillés et des serveurs alimentés par des panneaux solaires de récupération, une vingtaine d'archivistes en manteaux usés tamponnent encore des documents au nom de la neutralité helvétique. Les Archives Neutres de Genève survivent — à peine — en vendant leur mémoire fragment par fragment : un traité d'eau contre un bidon de gasoil, un acte de propriété cadastrale contre une semaine de protection armée assurée par telle ou telle milice. Leur directrice, une juriste genevoise d'une soixantaine d'années nommée Elsbeth Varner, répète que 'la mémoire ne se vend pas' mais chaque semaine, elle signe un nouvel accord de fourniture avec un nouveau seigneur local. Ceux qui viennent les consulter — délégués paysans, émissaires de cités-états, plénipotentiaires de factions en guerre — savent qu'ils entrent dans un espace où les règles de l'ancien monde ont encore une valeur, aussi étrange que cela paraisse en 2098.

## Tensions narratives
La tension centrale est existentielle : jusqu'où les Archives peuvent-elles négocier leur accès sans devenir l'instrument d'une faction plutôt que le bien commun de toutes ? Plusieurs blocs régionaux tentent activement de corrompre ou d'infiltrer le personnel pour obtenir un accès exclusif à des documents stratégiques — actes de concession minière préeffondrement, traités de délimitation de corridors d'eau. En parallèle, les collectifs hackers-archivistes itinérants pressent les Archives de numériser et diffuser librement leurs fonds, ce que Varner refuse au nom de la survie physique de l'institution. Une troisième tension sourd en interne : une faction minoritaire du personnel, épuisée et idéaliste, envisage une 'grande ouverture' sacrificielle — tout diffuser, tout publier, quitte à disparaître, plutôt que de continuer à attester pour ceux qui paient.

## Relations
**Alliés :**
- [[collectifs_de_gardiens_archivistes_itinerants_breakdown]]
- [[collectifs_de_hackers_archivistes_des_interstices_reseaux_breakdown]]
- [[enclaves_technologiques_survivantes_breakdown]]
- [[front_humanitaire_d_urgence_non_affilie_breakdown]]
- [[geneve_bunker_institutions_breakdown]]
- [[ligue_mediterraneenne_des_villes_etats_portuaires_breakdown]]
- [[reseau_des_courriers_nomades_sahelo_mediterraneens_breakdown]]
- [[tour_bcuc_geneve_breakdown]]
- [[tribunal_algorithmique_de_bruxelles_breakdown]]
**Opposants :**
- [[enclaves_corporatives_fortifiees_breakdown]]
- [[factions_propagandistes_des_archives_breakdown]]
- [[front_des_blocs_regionaux_du_recit_des_conflits_ressources_breakdown]]
- [[gouvernements_de_forteresse_anti_nairobi_breakdown]]
- [[milices_de_controle_territorial_breakdown]]
- [[reseau_des_anciens_financeurs_devenus_censeurs_breakdown]]
- [[seigneuries_logistiques_armees_breakdown]]
