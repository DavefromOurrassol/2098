---
name: Assemblées Bioterritoriales Régionales
type: instance
slug: assemblees_bioterritoriales_regionales_eco_communalism
entite: assemblees_bioterritoriales_regionales
scenario: eco_communalism
statut: officialise_enrichi
type_dans_scenario: institution
role_dans_scenario: Colonne vertébrale institutionnelle du communalisme écologique,
  les Assemblées Bioterritoriales Régionales exercent une souveraineté hybride en
  articulant logique bioécologique et délibération démocratique à l'échelle de bassins
  vivants. Émergées de la fragmentation institutionnelle des années 2040, elles structurent
  la gouvernance des territoires autonomes tout en naviguant la tension permanente
  entre inclusion démocratique et impératif écologique d'urgence.
responsabilites: Les Assemblées Bioterritoriales Régionales organisent la délibération
  collective sur la gestion des ressources naturelles, la planification écologique
  et la résilience climatique à l'échelle de bassins versants et d'écosystèmes partagés.
  Elles arbitrent les conflits d'usage entre communautés locales, fixent les quotas
  de prélèvement, coordonnent les corridors de régénération et valident les chartes
  d'appartenance bioterritioriale. Elles constituent le principal relais entre les
  décisions de subsistance quotidienne et les impératifs écosystémiques de long terme,
  en articulant savoirs autochtones, expertise écologique et mandat démocratique.
impact_local: 5
impact_systemique_global: 4
variables_influencees:
- organisation_territoires
- gouvernance_institutions
- climat_environnement_global
zone_geographique:
- régionale
- continentale
zone_systemique:
- société
alliances:
- amazonie_pacte_viva_eco_communalism
- archives_ouvertes_des_jurisprudences_communales_aojc_eco_communalism
- assemblees_cooperatives_regionales_eco_communalism
- assemblees_de_bassin_versant_eco_communalism
- brigades_de_restauration_ecologique_eco_communalism
- cercles_de_mediation_territoriale_intercommunautaire_eco_communalism
- collectifs_de_cartographie_ecologique_participative_eco_communalism
- collectifs_de_facilitateurs_deliberatifs_itinerants_eco_communalism
- collectifs_de_geo_observateurs_citoyens_eco_communalism
- collectifs_de_techniciens_sobres_eco_communalism
- confederation_bassins_vivants_eco_communalism
- confederation_communs_arc_septentrional_eco_communalism
- conseils_de_bassin_versant_eco_communalistes_eco_communalism
- consortium_africain_de_biotechnologies_sociales_eco_communalism
- consortium_amazonia_viva_eco_communalism
- cooperatives_d_habitat_regeneratif_eco_communalism
- cooperatives_semencieres_et_d_archives_agronomiques_eco_communalism
- factions_algorithmiques_pro_gouvernance_ia_legere_eco_communalism
- fraternites_ecospiritualistes_des_anciens_survivalistes_eco_communalism
- guildes_de_mediateurs_ecologiques_eco_communalism
- guildes_des_semenciers_itinerants_eco_communalism
- kalaallit_nunaat_bioterritoire_eco_communalism
- kalaallit_nunaat_sovereign_fund_eco_communalism
- les_veilleurs_du_fleuve_eco_communalism
- mouvement_des_archives_vivantes_du_savoir_partage_eco_communalism
- mutuelles_de_sante_territoriales_eco_communalism
- oracle_des_seuils_eco_communalism
- rede_paulista_de_distribuic_o_algor_tmica_eco_communalism
- reseau_des_assemblees_de_bassin_fennoscandien_eco_communalism
- reseau_mnemos_eco_communalism
- reseau_terrafond_bassins_eco_communalism
- reseaux_de_bibliotheques_archives_communautaires_eco_communalism
- reseaux_de_radio_communautaire_basse_consommation_eco_communalism
- reseaux_de_reconstruction_cooperative_inter_communautes_eco_communalism
- reseaux_de_troc_inter_cooperatives_et_marges_periurbaines_eco_communalism
- trame_bioclimatique_eco_communalism
- tresse_verte_corridor_eco_communalism
- tribunal_algorithmique_de_bruxelles_eco_communalism
- universite_nomade_eco_communalism
- zones_extractivistes_corridors_eco_communalism
oppositions:
- agro_conglomerats_des_enclaves_technologiques_eco_communalism
- cartels_de_narration_de_penurie_eco_communalism
- communautes_rurales_dissidentes_anti_cooperation_regionale_eco_communalism
- communs_secessionnistes_hors_coordination_eco_communalism
- conseils_territoriaux_opaques_sur_la_gestion_des_ressources_eco_communalism
- consortium_des_operateurs_d_ia_proprietaires_sur_les_trames_eco_communalism
- consortiums_industriels_de_l_eau_eco_communalism
- consortiums_logistiques_neo_industriels_des_terres_reconstruites_eco_communalism
- courant_isolationniste_anti_circulation_de_l_information_eco_communalism
- courant_techno_solutionniste_pro_re_globalisation_numerique_eco_communalism
- enclaves_extractivistes_et_etats_residuels_eco_communalism
- enclaves_extractivistes_residuelles_des_corridors_eco_communalism
- factions_autoritaires_de_controle_du_savoir_eco_communalism
- factions_autoritaires_locales_identitaires_exclusionnistes_eco_communalism
- factions_communautaires_refusant_le_partage_narratif_exterieur_eco_communalism
- factions_extractivistes_des_aquiferes_communs_eco_communalism
- factions_technophiles_de_la_geo_ingenierie_centralisee_eco_communalism
- fragments_d_etats_centraux_residuels_eco_communalism
- reseau_des_marches_noirs_de_donnees_extractivistes_eco_communalism
- reseaux_de_notables_communautaires_capturistes_eco_communalism
type_relation_dominante: symbiose
annee_debut: 2026
annee_fin: null
etat_temporel: actif
age_historique: émergent
generation: transition
injection:
  type: canonique
  annee_injection: null
  contexte_injection: null
  impact_sur_variables: null
  propagation:
    via_matrice: false
description_journalistique: 'Nées de la fragmentation institutionnelle des années
  2040, les Assemblées Bioterritoriales Régionales sont aujourd''hui l''épine dorsale
  de la gouvernance dans les territoires autonomes : on y vote par bassin versant,
  on y légifère par strate végétale. Ni État, ni simple commune, elles incarnent cette
  révolution silencieuse où le droit du territoire prime sur le droit du sol. Leur
  autorité repose moins sur la contrainte que sur la légitimité écologique — ce qui
  en fait à la fois leur force et leur fragilité.'
signes_distinctifs: Chaque Assemblée tient ses sessions en plein air, rythmées par
  le calendrier phénologique local, et ses décisions sont consignées dans des archives
  vivantes co-tenues par des gardiens de mémoire humains et des capteurs biométriques
  low-tech. Le mandat des délégués y expire non à date fixe mais à l'issue d'un cycle
  écologique désigné au moment de l'élection.
tensions_narratives: Les Assemblées sont constamment tiraillées entre leur vocation
  délibérative inclusive et la nécessité de décisions rapides face aux crises climatiques
  saisonnières, souvent perçues comme trop lentes par les communautés en urgence.
  Leur légitimité est contestée aux marges, là où les enclaves extractivistes résiduelles
  refusent de reconnaître leur souveraineté et où les flux migratoires climatiques
  introduisent des populations sans ancrage bioterritorial établi. Enfin, la tentation
  de la consolidation — fusionner des Assemblées pour gagner en efficacité — risque
  à chaque cycle de reproduire les logiques étatiques centralisatrices qu'elles prétendent
  avoir abolies.
date_creation: 2026-06-20
localisation:
  zone: null
  lieu: null
  type_lieu: region
---

# Assemblées Bioterritoriales Régionales

## Rôle dans [[eco_communalism]]
Colonne vertébrale institutionnelle du communalisme écologique, les Assemblées Bioterritoriales Régionales exercent une souveraineté hybride en articulant logique bioécologique et délibération démocratique à l'échelle de bassins vivants. Émergées de la fragmentation institutionnelle des années 2040, elles structurent la gouvernance des territoires autonomes tout en naviguant la tension permanente entre inclusion démocratique et impératif écologique d'urgence.

## Responsabilités
Les Assemblées Bioterritoriales Régionales organisent la délibération collective sur la gestion des ressources naturelles, la planification écologique et la résilience climatique à l'échelle de bassins versants et d'écosystèmes partagés. Elles arbitrent les conflits d'usage entre communautés locales, fixent les quotas de prélèvement, coordonnent les corridors de régénération et valident les chartes d'appartenance bioterritioriale. Elles constituent le principal relais entre les décisions de subsistance quotidienne et les impératifs écosystémiques de long terme, en articulant savoirs autochtones, expertise écologique et mandat démocratique.

## Description journalistique
Nées de la fragmentation institutionnelle des années 2040, les Assemblées Bioterritoriales Régionales sont aujourd'hui l'épine dorsale de la gouvernance dans les territoires autonomes : on y vote par bassin versant, on y légifère par strate végétale. Ni État, ni simple commune, elles incarnent cette révolution silencieuse où le droit du territoire prime sur le droit du sol. Leur autorité repose moins sur la contrainte que sur la légitimité écologique — ce qui en fait à la fois leur force et leur fragilité.

## Signes distinctifs
Chaque Assemblée tient ses sessions en plein air, rythmées par le calendrier phénologique local, et ses décisions sont consignées dans des archives vivantes co-tenues par des gardiens de mémoire humains et des capteurs biométriques low-tech. Le mandat des délégués y expire non à date fixe mais à l'issue d'un cycle écologique désigné au moment de l'élection.

## Tensions narratives
Les Assemblées sont constamment tiraillées entre leur vocation délibérative inclusive et la nécessité de décisions rapides face aux crises climatiques saisonnières, souvent perçues comme trop lentes par les communautés en urgence. Leur légitimité est contestée aux marges, là où les enclaves extractivistes résiduelles refusent de reconnaître leur souveraineté et où les flux migratoires climatiques introduisent des populations sans ancrage bioterritorial établi. Enfin, la tentation de la consolidation — fusionner des Assemblées pour gagner en efficacité — risque à chaque cycle de reproduire les logiques étatiques centralisatrices qu'elles prétendent avoir abolies.

## Variables influencées
- [[organisation_territoires]]
- [[gouvernance_institutions]]
- [[climat_environnement_global]]


## Relations
**Alliés :**
- [[amazonie_pacte_viva_eco_communalism]]
- [[archives_ouvertes_des_jurisprudences_communales_aojc_eco_communalism]]
- [[assemblees_cooperatives_regionales_eco_communalism]]
- [[assemblees_de_bassin_versant_eco_communalism]]
- [[brigades_de_restauration_ecologique_eco_communalism]]
- [[cercles_de_mediation_territoriale_intercommunautaire_eco_communalism]]
- [[collectifs_de_cartographie_ecologique_participative_eco_communalism]]
- [[collectifs_de_facilitateurs_deliberatifs_itinerants_eco_communalism]]
- [[collectifs_de_geo_observateurs_citoyens_eco_communalism]]
- [[collectifs_de_techniciens_sobres_eco_communalism]]
- [[confederation_bassins_vivants_eco_communalism]]
- [[confederation_communs_arc_septentrional_eco_communalism]]
- [[conseils_de_bassin_versant_eco_communalistes_eco_communalism]]
- [[consortium_africain_de_biotechnologies_sociales_eco_communalism]]
- [[consortium_amazonia_viva_eco_communalism]]
- [[cooperatives_d_habitat_regeneratif_eco_communalism]]
- [[cooperatives_semencieres_et_d_archives_agronomiques_eco_communalism]]
- [[factions_algorithmiques_pro_gouvernance_ia_legere_eco_communalism]]
- [[fraternites_ecospiritualistes_des_anciens_survivalistes_eco_communalism]]
- [[guildes_de_mediateurs_ecologiques_eco_communalism]]
- [[guildes_des_semenciers_itinerants_eco_communalism]]
- [[kalaallit_nunaat_bioterritoire_eco_communalism]]
- [[kalaallit_nunaat_sovereign_fund_eco_communalism]]
- [[les_veilleurs_du_fleuve_eco_communalism]]
- [[mouvement_des_archives_vivantes_du_savoir_partage_eco_communalism]]
- [[mutuelles_de_sante_territoriales_eco_communalism]]
- [[oracle_des_seuils_eco_communalism]]
- [[rede_paulista_de_distribuic_o_algor_tmica_eco_communalism]]
- [[reseau_des_assemblees_de_bassin_fennoscandien_eco_communalism]]
- [[reseau_mnemos_eco_communalism]]
- [[reseau_terrafond_bassins_eco_communalism]]
- [[reseaux_de_bibliotheques_archives_communautaires_eco_communalism]]
- [[reseaux_de_radio_communautaire_basse_consommation_eco_communalism]]
- [[reseaux_de_reconstruction_cooperative_inter_communautes_eco_communalism]]
- [[reseaux_de_troc_inter_cooperatives_et_marges_periurbaines_eco_communalism]]
- [[trame_bioclimatique_eco_communalism]]
- [[tresse_verte_corridor_eco_communalism]]
- [[tribunal_algorithmique_de_bruxelles_eco_communalism]]
- [[universite_nomade_eco_communalism]]
- [[zones_extractivistes_corridors_eco_communalism]]
**Opposants :**
- [[agro_conglomerats_des_enclaves_technologiques_eco_communalism]]
- [[cartels_de_narration_de_penurie_eco_communalism]]
- [[communautes_rurales_dissidentes_anti_cooperation_regionale_eco_communalism]]
- [[communs_secessionnistes_hors_coordination_eco_communalism]]
- [[conseils_territoriaux_opaques_sur_la_gestion_des_ressources_eco_communalism]]
- [[consortium_des_operateurs_d_ia_proprietaires_sur_les_trames_eco_communalism]]
- [[consortiums_industriels_de_l_eau_eco_communalism]]
- [[consortiums_logistiques_neo_industriels_des_terres_reconstruites_eco_communalism]]
- [[courant_isolationniste_anti_circulation_de_l_information_eco_communalism]]
- [[courant_techno_solutionniste_pro_re_globalisation_numerique_eco_communalism]]
- [[enclaves_extractivistes_et_etats_residuels_eco_communalism]]
- [[enclaves_extractivistes_residuelles_des_corridors_eco_communalism]]
- [[factions_autoritaires_de_controle_du_savoir_eco_communalism]]
- [[factions_autoritaires_locales_identitaires_exclusionnistes_eco_communalism]]
- [[factions_communautaires_refusant_le_partage_narratif_exterieur_eco_communalism]]
- [[factions_extractivistes_des_aquiferes_communs_eco_communalism]]
- [[factions_technophiles_de_la_geo_ingenierie_centralisee_eco_communalism]]
- [[fragments_d_etats_centraux_residuels_eco_communalism]]
- [[reseau_des_marches_noirs_de_donnees_extractivistes_eco_communalism]]
- [[reseaux_de_notables_communautaires_capturistes_eco_communalism]]

## Notes
Fiche enrichie depuis officialise_minimal le 2026-06-27.
