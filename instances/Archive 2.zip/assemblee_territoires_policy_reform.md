---
name: Conseil de Régulation des Territoires Intégrés (CRTI)
type: instance
slug: assemblee_territoires_policy_reform
entite: assemblee_territoires
scenario: policy_reform
statut: officialise_enrichi
localisation:
  zone: null
  lieu: null
  type_lieu: null
  note: transnationale_sans_ancrage
type_dans_scenario: institution

role_dans_scenario: >
  Pilier central de la gouvernance multi-niveaux d'Ourrassol 2098, le CRTI articule les décisions des blocs continentaux avec les réalités des entités infra-nationales — métropoles-nœuds, corridors énergétiques, zones de relogement climatique. Il n'est pas un parlement au sens classique : c'est une chambre de coordination algorithmiquement assistée, où les mandats territoriaux sont pondérés par des indices de pression systémique (densité de flux migratoires, stress énergétique, résilience infrastructurelle). Sa légitimité repose moins sur le suffrage que sur la reconnaissance technocratique de sa capacité à stabiliser les déséquilibres territoriaux en temps réel.

responsabilites: >
  Le CRTI alloue les droits de planification territoriale aux grandes zones de transition climatique, valide les corridors d'infrastructure distribuée (énergie, eau, mobilité), et arbitre les conflits de compétence entre gouvernances locales et instances continentales. Il pilote également les plans quinquennaux de rééquilibrage démographique en lien avec les agences de mobilité coordonnée.

impact_local: 3
impact_systemique_global: 5
variables_influencees:
    - organisation_territoires
    - gouvernance_institutions
    - demographie_mobilite_humaine
    - energie_ressources_critiques
    - climat_environnement_global

zone_geographique:
    - continentale
    - globale

zone_systemique:
    - gouvernance
    - infrastructure
    - énergie
    - société

alliances:
- agence_internationale_de_l_energie_reformatee_aier_policy_reform
- conseil_regulation_algorithmique_policy_reform
- consortium_technologique_de_planification_territoriale_policy_reform
- great_lakes_autonomous_compact_policy_reform
- office_integre_des_flux_migratoires_policy_reform
- pacifique_sud_resilience_network_policy_reform
- reseau_des_metropoles_n_uds_policy_reform
oppositions:
- collectifs_de_gouvernance_communautaire_decentralisee_policy_reform
- front_des_autonomies_territoriales_radicales_policy_reform
- front_souverainiste_des_blocs_non_signataires_policy_reform
type_relation_dominante: coopération

annee_debut: 2041
annee_fin: 

etat_temporel: actif
age_historique: dominant
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  Depuis son siège rotatif — alternant tous les sept ans entre Nairobi, Rotterdam et Chengdu — le CRTI ressemble moins à une assemblée qu'à une salle de contrôle géopolitique. Les délégués territoriaux n'y prononcent pas de discours : ils y valident des arbitrages produits par les systèmes de modélisation ATLAS, corrigent des pondérations, négocient des seuils. Certains y voient l'aboutissement rationnel de la gouvernance post-crise ; d'autres dénoncent une chambre d'entérinement habillée en démocratie. Ce qui est indéniable, c'est son emprise : aucun corridor d'infrastructure d'envergure continentale ne se construit sans son sceau, aucune zone de relogement climatique ne s'ouvre sans son calendrier.

signes_distinctifs: >
  Logo composé d'un réseau de points interconnectés sur fond de projection cartographique non-euclidienne, symbolisant la discontinuité des territoires intégrés. Les sessions plénières se tiennent dans des espaces hybrides physique-holographique, où les délégués distants apparaissent en présence augmentée à échelle réelle. Le bleu institutionnel du CRTI — dit 'bleu de transit' — est devenu une couleur-signal dans la signalétique des zones de planification coordonnée.

tensions_narratives: >
  La légitimité démocratique du CRTI est contestée en profondeur : ses mécanismes de pondération algorithmique favorisent structurellement les territoires à haute densité infrastructurelle, marginalisant de facto les zones périphériques qu'il prétend rééquilibrer. Une faction interne pousse à une réforme du mode de représentation, tandis que des blocs souverainistes régionaux menacent de créer des assemblées parallèles. Par ailleurs, la dépendance croissante aux modèles prédictifs ATLAS soulève une question existentielle : qui gouverne vraiment — les délégués, ou l'algorithme qu'ils ne comprennent plus tout à fait ?

date_creation: 2026-06-20
---

# Conseil de Régulation des Territoires Intégrés (CRTI)

## Rôle dans [[policy_reform]]
Pilier central de la gouvernance multi-niveaux d'Ourrassol 2098, le CRTI articule les décisions des blocs continentaux avec les réalités des entités infra-nationales — métropoles-nœuds, corridors énergétiques, zones de relogement climatique. Il n'est pas un parlement au sens classique : c'est une chambre de coordination algorithmiquement assistée, où les mandats territoriaux sont pondérés par des indices de pression systémique (densité de flux migratoires, stress énergétique, résilience infrastructurelle). Sa légitimité repose moins sur le suffrage que sur la reconnaissance technocratique de sa capacité à stabiliser les déséquilibres territoriaux en temps réel.

## Responsabilités
Le CRTI alloue les droits de planification territoriale aux grandes zones de transition climatique, valide les corridors d'infrastructure distribuée (énergie, eau, mobilité), et arbitre les conflits de compétence entre gouvernances locales et instances continentales. Il pilote également les plans quinquennaux de rééquilibrage démographique en lien avec les agences de mobilité coordonnée.

## Variables influencées
- [[organisation_territoires]]
- [[gouvernance_institutions]]
- [[demographie_mobilite_humaine]]
- [[energie_ressources_critiques]]
- [[climat_environnement_global]]


## Description journalistique
Depuis son siège rotatif — alternant tous les sept ans entre Nairobi, Rotterdam et Chengdu — le CRTI ressemble moins à une assemblée qu'à une salle de contrôle géopolitique. Les délégués territoriaux n'y prononcent pas de discours : ils y valident des arbitrages produits par les systèmes de modélisation ATLAS, corrigent des pondérations, négocient des seuils. Certains y voient l'aboutissement rationnel de la gouvernance post-crise ; d'autres dénoncent une chambre d'entérinement habillée en démocratie. Ce qui est indéniable, c'est son emprise : aucun corridor d'infrastructure d'envergure continentale ne se construit sans son sceau, aucune zone de relogement climatique ne s'ouvre sans son calendrier.

## Tensions narratives
La légitimité démocratique du CRTI est contestée en profondeur : ses mécanismes de pondération algorithmique favorisent structurellement les territoires à haute densité infrastructurelle, marginalisant de facto les zones périphériques qu'il prétend rééquilibrer. Une faction interne pousse à une réforme du mode de représentation, tandis que des blocs souverainistes régionaux menacent de créer des assemblées parallèles. Par ailleurs, la dépendance croissante aux modèles prédictifs ATLAS soulève une question existentielle : qui gouverne vraiment — les délégués, ou l'algorithme qu'ils ne comprennent plus tout à fait ?

## Relations
**Alliés :**
- [[agence_internationale_de_l_energie_reformatee_aier_policy_reform]]
- [[conseil_regulation_algorithmique_policy_reform]]
- [[consortium_technologique_de_planification_territoriale_policy_reform]]
- [[great_lakes_autonomous_compact_policy_reform]]
- [[office_integre_des_flux_migratoires_policy_reform]]
- [[pacifique_sud_resilience_network_policy_reform]]
- [[reseau_des_metropoles_n_uds_policy_reform]]
**Opposants :**
- [[collectifs_de_gouvernance_communautaire_decentralisee_policy_reform]]
- [[front_des_autonomies_territoriales_radicales_policy_reform]]
- [[front_souverainiste_des_blocs_non_signataires_policy_reform]]
