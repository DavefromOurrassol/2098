---
name: Enclaves Industrielles du Corridor Oural-Caspien
type: instance
slug: enclaves_industrielles_du_corridor_oural_caspien_breakdown
entite: enclaves_industrielles_du_corridor_oural_caspien
scenario: breakdown
localisation:
  zone: corridor_oural_caspien
  lieu: Corridor Oural-Caspien
  type_lieu: region
statut: officialise_enrichi
type_dans_scenario: organisation
role_dans_scenario: 'Dans le scénario breakdown, les Enclaves Industrielles du Corridor
  Oural-Caspien incarnent la persistance paradoxale d''une capacité productive lourde
  au cœur du délitement systémique : ni États, ni corporations transnationales, elles
  fonctionnent comme des cités-usines autarciques, produisant ce que plus personne
  d''autre dans la région ne peut fabriquer, et négociant leur survie au prix d''une
  neutralité armée constamment menacée par les factions en conflit autour du Bassin
  Caspien.'
responsabilites: Les Enclaves Industrielles du Corridor Oural-Caspien assurent la
  continuité de productions stratégiques — métallurgie lourde, traitement des hydrocarbures
  résiduels, fabrication de composants énergétiques — dans une zone où tout ordre
  étatique centralisé s'est effondré. Elles gèrent des flux de main-d'œuvre locale
  captive et des stocks de matières premières extraits de gisements hérités, en négociant
  directement avec les convois armés qui traversent le corridor. Leur survie repose
  sur la capacité à maintenir des infrastructures soviétiques reconverties sans appui
  logistique externe, en appliquant des logiques d'autarcie productive radicale.
impact_local: 5
impact_systemique_global: 3
variables_influencees:
- organisation_territoires
- systemes_productifs_travail
- energie_ressources_critiques
zone_geographique:
- régionale
zone_systemique:
- société
alliances:
- collectifs_de_reparation_energetique_breakdown
- conglometrat_sino_siberien_bohai_transit_breakdown
- consortium_energetique_oural_caspien_breakdown
- enclaves_technologiques_survivantes_breakdown
- factions_energetiques_heritieres_des_pactes_abs_breakdown
- front_techno_reconstructionniste_breakdown
- guilde_des_techniciens_nomades_breakdown
- reseaux_de_renseignement_informels_issus_de_l_ancienne_structure_militaire_eurasienne_breakdown
- vasil_orentchev_breakdown
oppositions:
- blocs_de_controle_des_couloirs_d_approvisionnement_strategiques_breakdown
- factions_para_etatiques_hydriques_breakdown
- milices_de_controle_territorial_breakdown
- seigneuries_logistiques_armees_breakdown
- seigneurs_de_guerre_agro_territoriaux_breakdown
type_relation_dominante: compétition
annee_debut: 2026
annee_fin: null
etat_temporel: actif
age_historique: émergent
generation: transition
injection:
  type: canonique
  annee_injection: null
  contexte_injection: null
  impact_sur_variables: null
  propagation:
    via_matrice: false
description_journalistique: 'Dans l''arc eurasien central ravagé par les guerres de
  ressources, les Enclaves du Corridor Oural-Caspien sont les dinosaures industriels
  qui refusent de mourir : des complexes métallurgiques et pétroliers fonctionnant
  encore à plein régime, alimentés par des réserves souterraines que personne n''a
  encore réussi à leur arracher. Leurs cheminées crachent une fumée visible depuis
  Orenbourg jusqu''à Aktaou, signal d''une capacité productive que tous les blocs
  armés de la région veulent contrôler — ou détruire. Vestiges résilients d''une autre
  ère, elles sont devenues l''enjeu central des négociations brutales entre milices,
  cartels énergétiques et fantômes d''États.'
signes_distinctifs: Des complexes industriels aux architecture soviétique massive,
  protégés par des milices ouvrières armées et signalés de loin par leurs torchères
  permanentes — derniers phares d'une production industrielle continue dans un corridor
  où tout le reste s'est tu. Leur monnaie d'échange n'est pas une devise mais du métal,
  du carburant et des pièces détachées.
tensions_narratives: 'Les Enclaves sont prisonnières de leur propre valeur : leur
  capacité productive attire convoitises, raids et tentatives d''intégration forcée
  par les blocs armés du Bassin Caspien, menaçant l''autonomie qui est pourtant la
  condition même de leur survie. En interne, la tension entre les techniciens héritiers
  du savoir-faire soviétique — vieillissants et irremplaçables — et les cohortes de
  travailleurs précaires recrutés de force dans les zones de déplacement crée une
  instabilité sociale permanente. Enfin, chaque accord de livraison avec un acteur
  extérieur risque de transformer l''enclave en vassale d''un seigneur de guerre plutôt
  qu''en nœud productif indépendant.'
date_creation: 2026-06-20
---

# Enclaves Industrielles du Corridor Oural-Caspien

## Rôle dans [[breakdown]]
Dans le scénario breakdown, les Enclaves Industrielles du Corridor Oural-Caspien incarnent la persistance paradoxale d'une capacité productive lourde au cœur du délitement systémique : ni États, ni corporations transnationales, elles fonctionnent comme des cités-usines autarciques, produisant ce que plus personne d'autre dans la région ne peut fabriquer, et négociant leur survie au prix d'une neutralité armée constamment menacée par les factions en conflit autour du Bassin Caspien.

## Responsabilités
Les Enclaves Industrielles du Corridor Oural-Caspien assurent la continuité de productions stratégiques — métallurgie lourde, traitement des hydrocarbures résiduels, fabrication de composants énergétiques — dans une zone où tout ordre étatique centralisé s'est effondré. Elles gèrent des flux de main-d'œuvre locale captive et des stocks de matières premières extraits de gisements hérités, en négociant directement avec les convois armés qui traversent le corridor. Leur survie repose sur la capacité à maintenir des infrastructures soviétiques reconverties sans appui logistique externe, en appliquant des logiques d'autarcie productive radicale.

## Description journalistique
Dans l'arc eurasien central ravagé par les guerres de ressources, les Enclaves du Corridor Oural-Caspien sont les dinosaures industriels qui refusent de mourir : des complexes métallurgiques et pétroliers fonctionnant encore à plein régime, alimentés par des réserves souterraines que personne n'a encore réussi à leur arracher. Leurs cheminées crachent une fumée visible depuis Orenbourg jusqu'à Aktaou, signal d'une capacité productive que tous les blocs armés de la région veulent contrôler — ou détruire. Vestiges résilients d'une autre ère, elles sont devenues l'enjeu central des négociations brutales entre milices, cartels énergétiques et fantômes d'États.

## Signes distinctifs
Des complexes industriels aux architecture soviétique massive, protégés par des milices ouvrières armées et signalés de loin par leurs torchères permanentes — derniers phares d'une production industrielle continue dans un corridor où tout le reste s'est tu. Leur monnaie d'échange n'est pas une devise mais du métal, du carburant et des pièces détachées.

## Tensions narratives
Les Enclaves sont prisonnières de leur propre valeur : leur capacité productive attire convoitises, raids et tentatives d'intégration forcée par les blocs armés du Bassin Caspien, menaçant l'autonomie qui est pourtant la condition même de leur survie. En interne, la tension entre les techniciens héritiers du savoir-faire soviétique — vieillissants et irremplaçables — et les cohortes de travailleurs précaires recrutés de force dans les zones de déplacement crée une instabilité sociale permanente. Enfin, chaque accord de livraison avec un acteur extérieur risque de transformer l'enclave en vassale d'un seigneur de guerre plutôt qu'en nœud productif indépendant.

## Variables influencées
- [[organisation_territoires]]
- [[systemes_productifs_travail]]
- [[energie_ressources_critiques]]


## Relations
**Alliés :**
- [[collectifs_de_reparation_energetique_breakdown]]
- [[conglometrat_sino_siberien_bohai_transit_breakdown]]
- [[consortium_energetique_oural_caspien_breakdown]]
- [[enclaves_technologiques_survivantes_breakdown]]
- [[factions_energetiques_heritieres_des_pactes_abs_breakdown]]
- [[front_techno_reconstructionniste_breakdown]]
- [[guilde_des_techniciens_nomades_breakdown]]
- [[reseaux_de_renseignement_informels_issus_de_l_ancienne_structure_militaire_eurasienne_breakdown]]
- [[vasil_orentchev_breakdown]]
**Opposants :**
- [[blocs_de_controle_des_couloirs_d_approvisionnement_strategiques_breakdown]]
- [[factions_para_etatiques_hydriques_breakdown]]
- [[milices_de_controle_territorial_breakdown]]
- [[seigneuries_logistiques_armees_breakdown]]
- [[seigneurs_de_guerre_agro_territoriaux_breakdown]]

## Notes
Fiche enrichie depuis officialise_minimal le 2026-06-27.
