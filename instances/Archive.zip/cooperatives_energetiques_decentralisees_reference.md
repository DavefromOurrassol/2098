---
name: Coopératives Énergétiques Décentralisées
type: instance
slug: cooperatives_energetiques_decentralisees_reference
entite: cooperatives_energetiques_decentralisees
scenario: reference
statut: officialise_minimal

type_dans_scenario: organisation

role_dans_scenario: >
  Dans le scénario, elles incarnent une forme de résilience énergétique décentralisée, potentiellement en tension ou en alliance avec les acteurs institutionnels et industriels du secteur.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - energie_ressources_critiques
  - organisation_territoires
  - systeme_economique_redistribution

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Coopératives Énergétiques Décentralisées

## Rôle dans [[reference]]
Dans le scénario, elles incarnent une forme de résilience énergétique décentralisée, potentiellement en tension ou en alliance avec les acteurs institutionnels et industriels du secteur.

## Variables influencées
- [[energie_ressources_critiques]]
- [[organisation_territoires]]
- [[systeme_economique_redistribution]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
