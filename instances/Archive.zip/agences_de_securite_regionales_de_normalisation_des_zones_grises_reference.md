---
name: Agences de Sécurité Régionales de Normalisation des Zones Grises
type: instance
slug: agences_de_securite_regionales_de_normalisation_des_zones_grises_reference
entite: agences_de_securite_regionales_de_normalisation_des_zones_grises
scenario: reference
statut: officialise_minimal

type_dans_scenario: organisation

role_dans_scenario: >
  Dans le scénario reference, elles incarnent le bras opérationnel de la normalisation des zones grises, traduisant des directives de gouvernance en protocoles de terrain applicables aux espaces hors-cadre.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - gouvernance_institutions
  - organisation_territoires
  - frontieres_du_systeme

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Agences de Sécurité Régionales de Normalisation des Zones Grises

## Rôle dans [[reference]]
Dans le scénario reference, elles incarnent le bras opérationnel de la normalisation des zones grises, traduisant des directives de gouvernance en protocoles de terrain applicables aux espaces hors-cadre.

## Variables influencées
- [[gouvernance_institutions]]
- [[organisation_territoires]]
- [[frontieres_du_systeme]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
