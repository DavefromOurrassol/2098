---
name: Enclaves de Données Propriétaires des Mégacorporations
type: instance
slug: enclaves_de_donnees_proprietaires_des_megacorporations_new_sustainability
entite: enclaves_de_donnees_proprietaires_des_megacorporations
scenario: new_sustainability
statut: officialise_minimal

type_dans_scenario: infrastructure

role_dans_scenario: >
  Dans le scénario new_sustainability, ces enclaves constituent des verrous sur des ressources informationnelles potentiellement cruciales pour la transition écologique, bloquant la circulation des données au nom de droits patrimoniaux hérités.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - technologie_information
  - gouvernance_institutions
  - frontieres_du_systeme

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Enclaves de Données Propriétaires des Mégacorporations

## Rôle dans [[new_sustainability]]
Dans le scénario new_sustainability, ces enclaves constituent des verrous sur des ressources informationnelles potentiellement cruciales pour la transition écologique, bloquant la circulation des données au nom de droits patrimoniaux hérités.

## Variables influencées
- [[technologie_information]]
- [[gouvernance_institutions]]
- [[frontieres_du_systeme]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
