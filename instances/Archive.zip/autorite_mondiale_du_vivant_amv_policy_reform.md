---
name: Autorité Mondiale du Vivant (AMV)
type: instance
slug: autorite_mondiale_du_vivant_amv_policy_reform
entite: autorite_mondiale_du_vivant_amv
scenario: policy_reform
statut: officialise_minimal

type_dans_scenario: institution

role_dans_scenario: >
  Dans le scénario policy_reform, l'AMV constitue un acteur central des débats sur la réforme des cadres normatifs encadrant le vivant, pesant sur les arbitrages entre exploitation, protection et transformation biotechnologique.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - gouvernance_institutions
  - sante_biotechnologies
  - climat_environnement_global

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Autorité Mondiale du Vivant (AMV)

## Rôle dans [[policy_reform]]
Dans le scénario policy_reform, l'AMV constitue un acteur central des débats sur la réforme des cadres normatifs encadrant le vivant, pesant sur les arbitrages entre exploitation, protection et transformation biotechnologique.

## Variables influencées
- [[gouvernance_institutions]]
- [[sante_biotechnologies]]
- [[climat_environnement_global]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
