---
name: Faction Conservatrice Pro-Actif Stratégique
type: instance
slug: faction_conservatrice_pro_actif_strategique_new_sustainability
entite: faction_conservatrice_pro_actif_strategique
scenario: new_sustainability
statut: officialise_minimal

type_dans_scenario: organisation

role_dans_scenario: >
  Faction de blocage ou de freinage au sein d'une organisation face aux pressions de transformation liées au scénario new_sustainability, défendant la valeur stratégique d'un actif existant.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - gouvernance_institutions
  - energie_ressources_critiques
  - systemes_productifs_travail

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Faction Conservatrice Pro-Actif Stratégique

## Rôle dans [[new_sustainability]]
Faction de blocage ou de freinage au sein d'une organisation face aux pressions de transformation liées au scénario new_sustainability, défendant la valeur stratégique d'un actif existant.

## Variables influencées
- [[gouvernance_institutions]]
- [[energie_ressources_critiques]]
- [[systemes_productifs_travail]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
