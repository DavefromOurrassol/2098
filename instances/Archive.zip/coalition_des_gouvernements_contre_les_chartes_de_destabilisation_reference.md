---
name: Coalition des Gouvernements Contre les Chartes de Déstabilisation
type: instance
slug: coalition_des_gouvernements_contre_les_chartes_de_destabilisation_reference
entite: coalition_des_gouvernements_contre_les_chartes_de_destabilisation
scenario: reference
statut: officialise_minimal

type_dans_scenario: organisation

role_dans_scenario: >
  Dans ce scénario, elle légitime juridiquement et diplomatiquement la répression des chartes concernées, en coordonnant des réponses étatiques collectives pour les neutraliser ou les interdire.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - gouvernance_institutions
  - geopolitique_conflits
  - frontieres_du_systeme

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Coalition des Gouvernements Contre les Chartes de Déstabilisation

## Rôle dans [[reference]]
Dans ce scénario, elle légitime juridiquement et diplomatiquement la répression des chartes concernées, en coordonnant des réponses étatiques collectives pour les neutraliser ou les interdire.

## Variables influencées
- [[gouvernance_institutions]]
- [[geopolitique_conflits]]
- [[frontieres_du_systeme]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
