---
name: Bloc des Nations Non-Alignées Résiduelles
type: instance
slug: bloc_des_nations_non_alignees_residuelles_fortress_world
entite: bloc_des_nations_non_alignees_residuelles
scenario: fortress_world
statut: officialise_minimal

type_dans_scenario: organisation

role_dans_scenario: >
  Fournissent un soutien de façade aux acteurs cherchant à contester l'ordre forteresse, sans s'y engager réellement — leur neutralité calculée les rend utiles comme caution symbolique sans risque assumé.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - geopolitique_conflits
  - gouvernance_institutions
  - frontieres_du_systeme

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Bloc des Nations Non-Alignées Résiduelles

## Rôle dans [[fortress_world]]
Fournissent un soutien de façade aux acteurs cherchant à contester l'ordre forteresse, sans s'y engager réellement — leur neutralité calculée les rend utiles comme caution symbolique sans risque assumé.

## Variables influencées
- [[geopolitique_conflits]]
- [[gouvernance_institutions]]
- [[frontieres_du_systeme]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
