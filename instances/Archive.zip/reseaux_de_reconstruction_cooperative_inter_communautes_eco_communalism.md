---
name: Réseaux de reconstruction coopérative inter-communautés
type: instance
slug: reseaux_de_reconstruction_cooperative_inter_communautes_eco_communalism
entite: reseaux_de_reconstruction_cooperative_inter_communautes
scenario: eco_communalism
statut: officialise_minimal

type_dans_scenario: réseau

role_dans_scenario: >
  Assure la cohésion opérationnelle entre communautés autonomes dans le scénario éco-communaliste, en facilitant les échanges matériels et les transferts de compétences nécessaires à la résilience collective.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - organisation_territoires
  - systeme_economique_redistribution
  - systemes_productifs_travail

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Réseaux de reconstruction coopérative inter-communautés

## Rôle dans [[eco_communalism]]
Assure la cohésion opérationnelle entre communautés autonomes dans le scénario éco-communaliste, en facilitant les échanges matériels et les transferts de compétences nécessaires à la résilience collective.

## Variables influencées
- [[organisation_territoires]]
- [[systeme_economique_redistribution]]
- [[systemes_productifs_travail]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
