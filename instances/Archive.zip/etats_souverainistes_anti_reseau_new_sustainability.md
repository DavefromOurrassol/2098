---
name: États Souverainistes Anti-Réseau
type: instance
slug: etats_souverainistes_anti_reseau_new_sustainability
entite: etats_souverainistes_anti_reseau
scenario: new_sustainability
statut: officialise_minimal

type_dans_scenario: institution

role_dans_scenario: >
  Opposants structurels à l'expansion du réseau dans le scénario new_sustainability, ils constituent un frein politique et juridique à la reconfiguration territoriale portée par les acteurs du réseau.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - gouvernance_institutions
  - organisation_territoires
  - geopolitique_conflits

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# États Souverainistes Anti-Réseau

## Rôle dans [[new_sustainability]]
Opposants structurels à l'expansion du réseau dans le scénario new_sustainability, ils constituent un frein politique et juridique à la reconfiguration territoriale portée par les acteurs du réseau.

## Variables influencées
- [[gouvernance_institutions]]
- [[organisation_territoires]]
- [[geopolitique_conflits]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
