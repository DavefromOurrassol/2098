---
name: Fonds Mondial pour la Transition Écosystémique (FMTE)
type: instance
slug: fonds_mondial_pour_la_transition_ecosystemique_fmte_policy_reform
entite: fonds_mondial_pour_la_transition_ecosystemique_fmte
scenario: policy_reform
statut: officialise_minimal

type_dans_scenario: institution

role_dans_scenario: >
  Dans le scénario policy_reform, le FMTE constitue un levier institutionnel central pour orienter ou bloquer les réformes politiques liées à la gouvernance environnementale et à l'allocation des fonds climatiques.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - gouvernance_institutions
  - climat_environnement_global
  - systeme_economique_redistribution

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Fonds Mondial pour la Transition Écosystémique (FMTE)

## Rôle dans [[policy_reform]]
Dans le scénario policy_reform, le FMTE constitue un levier institutionnel central pour orienter ou bloquer les réformes politiques liées à la gouvernance environnementale et à l'allocation des fonds climatiques.

## Variables influencées
- [[gouvernance_institutions]]
- [[climat_environnement_global]]
- [[systeme_economique_redistribution]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
