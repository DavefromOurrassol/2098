---
name: agences de sécurité intérieure des États forteresses
type: instance
slug: agences_de_securite_interieure_des_etats_forteresses_fortress_world
entite: agences_de_securite_interieure_des_etats_forteresses
scenario: fortress_world
statut: officialise_minimal

type_dans_scenario: institution

role_dans_scenario: >
  Acteurs institutionnels qui maintiennent l'ordre interne et l'étanchéité des frontières dans un monde fragmenté, au prix de libertés civiles fortement réduites.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - frontieres_du_systeme
  - gouvernance_institutions
  - demographie_mobilite_humaine

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# agences de sécurité intérieure des États forteresses

## Rôle dans [[fortress_world]]
Acteurs institutionnels qui maintiennent l'ordre interne et l'étanchéité des frontières dans un monde fragmenté, au prix de libertés civiles fortement réduites.

## Variables influencées
- [[frontieres_du_systeme]]
- [[gouvernance_institutions]]
- [[demographie_mobilite_humaine]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
