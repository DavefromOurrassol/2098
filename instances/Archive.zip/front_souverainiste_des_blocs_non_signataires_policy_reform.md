---
name: Front Souverainiste des Blocs Non-Signataires
type: instance
slug: front_souverainiste_des_blocs_non_signataires_policy_reform
entite: front_souverainiste_des_blocs_non_signataires
scenario: policy_reform
statut: officialise_minimal

type_dans_scenario: organisation

role_dans_scenario: >
  Dans le scénario policy_reform, ce front s'oppose aux réformes institutionnelles portées par les blocs signataires, bloquant ou contournant leur mise en œuvre sur les territoires non-alignés.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - gouvernance_institutions
  - geopolitique_conflits
  - organisation_territoires

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Front Souverainiste des Blocs Non-Signataires

## Rôle dans [[policy_reform]]
Dans le scénario policy_reform, ce front s'oppose aux réformes institutionnelles portées par les blocs signataires, bloquant ou contournant leur mise en œuvre sur les territoires non-alignés.

## Variables influencées
- [[gouvernance_institutions]]
- [[geopolitique_conflits]]
- [[organisation_territoires]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
