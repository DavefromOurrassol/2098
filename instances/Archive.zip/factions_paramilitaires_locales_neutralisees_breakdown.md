---
name: Factions Paramilitaires Locales Neutralisées
type: instance
slug: factions_paramilitaires_locales_neutralisees_breakdown
entite: factions_paramilitaires_locales_neutralisees
scenario: breakdown
statut: officialise_minimal

type_dans_scenario: organisation

role_dans_scenario: >
  Dans le scénario breakdown, ces factions représentent les acteurs de violence décentralisée que d'autres puissances — corporates, étatiques ou criminelles — cherchent à absorber ou éliminer pour consolider leur contrôle sur des territoires fragmentés.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - geopolitique_conflits
  - organisation_territoires
  - gouvernance_institutions

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Factions Paramilitaires Locales Neutralisées

## Rôle dans [[breakdown]]
Dans le scénario breakdown, ces factions représentent les acteurs de violence décentralisée que d'autres puissances — corporates, étatiques ou criminelles — cherchent à absorber ou éliminer pour consolider leur contrôle sur des territoires fragmentés.

## Variables influencées
- [[geopolitique_conflits]]
- [[organisation_territoires]]
- [[gouvernance_institutions]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
