---
name: Réseau des Métropoles-Nœuds
type: instance
slug: reseau_des_metropoles_n_uds_policy_reform
entite: reseau_des_metropoles_n_uds
scenario: policy_reform
statut: officialise_minimal

type_dans_scenario: réseau

role_dans_scenario: >
  Dans le scénario policy_reform, ce réseau agit comme levier ou obstacle à la réforme institutionnelle selon que ses intérêts métropolitains convergent ou divergent avec les réformes proposées.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - organisation_territoires
  - gouvernance_institutions
  - demographie_mobilite_humaine

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Réseau des Métropoles-Nœuds

## Rôle dans [[policy_reform]]
Dans le scénario policy_reform, ce réseau agit comme levier ou obstacle à la réforme institutionnelle selon que ses intérêts métropolitains convergent ou divergent avec les réformes proposées.

## Variables influencées
- [[organisation_territoires]]
- [[gouvernance_institutions]]
- [[demographie_mobilite_humaine]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
