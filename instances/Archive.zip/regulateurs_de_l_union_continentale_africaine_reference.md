---
name: Régulateurs de l'Union Continentale Africaine
type: instance
slug: regulateurs_de_l_union_continentale_africaine_reference
entite: regulateurs_de_l_union_continentale_africaine
scenario: reference
statut: officialise_minimal

type_dans_scenario: institution

role_dans_scenario: >
  Intervient comme acteur de régulation et de contrôle dans le scénario, potentiellement en tension ou en coopération avec d'autres entités soumises à son cadre réglementaire.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - gouvernance_institutions
  - organisation_territoires
  - geopolitique_conflits

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Régulateurs de l'Union Continentale Africaine

## Rôle dans [[reference]]
Intervient comme acteur de régulation et de contrôle dans le scénario, potentiellement en tension ou en coopération avec d'autres entités soumises à son cadre réglementaire.

## Variables influencées
- [[gouvernance_institutions]]
- [[organisation_territoires]]
- [[geopolitique_conflits]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
