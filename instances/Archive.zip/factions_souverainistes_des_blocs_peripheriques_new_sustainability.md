---
name: Factions Souverainistes des Blocs Périphériques
type: instance
slug: factions_souverainistes_des_blocs_peripheriques_new_sustainability
entite: factions_souverainistes_des_blocs_peripheriques
scenario: new_sustainability
statut: officialise_minimal

type_dans_scenario: organisation

role_dans_scenario: >
  Dans le scénario new_sustainability, ces factions contestent les modèles de transition écologique imposés par les centres hégémoniques, défendant le droit des périphéries à définir leurs propres trajectoires de durabilité.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - organisation_territoires
  - geopolitique_conflits
  - gouvernance_institutions

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Factions Souverainistes des Blocs Périphériques

## Rôle dans [[new_sustainability]]
Dans le scénario new_sustainability, ces factions contestent les modèles de transition écologique imposés par les centres hégémoniques, défendant le droit des périphéries à définir leurs propres trajectoires de durabilité.

## Variables influencées
- [[organisation_territoires]]
- [[geopolitique_conflits]]
- [[gouvernance_institutions]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
