---
name: Institutions Multilatérales Résiduelles
type: instance
slug: institutions_multilaterales_residuelles_fortress_world
entite: institutions_multilaterales_residuelles
scenario: fortress_world
statut: officialise_minimal

type_dans_scenario: institution

role_dans_scenario: >
  Dans fortress_world, elles tentent de maintenir un minimum de droit international et de coordination humanitaire entre des États-forteresses qui les ignorent ou les instrumentalisent selon leurs intérêts.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - gouvernance_institutions
  - demographie_mobilite_humaine
  - geopolitique_conflits

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Institutions Multilatérales Résiduelles

## Rôle dans [[fortress_world]]
Dans fortress_world, elles tentent de maintenir un minimum de droit international et de coordination humanitaire entre des États-forteresses qui les ignorent ou les instrumentalisent selon leurs intérêts.

## Variables influencées
- [[gouvernance_institutions]]
- [[demographie_mobilite_humaine]]
- [[geopolitique_conflits]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
