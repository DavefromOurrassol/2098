---
name: Fonds Souverain Arctique Scandinave
type: instance
slug: fonds_souverain_arctique_scandinave_reference
entite: fonds_souverain_arctique_scandinave
scenario: reference
statut: officialise_minimal

type_dans_scenario: institution

role_dans_scenario: >
  Acteur de référence pour le financement et la gouvernance des territoires arctiques, pesant sur les arbitrages entre exploitation ressourcière et conservation environnementale.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - energie_ressources_critiques
  - gouvernance_institutions
  - climat_environnement_global

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Fonds Souverain Arctique Scandinave

## Rôle dans [[reference]]
Acteur de référence pour le financement et la gouvernance des territoires arctiques, pesant sur les arbitrages entre exploitation ressourcière et conservation environnementale.

## Variables influencées
- [[energie_ressources_critiques]]
- [[gouvernance_institutions]]
- [[climat_environnement_global]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
