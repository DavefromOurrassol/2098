---
name: Bloc des Souverainistes Climatiques
type: instance
slug: bloc_des_souverainistes_climatiques_reference
entite: bloc_des_souverainistes_climatiques
scenario: reference
statut: officialise_minimal

type_dans_scenario: organisation

role_dans_scenario: >
  Dans ce scénario, le Bloc constitue un pôle d'opposition organisée aux décisions géo-ingénieristes centralisées, fragmentant la coordination climatique internationale et créant des zones de non-conformité.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - gouvernance_institutions
  - geopolitique_conflits
  - climat_environnement_global

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Bloc des Souverainistes Climatiques

## Rôle dans [[reference]]
Dans ce scénario, le Bloc constitue un pôle d'opposition organisée aux décisions géo-ingénieristes centralisées, fragmentant la coordination climatique internationale et créant des zones de non-conformité.

## Variables influencées
- [[gouvernance_institutions]]
- [[geopolitique_conflits]]
- [[climat_environnement_global]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
