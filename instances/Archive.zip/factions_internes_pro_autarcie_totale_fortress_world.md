---
name: Factions Internes Pro-Autarcie Totale
type: instance
slug: factions_internes_pro_autarcie_totale_fortress_world
entite: factions_internes_pro_autarcie_totale
scenario: fortress_world
statut: officialise_minimal

type_dans_scenario: autre

role_dans_scenario: >
  Exercent une pression centrifuge sur les gouvernances du scénario fortress_world, poussant les États-forteresses vers une autarcie intégrale au détriment de toute coopération résiduelle.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - frontieres_du_systeme
  - gouvernance_institutions
  - systeme_economique_redistribution

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Factions Internes Pro-Autarcie Totale

## Rôle dans [[fortress_world]]
Exercent une pression centrifuge sur les gouvernances du scénario fortress_world, poussant les États-forteresses vers une autarcie intégrale au détriment de toute coopération résiduelle.

## Variables influencées
- [[frontieres_du_systeme]]
- [[gouvernance_institutions]]
- [[systeme_economique_redistribution]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
