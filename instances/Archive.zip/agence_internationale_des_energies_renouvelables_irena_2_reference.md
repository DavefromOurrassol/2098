---
name: Agence Internationale des Énergies Renouvelables (IRENA-2)
type: instance
slug: agence_internationale_des_energies_renouvelables_irena_2_reference
entite: agence_internationale_des_energies_renouvelables_irena_2
scenario: reference
statut: officialise_minimal

type_dans_scenario: institution

role_dans_scenario: >
  Sert de référence normative et de cadre de coordination multilatérale pour les décisions énergétiques globales dans ce scénario.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - energie_ressources_critiques
  - gouvernance_institutions
  - geopolitique_conflits

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Agence Internationale des Énergies Renouvelables (IRENA-2)

## Rôle dans [[reference]]
Sert de référence normative et de cadre de coordination multilatérale pour les décisions énergétiques globales dans ce scénario.

## Variables influencées
- [[energie_ressources_critiques]]
- [[gouvernance_institutions]]
- [[geopolitique_conflits]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
