---
name: Front Souverainiste de l'Information Régionale
type: instance
slug: front_souverainiste_de_l_information_regionale_policy_reform
entite: front_souverainiste_de_l_information_regionale
scenario: policy_reform
statut: officialise_minimal

type_dans_scenario: organisation

role_dans_scenario: >
  Dans le scénario policy_reform, représente une force de pression régionaliste cherchant à inscrire la souveraineté informationnelle territoriale dans les réformes de gouvernance des médias et des données.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - technologie_information
  - gouvernance_institutions
  - organisation_territoires

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Front Souverainiste de l'Information Régionale

## Rôle dans [[policy_reform]]
Dans le scénario policy_reform, représente une force de pression régionaliste cherchant à inscrire la souveraineté informationnelle territoriale dans les réformes de gouvernance des médias et des données.

## Variables influencées
- [[technologie_information]]
- [[gouvernance_institutions]]
- [[organisation_territoires]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
