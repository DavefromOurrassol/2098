---
name: Réseaux de médecine traditionnelle augmentée
type: instance
slug: reseaux_de_medecine_traditionnelle_augmentee_reference
entite: reseaux_de_medecine_traditionnelle_augmentee
scenario: reference
statut: officialise_minimal

type_dans_scenario: réseau

role_dans_scenario: >
  Dans ce scénario, constituent un acteur alternatif de la santé, potentiellement en tension ou en coopération avec les institutions médicales dominantes selon les territoires.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - sante_biotechnologies
  - valeurs_culture_tempo_sociale
  - organisation_territoires

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Réseaux de médecine traditionnelle augmentée

## Rôle dans [[reference]]
Dans ce scénario, constituent un acteur alternatif de la santé, potentiellement en tension ou en coopération avec les institutions médicales dominantes selon les territoires.

## Variables influencées
- [[sante_biotechnologies]]
- [[valeurs_culture_tempo_sociale]]
- [[organisation_territoires]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
