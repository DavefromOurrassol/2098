---
name: Gouvernements de Forteresse Anti-Nairobi
type: instance
slug: gouvernements_de_forteresse_anti_nairobi_breakdown
entite: gouvernements_de_forteresse_anti_nairobi
scenario: breakdown
statut: officialise_minimal

type_dans_scenario: organisation

role_dans_scenario: >
  Bloc de résistance institutionnelle qui fragmente l'ordre géopolitique en rejetant les cadres multilatéraux issus de Nairobi, accentuant l'effondrement de la coopération internationale.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - gouvernance_institutions
  - geopolitique_conflits
  - frontieres_du_systeme

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Gouvernements de Forteresse Anti-Nairobi

## Rôle dans [[breakdown]]
Bloc de résistance institutionnelle qui fragmente l'ordre géopolitique en rejetant les cadres multilatéraux issus de Nairobi, accentuant l'effondrement de la coopération internationale.

## Variables influencées
- [[gouvernance_institutions]]
- [[geopolitique_conflits]]
- [[frontieres_du_systeme]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
