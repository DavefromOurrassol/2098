---
name: Réseau des Bio-Communs Régionaux
type: instance
slug: reseau_des_bio_communs_regionaux_new_sustainability
entite: reseau_des_bio_communs_regionaux
scenario: new_sustainability
statut: officialise_minimal

type_dans_scenario: réseau

role_dans_scenario: >
  Dans le scénario new_sustainability, constitue l'une des infrastructures de base de la transition : ancrage territorial des pratiques durables, résistance aux logiques de privatisation du vivant.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - organisation_territoires
  - climat_environnement_global
  - systeme_economique_redistribution

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Réseau des Bio-Communs Régionaux

## Rôle dans [[new_sustainability]]
Dans le scénario new_sustainability, constitue l'une des infrastructures de base de la transition : ancrage territorial des pratiques durables, résistance aux logiques de privatisation du vivant.

## Variables influencées
- [[organisation_territoires]]
- [[climat_environnement_global]]
- [[systeme_economique_redistribution]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
