---
name: Corps des Inspecteurs de Conformité Inter-Blocs
type: instance
slug: corps_des_inspecteurs_de_conformite_inter_blocs_fortress_world
entite: corps_des_inspecteurs_de_conformite_inter_blocs
scenario: fortress_world
statut: officialise_minimal

type_dans_scenario: institution

role_dans_scenario: >
  Contrôle la conformité des échanges entre blocs dans le scénario fortress_world, agissant comme verrou institutionnel contre les flux illicites ou non-autorisés.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - gouvernance_institutions
  - frontieres_du_systeme
  - geopolitique_conflits

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Corps des Inspecteurs de Conformité Inter-Blocs

## Rôle dans [[fortress_world]]
Contrôle la conformité des échanges entre blocs dans le scénario fortress_world, agissant comme verrou institutionnel contre les flux illicites ou non-autorisés.

## Variables influencées
- [[gouvernance_institutions]]
- [[frontieres_du_systeme]]
- [[geopolitique_conflits]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
