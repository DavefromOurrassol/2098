---
name: Opérateurs de Fusion Énergétique Régionaux
type: instance
slug: operateurs_de_fusion_energetique_regionaux_new_sustainability
entite: operateurs_de_fusion_energetique_regionaux
scenario: new_sustainability
statut: officialise_minimal

type_dans_scenario: entreprise

role_dans_scenario: >
  Acteurs clés de la transition énergétique dans le scénario new_sustainability, ils incarnent le nouveau tissu productif énergétique régionalisé et ses tensions avec les logiques de gouvernance centralisée ou de marché global.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - energie_ressources_critiques
  - organisation_territoires
  - systemes_productifs_travail

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Opérateurs de Fusion Énergétique Régionaux

## Rôle dans [[new_sustainability]]
Acteurs clés de la transition énergétique dans le scénario new_sustainability, ils incarnent le nouveau tissu productif énergétique régionalisé et ses tensions avec les logiques de gouvernance centralisée ou de marché global.

## Variables influencées
- [[energie_ressources_critiques]]
- [[organisation_territoires]]
- [[systemes_productifs_travail]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
