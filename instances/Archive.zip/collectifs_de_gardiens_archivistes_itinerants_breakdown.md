---
name: Collectifs de Gardiens-Archivistes Itinérants
type: instance
slug: collectifs_de_gardiens_archivistes_itinerants_breakdown
entite: collectifs_de_gardiens_archivistes_itinerants
scenario: breakdown
statut: officialise_minimal

type_dans_scenario: réseau

role_dans_scenario: >
  Dans un scénario de breakdown, ces collectifs constituent l'un des rares vecteurs de continuité culturelle et informationnelle, palliant l'effondrement des systèmes centralisés de stockage et de diffusion du savoir.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - technologie_information
  - valeurs_culture_tempo_sociale
  - demographie_mobilite_humaine

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Collectifs de Gardiens-Archivistes Itinérants

## Rôle dans [[breakdown]]
Dans un scénario de breakdown, ces collectifs constituent l'un des rares vecteurs de continuité culturelle et informationnelle, palliant l'effondrement des systèmes centralisés de stockage et de diffusion du savoir.

## Variables influencées
- [[technologie_information]]
- [[valeurs_culture_tempo_sociale]]
- [[demographie_mobilite_humaine]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
