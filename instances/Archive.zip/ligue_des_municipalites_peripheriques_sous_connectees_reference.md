---
name: Ligue des Municipalités Périphériques Sous-Connectées
type: instance
slug: ligue_des_municipalites_peripheriques_sous_connectees_reference
entite: ligue_des_municipalites_peripheriques_sous_connectees
scenario: reference
statut: officialise_minimal

type_dans_scenario: institution

role_dans_scenario: >
  Dans ce scénario, elle représente la pression collective des zones périphériques face aux déséquilibres de connectivité, agissant comme contrepoids institutionnel aux logiques centralisatrices.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - organisation_territoires
  - technologie_information
  - gouvernance_institutions

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Ligue des Municipalités Périphériques Sous-Connectées

## Rôle dans [[reference]]
Dans ce scénario, elle représente la pression collective des zones périphériques face aux déséquilibres de connectivité, agissant comme contrepoids institutionnel aux logiques centralisatrices.

## Variables influencées
- [[organisation_territoires]]
- [[technologie_information]]
- [[gouvernance_institutions]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
