---
name: Enclaves Industrielles du Corridor Oural-Caspien
type: instance
slug: enclaves_industrielles_du_corridor_oural_caspien_breakdown
entite: enclaves_industrielles_du_corridor_oural_caspien
scenario: breakdown
statut: officialise_minimal

type_dans_scenario: organisation

role_dans_scenario: >
  Dans le scénario breakdown, représentent des îlots de capacité productive persistante au milieu du délitement systémique, fonctionnant en dehors des réseaux globaux effondrés.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - organisation_territoires
  - systemes_productifs_travail
  - energie_ressources_critiques

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Enclaves Industrielles du Corridor Oural-Caspien

## Rôle dans [[breakdown]]
Dans le scénario breakdown, représentent des îlots de capacité productive persistante au milieu du délitement systémique, fonctionnant en dehors des réseaux globaux effondrés.

## Variables influencées
- [[organisation_territoires]]
- [[systemes_productifs_travail]]
- [[energie_ressources_critiques]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
