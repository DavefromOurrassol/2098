---
name: Enclaves Extractivistes Résiduelles des Corridors
type: instance
slug: enclaves_extractivistes_residuelles_des_corridors_eco_communalism
entite: enclaves_extractivistes_residuelles_des_corridors
scenario: eco_communalism
statut: officialise_minimal

type_dans_scenario: organisation

role_dans_scenario: >
  Exercent une pression antagoniste sur les corridors écologiques en tentant de les monétiser, représentant la persistance d'une logique marchande extractive dans un monde majoritairement post-croissanciste.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - organisation_territoires
  - energie_ressources_critiques
  - frontieres_du_systeme

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Enclaves Extractivistes Résiduelles des Corridors

## Rôle dans [[eco_communalism]]
Exercent une pression antagoniste sur les corridors écologiques en tentant de les monétiser, représentant la persistance d'une logique marchande extractive dans un monde majoritairement post-croissanciste.

## Variables influencées
- [[organisation_territoires]]
- [[energie_ressources_critiques]]
- [[frontieres_du_systeme]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
