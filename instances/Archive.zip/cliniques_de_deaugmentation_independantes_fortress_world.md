---
name: Cliniques de Déaugmentation Indépendantes
type: instance
slug: cliniques_de_deaugmentation_independantes_fortress_world
entite: cliniques_de_deaugmentation_independantes
scenario: fortress_world
statut: officialise_minimal

type_dans_scenario: réseau

role_dans_scenario: >
  Dans un monde forteresse où l'accès aux technologies d'augmentation est stratifié et contrôlé, ces cliniques offrent une voie de sortie ou de survie pour ceux qui ne peuvent plus entretenir, justifier ou dissimuler leurs implants.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - sante_biotechnologies
  - organisation_territoires
  - demographie_mobilite_humaine

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Cliniques de Déaugmentation Indépendantes

## Rôle dans [[fortress_world]]
Dans un monde forteresse où l'accès aux technologies d'augmentation est stratifié et contrôlé, ces cliniques offrent une voie de sortie ou de survie pour ceux qui ne peuvent plus entretenir, justifier ou dissimuler leurs implants.

## Variables influencées
- [[sante_biotechnologies]]
- [[organisation_territoires]]
- [[demographie_mobilite_humaine]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
