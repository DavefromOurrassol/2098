---
name: Plateformes Centralisées de Réagrégation Globale
type: instance
slug: plateformes_centralisees_de_reagregation_globale_eco_communalism
entite: plateformes_centralisees_de_reagregation_globale
scenario: eco_communalism
statut: officialise_minimal

type_dans_scenario: système

role_dans_scenario: >
  Dans le scénario eco_communalism, elles représentent la tension persistante entre la logique de centralisation globale et les dynamiques de réappropriation locale et communautaire des communs.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - technologie_information
  - organisation_territoires
  - frontieres_du_systeme

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Plateformes Centralisées de Réagrégation Globale

## Rôle dans [[eco_communalism]]
Dans le scénario eco_communalism, elles représentent la tension persistante entre la logique de centralisation globale et les dynamiques de réappropriation locale et communautaire des communs.

## Variables influencées
- [[technologie_information]]
- [[organisation_territoires]]
- [[frontieres_du_systeme]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
