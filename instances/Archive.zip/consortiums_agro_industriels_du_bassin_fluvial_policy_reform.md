---
name: Consortiums Agro-Industriels du Bassin Fluvial
type: instance
slug: consortiums_agro_industriels_du_bassin_fluvial_policy_reform
entite: consortiums_agro_industriels_du_bassin_fluvial
scenario: policy_reform
statut: officialise_minimal

type_dans_scenario: entreprise

role_dans_scenario: >
  Dans le scénario policy_reform, ces consortiums figurent parmi les parties prenantes dont les lobbies pèsent sur les réformes réglementaires, notamment en matière d'usage des sols, de droits sur l'eau et de normes de production.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - systemes_productifs_travail
  - climat_environnement_global
  - organisation_territoires

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Consortiums Agro-Industriels du Bassin Fluvial

## Rôle dans [[policy_reform]]
Dans le scénario policy_reform, ces consortiums figurent parmi les parties prenantes dont les lobbies pèsent sur les réformes réglementaires, notamment en matière d'usage des sols, de droits sur l'eau et de normes de production.

## Variables influencées
- [[systemes_productifs_travail]]
- [[climat_environnement_global]]
- [[organisation_territoires]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
