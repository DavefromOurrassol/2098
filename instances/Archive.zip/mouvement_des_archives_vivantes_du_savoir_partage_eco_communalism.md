---
name: Mouvement des Archives Vivantes du Savoir Partagé
type: instance
slug: mouvement_des_archives_vivantes_du_savoir_partage_eco_communalism
entite: mouvement_des_archives_vivantes_du_savoir_partage
scenario: eco_communalism
statut: officialise_minimal

type_dans_scenario: réseau

role_dans_scenario: >
  Assure la transmission et l'accessibilité des connaissances locales entre communautés dans un scénario de repli territorial et de autonomie collective.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - technologie_information
  - valeurs_culture_tempo_sociale
  - organisation_territoires

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Mouvement des Archives Vivantes du Savoir Partagé

## Rôle dans [[eco_communalism]]
Assure la transmission et l'accessibilité des connaissances locales entre communautés dans un scénario de repli territorial et de autonomie collective.

## Variables influencées
- [[technologie_information]]
- [[valeurs_culture_tempo_sociale]]
- [[organisation_territoires]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
