---
name: Réseau des Coopératives Agro-Sahéliennes
type: instance
slug: reseau_des_cooperatives_agro_saheliennes_reference
entite: reseau_des_cooperatives_agro_saheliennes
scenario: reference
statut: officialise_minimal

type_dans_scenario: réseau

role_dans_scenario: >
  Dans le scénario de référence, ce réseau incarne une alternative d'organisation productive territoriale ancrée dans les réalités sahéliennes de 2098, potentiellement en tension avec des acteurs industriels ou institutionnels.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - systemes_productifs_travail
  - organisation_territoires
  - climat_environnement_global

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Réseau des Coopératives Agro-Sahéliennes

## Rôle dans [[reference]]
Dans le scénario de référence, ce réseau incarne une alternative d'organisation productive territoriale ancrée dans les réalités sahéliennes de 2098, potentiellement en tension avec des acteurs industriels ou institutionnels.

## Variables influencées
- [[systemes_productifs_travail]]
- [[organisation_territoires]]
- [[climat_environnement_global]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
