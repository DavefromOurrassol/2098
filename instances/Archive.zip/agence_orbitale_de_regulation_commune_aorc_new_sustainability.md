---
name: Agence Orbitale de Régulation Commune (AORC)
type: instance
slug: agence_orbitale_de_regulation_commune_aorc_new_sustainability
entite: agence_orbitale_de_regulation_commune_aorc
scenario: new_sustainability
statut: officialise_minimal

type_dans_scenario: institution

role_dans_scenario: >
  Dans le scénario new_sustainability, l'AORC encadre l'exploitation des ressources spatiales et la gestion des débris orbitaux, jouant un rôle clé dans l'équilibre entre compétition géopolitique et coopération environnementale à l'échelle planétaire.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - gouvernance_institutions
  - energie_ressources_critiques
  - geopolitique_conflits

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Agence Orbitale de Régulation Commune (AORC)

## Rôle dans [[new_sustainability]]
Dans le scénario new_sustainability, l'AORC encadre l'exploitation des ressources spatiales et la gestion des débris orbitaux, jouant un rôle clé dans l'équilibre entre compétition géopolitique et coopération environnementale à l'échelle planétaire.

## Variables influencées
- [[gouvernance_institutions]]
- [[energie_ressources_critiques]]
- [[geopolitique_conflits]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
