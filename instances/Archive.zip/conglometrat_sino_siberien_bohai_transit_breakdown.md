---
name: Conglométrat sino-sibérien Bohai Transit
type: instance
slug: conglometrat_sino_siberien_bohai_transit_breakdown
entite: conglometrat_sino_siberien_bohai_transit
scenario: breakdown
statut: officialise_minimal

type_dans_scenario: entreprise

role_dans_scenario: >
  Dans le scénario breakdown, Bohai Transit représente l'un des rares opérateurs de flux encore fonctionnels lorsque les chaînes d'approvisionnement globales se fragmentent — à la fois pivot critique et point de tension géopolitique.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - energie_ressources_critiques
  - organisation_territoires
  - geopolitique_conflits

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Conglométrat sino-sibérien Bohai Transit

## Rôle dans [[breakdown]]
Dans le scénario breakdown, Bohai Transit représente l'un des rares opérateurs de flux encore fonctionnels lorsque les chaînes d'approvisionnement globales se fragmentent — à la fois pivot critique et point de tension géopolitique.

## Variables influencées
- [[energie_ressources_critiques]]
- [[organisation_territoires]]
- [[geopolitique_conflits]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
