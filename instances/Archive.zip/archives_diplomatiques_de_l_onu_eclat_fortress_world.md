---
name: Archives Diplomatiques de l'ONU-Éclat
type: instance
slug: archives_diplomatiques_de_l_onu_eclat_fortress_world
entite: archives_diplomatiques_de_l_onu_eclat
scenario: fortress_world
statut: officialise_minimal

type_dans_scenario: infrastructure

role_dans_scenario: >
  Dans le scénario fortress_world, constitue un point de référence contesté pour légitimer ou invalider des revendications territoriales et des droits d'accès entre blocs fortifiés rivaux.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - gouvernance_institutions
  - geopolitique_conflits
  - organisation_territoires

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Archives Diplomatiques de l'ONU-Éclat

## Rôle dans [[fortress_world]]
Dans le scénario fortress_world, constitue un point de référence contesté pour légitimer ou invalider des revendications territoriales et des droits d'accès entre blocs fortifiés rivaux.

## Variables influencées
- [[gouvernance_institutions]]
- [[geopolitique_conflits]]
- [[organisation_territoires]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
