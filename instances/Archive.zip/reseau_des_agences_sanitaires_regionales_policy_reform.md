---
name: Réseau des Agences Sanitaires Régionales
type: instance
slug: reseau_des_agences_sanitaires_regionales_policy_reform
entite: reseau_des_agences_sanitaires_regionales
scenario: policy_reform
statut: officialise_minimal

type_dans_scenario: réseau

role_dans_scenario: >
  Acteur clé dans la négociation et l'application des réformes de santé publique, il peut soutenir ou freiner les changements selon l'alignement des agences membres avec les nouvelles orientations politiques.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - sante_biotechnologies
  - gouvernance_institutions
  - organisation_territoires

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Réseau des Agences Sanitaires Régionales

## Rôle dans [[policy_reform]]
Acteur clé dans la négociation et l'application des réformes de santé publique, il peut soutenir ou freiner les changements selon l'alignement des agences membres avec les nouvelles orientations politiques.

## Variables influencées
- [[sante_biotechnologies]]
- [[gouvernance_institutions]]
- [[organisation_territoires]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
