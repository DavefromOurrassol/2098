---
name: Fonds Souverains de la Ceinture Financière Pacifique
type: instance
slug: fonds_souverains_de_la_ceinture_financiere_pacifique_reference
entite: fonds_souverains_de_la_ceinture_financiere_pacifique
scenario: reference
statut: officialise_minimal

type_dans_scenario: institution

role_dans_scenario: >
  Acteur financier structurant du scénario reference, capable de peser sur les équilibres économiques mondiaux via le contrôle de capitaux publics massifs.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - systeme_economique_redistribution
  - geopolitique_conflits
  - gouvernance_institutions

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Fonds Souverains de la Ceinture Financière Pacifique

## Rôle dans [[reference]]
Acteur financier structurant du scénario reference, capable de peser sur les équilibres économiques mondiaux via le contrôle de capitaux publics massifs.

## Variables influencées
- [[systeme_economique_redistribution]]
- [[geopolitique_conflits]]
- [[gouvernance_institutions]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
