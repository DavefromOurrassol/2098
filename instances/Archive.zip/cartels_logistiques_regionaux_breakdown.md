---
name: Cartels Logistiques Régionaux
type: instance
slug: cartels_logistiques_regionaux_breakdown
entite: cartels_logistiques_regionaux
scenario: breakdown
statut: officialise_minimal

type_dans_scenario: entreprise

role_dans_scenario: >
  Dans un scénario de breakdown, elles comblent le vide laissé par l'effondrement des chaînes d'approvisionnement centralisées, devenant des acteurs de pouvoir incontournables mais fragmentant davantage la cohérence territoriale.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - organisation_territoires
  - energie_ressources_critiques
  - gouvernance_institutions

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Cartels Logistiques Régionaux

## Rôle dans [[breakdown]]
Dans un scénario de breakdown, elles comblent le vide laissé par l'effondrement des chaînes d'approvisionnement centralisées, devenant des acteurs de pouvoir incontournables mais fragmentant davantage la cohérence territoriale.

## Variables influencées
- [[organisation_territoires]]
- [[energie_ressources_critiques]]
- [[gouvernance_institutions]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
