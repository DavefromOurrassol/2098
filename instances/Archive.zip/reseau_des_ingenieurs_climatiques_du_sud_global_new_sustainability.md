---
name: Réseau des Ingénieurs Climatiques du Sud Global
type: instance
slug: reseau_des_ingenieurs_climatiques_du_sud_global_new_sustainability
entite: reseau_des_ingenieurs_climatiques_du_sud_global
scenario: new_sustainability
statut: officialise_minimal

type_dans_scenario: réseau

role_dans_scenario: >
  Acteur clé dans la mise en œuvre et la négociation des grandes interventions climatiques, revendiquant une expertise et une souveraineté technique face aux institutions du Nord.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - climat_environnement_global
  - gouvernance_institutions
  - geopolitique_conflits

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Réseau des Ingénieurs Climatiques du Sud Global

## Rôle dans [[new_sustainability]]
Acteur clé dans la mise en œuvre et la négociation des grandes interventions climatiques, revendiquant une expertise et une souveraineté technique face aux institutions du Nord.

## Variables influencées
- [[climat_environnement_global]]
- [[gouvernance_institutions]]
- [[geopolitique_conflits]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
