---
name: Front Résilient Pro-Système
type: instance
slug: front_resilient_pro_systeme_fortress_world
entite: front_resilient_pro_systeme
scenario: fortress_world
statut: officialise_minimal

type_dans_scenario: organisation

role_dans_scenario: >
  Dans le scénario fortress_world, agit comme force de légitimation des structures d'enclavement et de contrôle, en mobilisant les populations autour d'un discours de résilience compatible avec l'ordre établi.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - gouvernance_institutions
  - valeurs_culture_tempo_sociale
  - frontieres_du_systeme

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Front Résilient Pro-Système

## Rôle dans [[fortress_world]]
Dans le scénario fortress_world, agit comme force de légitimation des structures d'enclavement et de contrôle, en mobilisant les populations autour d'un discours de résilience compatible avec l'ordre établi.

## Variables influencées
- [[gouvernance_institutions]]
- [[valeurs_culture_tempo_sociale]]
- [[frontieres_du_systeme]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
