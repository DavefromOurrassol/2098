---
name: Réseaux de financement gris issus d'anciens blocs militaires
type: instance
slug: reseaux_de_financement_gris_issus_d_anciens_blocs_militaires_reference
entite: reseaux_de_financement_gris_issus_d_anciens_blocs_militaires
scenario: reference
statut: officialise_minimal

type_dans_scenario: réseau

role_dans_scenario: >
  Fournissent des ressources financières hors-traçabilité à des acteurs du scénario, maintenant des dynamiques de pouvoir parallèles aux institutions officielles.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - geopolitique_conflits
  - systeme_economique_redistribution
  - gouvernance_institutions

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Réseaux de financement gris issus d'anciens blocs militaires

## Rôle dans [[reference]]
Fournissent des ressources financières hors-traçabilité à des acteurs du scénario, maintenant des dynamiques de pouvoir parallèles aux institutions officielles.

## Variables influencées
- [[geopolitique_conflits]]
- [[systeme_economique_redistribution]]
- [[gouvernance_institutions]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
