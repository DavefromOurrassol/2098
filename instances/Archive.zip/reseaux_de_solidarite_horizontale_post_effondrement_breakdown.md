---
name: Réseaux de solidarité horizontale post-effondrement
type: instance
slug: reseaux_de_solidarite_horizontale_post_effondrement_breakdown
entite: reseaux_de_solidarite_horizontale_post_effondrement
scenario: breakdown
statut: officialise_minimal

type_dans_scenario: réseau

role_dans_scenario: >
  Dans le scénario breakdown, ils constituent une des réponses adaptatives au délitement des systèmes étatiques et marchands, incarnant une recomposition sociale par le bas.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - organisation_territoires
  - gouvernance_institutions
  - valeurs_culture_tempo_sociale

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Réseaux de solidarité horizontale post-effondrement

## Rôle dans [[breakdown]]
Dans le scénario breakdown, ils constituent une des réponses adaptatives au délitement des systèmes étatiques et marchands, incarnant une recomposition sociale par le bas.

## Variables influencées
- [[organisation_territoires]]
- [[gouvernance_institutions]]
- [[valeurs_culture_tempo_sociale]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
