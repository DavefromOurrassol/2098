---
name: Coalition des Semences Libres
type: instance
slug: coalition_des_semences_libres_policy_reform
entite: coalition_des_semences_libres
scenario: policy_reform
statut: officialise_minimal

type_dans_scenario: organisation

role_dans_scenario: >
  Dans ce scénario de réforme politique, la Coalition pousse pour une législation protégeant les communs semenciers face aux intérêts des grands groupes agro-industriels.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - sante_biotechnologies
  - gouvernance_institutions
  - systemes_productifs_travail

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Coalition des Semences Libres

## Rôle dans [[policy_reform]]
Dans ce scénario de réforme politique, la Coalition pousse pour une législation protégeant les communs semenciers face aux intérêts des grands groupes agro-industriels.

## Variables influencées
- [[sante_biotechnologies]]
- [[gouvernance_institutions]]
- [[systemes_productifs_travail]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
