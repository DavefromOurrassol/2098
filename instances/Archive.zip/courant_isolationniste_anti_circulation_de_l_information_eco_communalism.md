---
name: Courant Isolationniste Anti-Circulation de l'Information
type: instance
slug: courant_isolationniste_anti_circulation_de_l_information_eco_communalism
entite: courant_isolationniste_anti_circulation_de_l_information
scenario: eco_communalism
statut: officialise_minimal

type_dans_scenario: autre

role_dans_scenario: >
  Dans le scénario éco-communaliste, ce courant représente la tendance radicale à l'enfermement communautaire, s'opposant aux réseaux d'entraide inter-communautés et fragilisant la résilience collective face aux crises.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - technologie_information
  - frontieres_du_systeme
  - valeurs_culture_tempo_sociale

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Courant Isolationniste Anti-Circulation de l'Information

## Rôle dans [[eco_communalism]]
Dans le scénario éco-communaliste, ce courant représente la tendance radicale à l'enfermement communautaire, s'opposant aux réseaux d'entraide inter-communautés et fragilisant la résilience collective face aux crises.

## Variables influencées
- [[technologie_information]]
- [[frontieres_du_systeme]]
- [[valeurs_culture_tempo_sociale]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
