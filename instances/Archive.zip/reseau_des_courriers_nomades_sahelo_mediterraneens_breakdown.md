---
name: Réseau des Courriers Nomades Sahélo-Méditerranéens
type: instance
slug: reseau_des_courriers_nomades_sahelo_mediterraneens_breakdown
entite: reseau_des_courriers_nomades_sahelo_mediterraneens
scenario: breakdown
statut: officialise_minimal

type_dans_scenario: réseau

role_dans_scenario: >
  Dans un contexte de breakdown systémique, ce réseau constitue l'une des rares artères de circulation persistante — marchandises, messages, personnes — entre les zones effondrées et les nœuds encore fonctionnels du bassin sahélo-méditerranéen.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - demographie_mobilite_humaine
  - organisation_territoires
  - frontieres_du_systeme

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Réseau des Courriers Nomades Sahélo-Méditerranéens

## Rôle dans [[breakdown]]
Dans un contexte de breakdown systémique, ce réseau constitue l'une des rares artères de circulation persistante — marchandises, messages, personnes — entre les zones effondrées et les nœuds encore fonctionnels du bassin sahélo-méditerranéen.

## Variables influencées
- [[demographie_mobilite_humaine]]
- [[organisation_territoires]]
- [[frontieres_du_systeme]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
