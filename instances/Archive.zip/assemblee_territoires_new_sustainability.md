---
name: Parlement des Territoires
type: instance
slug: assemblee_territoires_new_sustainability
entite: assemblee_territoires
scenario: new_sustainability
localisation:
  zone: hub_nairobi_kigali
  lieu: Nairobi
  type_lieu: ville
type_dans_scenario: institution
role_dans_scenario: >
  Instance mondiale de gouvernance territoriale créée par le Traité de
  Nairobi de 2041. Représente à la fois les États, les régions autonomes
  et les écosystèmes via des délégués spécialisés. Compétences sur
  l'aménagement territorial, les migrations climatiques et les droits
  du sol.
responsabilites: >
  Planification territoriale mondiale pour les transitions climatiques.
  Gestion coordonnée des migrations climatiques. Attribution des droits
  d'usage des territoires communs. Validation des plans de résilience
  régionaux.
impact_local: 3
impact_systemique_global: 4
variables_influencees:
  - organisation_territoires
  - gouvernance_institutions
  - demographie_mobilite_humaine
  - climat_environnement_global
zone_geographique:
  - globale
zone_systemique:
  - gouvernance
  - infrastructure
  - société
alliances:
  - conseil_regulation_algorithmique_new_sustainability
  - coalition_vivant_new_sustainability
  - nexcore_new_sustainability
oppositions: []
type_relation_dominante: coopération
annee_debut: 2041
annee_fin:
etat_temporel: actif
age_historique: mature
generation: ère cognitive
injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false
description_journalistique: >
  Le Parlement des Territoires siège à Nairobi dans un bâtiment conçu
  pour durer mille ans. 340 délégués représentent 195 États, 89 régions
  autonomes et 12 écosystèmes protégés. Ses sessions sont publiques,
  traduites en 94 langues en temps réel. Sa présidente, Nilufar
  Rashidova, est à son deuxième mandat.
signes_distinctifs: >
  Bâtiment bioclimatique iconique à Nairobi. Débats publics intégraux.
  Chaque délégué territorial porte les couleurs de sa région.
  Jardins intérieurs représentant les biomes du monde.
tensions_narratives: >
  Tension récurrente entre les délégués des États et ceux des régions
  autonomes sur les questions de souveraineté. Débat non résolu sur
  la pondération des votes — un État de 2 millions face à un écosystème
  de 500 millions d'hectares.
date_creation: 2098-01-01
---

# Parlement des Territoires

## Rôle dans [[new_sustainability]]
Instance mondiale de gouvernance territoriale. 340 délégués représentant
États, régions autonomes et écosystèmes.

## Variables influencées
- [[organisation_territoires]]
- [[gouvernance_institutions]]
- [[demographie_mobilite_humaine]]
- [[climat_environnement_global]]

## Relations
**Alliés** : [[conseil_regulation_algorithmique_new_sustainability]], [[coalition_vivant_new_sustainability]], [[nexcore_new_sustainability]]
**Opposants** : _aucun défini_

## Description journalistique
Le Parlement des Territoires siège à Nairobi dans un bâtiment conçu pour
durer mille ans. 340 délégués, sessions publiques, traduction en 94 langues.
Sa présidente, Nilufar Rashidova, est à son deuxième mandat.

## Tensions narratives
Tension entre délégués d'États et de régions autonomes. Débat non résolu
sur la pondération des votes.
