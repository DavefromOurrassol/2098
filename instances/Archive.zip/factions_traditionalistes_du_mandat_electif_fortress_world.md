---
name: Factions Traditionalistes du Mandat Électif
type: instance
slug: factions_traditionalistes_du_mandat_electif_fortress_world
entite: factions_traditionalistes_du_mandat_electif
scenario: fortress_world
statut: officialise_minimal

type_dans_scenario: organisation

role_dans_scenario: >
  Dans fortress_world, elles constituent un frein institutionnel aux réformes de gouvernance automatisée, revendiquant la primauté du vote et du mandat populaire face aux dispositifs de pilotage non-élus.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - gouvernance_institutions
  - valeurs_culture_tempo_sociale
  - organisation_territoires

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Factions Traditionalistes du Mandat Électif

## Rôle dans [[fortress_world]]
Dans fortress_world, elles constituent un frein institutionnel aux réformes de gouvernance automatisée, revendiquant la primauté du vote et du mandat populaire face aux dispositifs de pilotage non-élus.

## Variables influencées
- [[gouvernance_institutions]]
- [[valeurs_culture_tempo_sociale]]
- [[organisation_territoires]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
