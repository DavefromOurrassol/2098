---
name: Flux Migratoires Non Intégrables
type: instance
slug: flux_migratoires_non_integrables_breakdown
entite: flux_migratoires_non_integrables
scenario: breakdown
statut: officialise_minimal

type_dans_scenario: autre

role_dans_scenario: >
  Facteur de déstabilisation structurelle dans le scénario breakdown, révélant l'effondrement des mécanismes de gouvernance territoriale et d'accueil.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - demographie_mobilite_humaine
  - organisation_territoires
  - gouvernance_institutions

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Flux Migratoires Non Intégrables

## Rôle dans [[breakdown]]
Facteur de déstabilisation structurelle dans le scénario breakdown, révélant l'effondrement des mécanismes de gouvernance territoriale et d'accueil.

## Variables influencées
- [[demographie_mobilite_humaine]]
- [[organisation_territoires]]
- [[gouvernance_institutions]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
