---
name: Opérateurs Logistiques Privés des Zones Grises Eurasiennes
type: instance
slug: operateurs_logistiques_prives_des_zones_grises_eurasiennes_reference
entite: operateurs_logistiques_prives_des_zones_grises_eurasiennes
scenario: reference
statut: officialise_minimal

type_dans_scenario: réseau

role_dans_scenario: >
  Facilitent la circulation de marchandises, ressources ou données dans des corridors échappant aux contrôles institutionnels classiques, jouant un rôle structurant dans les économies parallèles de la région.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - geopolitique_conflits
  - organisation_territoires
  - frontieres_du_systeme

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Opérateurs Logistiques Privés des Zones Grises Eurasiennes

## Rôle dans [[reference]]
Facilitent la circulation de marchandises, ressources ou données dans des corridors échappant aux contrôles institutionnels classiques, jouant un rôle structurant dans les économies parallèles de la région.

## Variables influencées
- [[geopolitique_conflits]]
- [[organisation_territoires]]
- [[frontieres_du_systeme]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
