---
name: Populations des Zones Déficitaires d'Optimisation
type: instance
slug: populations_des_zones_deficitaires_d_optimisation_fortress_world
entite: populations_des_zones_deficitaires_d_optimisation
scenario: fortress_world
statut: officialise_minimal

type_dans_scenario: autre

role_dans_scenario: >
  Victimes emblématiques du scénario fortress_world, elles incarnent le coût humain des décisions d'exclusion territoriale et la fracture entre zones optimisées et zones sacrifiées.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - organisation_territoires
  - demographie_mobilite_humaine
  - gouvernance_institutions

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Populations des Zones Déficitaires d'Optimisation

## Rôle dans [[fortress_world]]
Victimes emblématiques du scénario fortress_world, elles incarnent le coût humain des décisions d'exclusion territoriale et la fracture entre zones optimisées et zones sacrifiées.

## Variables influencées
- [[organisation_territoires]]
- [[demographie_mobilite_humaine]]
- [[gouvernance_institutions]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
