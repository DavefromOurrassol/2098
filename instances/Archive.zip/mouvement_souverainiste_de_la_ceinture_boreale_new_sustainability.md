---
name: Mouvement Souverainiste de la Ceinture Boréale
type: instance
slug: mouvement_souverainiste_de_la_ceinture_boreale_new_sustainability
entite: mouvement_souverainiste_de_la_ceinture_boreale
scenario: new_sustainability
statut: officialise_minimal

type_dans_scenario: organisation

role_dans_scenario: >
  Dans le scénario new_sustainability, ce mouvement conteste la légitimité des grands accords environnementaux en revendiquant que les régions boréales — poumons verts et réservoirs de ressources critiques — décident elles-mêmes de leur modèle de durabilité.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - organisation_territoires
  - gouvernance_institutions
  - energie_ressources_critiques

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Mouvement Souverainiste de la Ceinture Boréale

## Rôle dans [[new_sustainability]]
Dans le scénario new_sustainability, ce mouvement conteste la légitimité des grands accords environnementaux en revendiquant que les régions boréales — poumons verts et réservoirs de ressources critiques — décident elles-mêmes de leur modèle de durabilité.

## Variables influencées
- [[organisation_territoires]]
- [[gouvernance_institutions]]
- [[energie_ressources_critiques]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
