---
name: Collectifs de Déplacés Climatiques Non-Représentés
type: instance
slug: collectifs_de_deplaces_climatiques_non_representes_new_sustainability
entite: collectifs_de_deplaces_climatiques_non_representes
scenario: new_sustainability
statut: officialise_minimal

type_dans_scenario: réseau

role_dans_scenario: >
  Dans le scénario new_sustainability, ces collectifs incarnent la fracture entre les nouvelles politiques de durabilité et les populations les plus directement frappées par l'effondrement climatique, restées invisibles dans les négociations.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - demographie_mobilite_humaine
  - gouvernance_institutions
  - organisation_territoires

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Collectifs de Déplacés Climatiques Non-Représentés

## Rôle dans [[new_sustainability]]
Dans le scénario new_sustainability, ces collectifs incarnent la fracture entre les nouvelles politiques de durabilité et les populations les plus directement frappées par l'effondrement climatique, restées invisibles dans les négociations.

## Variables influencées
- [[demographie_mobilite_humaine]]
- [[gouvernance_institutions]]
- [[organisation_territoires]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
