---
name: Réseaux de Soigneurs Traditionnels
type: instance
slug: reseaux_de_soigneurs_traditionnels_breakdown
entite: reseaux_de_soigneurs_traditionnels
scenario: breakdown
statut: officialise_minimal

type_dans_scenario: réseau

role_dans_scenario: >
  Dans un contexte de breakdown, ces réseaux comblent les vides laissés par l'effondrement des infrastructures médicales formelles, en assurant une continuité de soin de proximité à l'échelle locale et territoriale.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - sante_biotechnologies
  - organisation_territoires
  - valeurs_culture_tempo_sociale

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Réseaux de Soigneurs Traditionnels

## Rôle dans [[breakdown]]
Dans un contexte de breakdown, ces réseaux comblent les vides laissés par l'effondrement des infrastructures médicales formelles, en assurant une continuité de soin de proximité à l'échelle locale et territoriale.

## Variables influencées
- [[sante_biotechnologies]]
- [[organisation_territoires]]
- [[valeurs_culture_tempo_sociale]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
