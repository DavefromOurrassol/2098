---
name: Régimes Autoritaires du Bloc Eurasiatique Occidental
type: instance
slug: regimes_autoritaires_du_bloc_eurasiatique_occidental_fortress_world
entite: regimes_autoritaires_du_bloc_eurasiatique_occidental
scenario: fortress_world
statut: officialise_minimal

type_dans_scenario: institution

role_dans_scenario: >
  Dans le scénario fortress_world, ils incarnent l'un des pôles de la fragmentation mondiale, appliquant des politiques de forteresse à l'échelle régionale — fermeture des frontières, militarisation des ressources, rejet des flux migratoires.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - gouvernance_institutions
  - geopolitique_conflits
  - frontieres_du_systeme

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Régimes Autoritaires du Bloc Eurasiatique Occidental

## Rôle dans [[fortress_world]]
Dans le scénario fortress_world, ils incarnent l'un des pôles de la fragmentation mondiale, appliquant des politiques de forteresse à l'échelle régionale — fermeture des frontières, militarisation des ressources, rejet des flux migratoires.

## Variables influencées
- [[gouvernance_institutions]]
- [[geopolitique_conflits]]
- [[frontieres_du_systeme]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
