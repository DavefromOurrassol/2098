---
name: communautés rurales autonomes
type: instance
slug: communautes_rurales_autonomes_breakdown
entite: communautes_rurales_autonomes
scenario: breakdown
statut: officialise_minimal

type_dans_scenario: réseau

role_dans_scenario: >
  Dans le scénario breakdown, elles incarnent une forme de résilience décentralisée face à l'effondrement des systèmes institutionnels, constituant des îlots de stabilité locale.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - organisation_territoires
  - energie_ressources_critiques
  - gouvernance_institutions

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# communautés rurales autonomes

## Rôle dans [[breakdown]]
Dans le scénario breakdown, elles incarnent une forme de résilience décentralisée face à l'effondrement des systèmes institutionnels, constituant des îlots de stabilité locale.

## Variables influencées
- [[organisation_territoires]]
- [[energie_ressources_critiques]]
- [[gouvernance_institutions]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
