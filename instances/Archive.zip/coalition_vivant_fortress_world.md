---
name: Réseau Vert Clandestin
type: instance
slug: coalition_vivant_fortress_world
entite: coalition_vivant
scenario: fortress_world
localisation:
  zone: bloc_atlantique
  lieu: Bloc Atlantique
  type_lieu: region
type_dans_scenario: réseau
role_dans_scenario: >
  Organisation écologique clandestine opérant en marge de la légalité
  dans le Bloc Atlantique. Classée "organisation subversive" par l'ANBA
  en 2052 après avoir diffusé des données sur la dégradation des zones
  abandonnées. Opère via des réseaux mesh non certifiés et des cellules
  locales autonomes.
responsabilites: >
  Collecte de données environnementales dans les zones d'exclusion.
  Diffusion clandestine d'informations sur la dégradation écologique.
  Protection et exfiltration de militants menacés.
impact_local: 2
impact_systemique_global: 2
variables_influencees:
  - climat_environnement_global
  - valeurs_culture_tempo_sociale
  - gouvernance_institutions
zone_geographique:
  - continentale
zone_systemique:
  - société
  - information
alliances:
  - le_temoin_fortress_world
oppositions:
  - conseil_regulation_algorithmique_fortress_world
type_relation_dominante: conflit
annee_debut: 2048
annee_fin:
etat_temporel: clandestin
age_historique: ascendant
generation: forteresse
injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false
description_journalistique: >
  Le Réseau Vert Clandestin n'a pas de porte-parole officiel. Ses
  communiqués arrivent via des canaux mesh qui changent chaque semaine,
  signés d'un simple feuille stylisée. Le Bloc les accuse de "terrorisme
  environnemental" — terme qui s'applique, dans sa législation, à quiconque
  diffuse des données sur les zones d'exclusion sans autorisation.
  Leur dernier rapport documentait la contamination de trois nappes
  phréatiques dans le Midwest désertifié.
signes_distinctifs: >
  Feuille stylisée comme symbole. Communiqués courts, données vérifiables,
  aucune rhétorique — volontairement factuel pour contrer les accusations
  de propagande.
tensions_narratives: >
  Division interne sur la radicalisation — une faction veut passer
  à l'action directe, l'autre maintient la ligne de diffusion
  d'information. Plusieurs membres arrêtés en 2097. La coordination
  centrale a été compromise.
date_creation: 2098-01-01
---

# Réseau Vert Clandestin

## Rôle dans [[fortress_world]]
Organisation écologique clandestine, classée "subversive" par l'ANBA en 2052.
Opère via réseaux mesh non certifiés.

## Variables influencées
- [[climat_environnement_global]]
- [[valeurs_culture_tempo_sociale]]
- [[gouvernance_institutions]]

## Relations
**Alliés** : [[le_temoin_fortress_world]]
**Opposants** : [[conseil_regulation_algorithmique_fortress_world]]

## Description journalistique
Le Réseau Vert Clandestin n'a pas de porte-parole. Le Bloc les accuse de
"terrorisme environnemental" pour avoir diffusé des données sur les zones
d'exclusion. Leur dernier rapport documentait la contamination de trois
nappes phréatiques dans le Midwest désertifié.

## Tensions narratives
Division interne sur la radicalisation. Plusieurs membres arrêtés en 2097.
La coordination centrale a été compromise.
