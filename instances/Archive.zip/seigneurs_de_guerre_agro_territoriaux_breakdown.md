---
name: Seigneurs de Guerre Agro-Territoriaux
type: instance
slug: seigneurs_de_guerre_agro_territoriaux_breakdown
entite: seigneurs_de_guerre_agro_territoriaux
scenario: breakdown
statut: officialise_minimal

type_dans_scenario: organisation

role_dans_scenario: >
  Dans le scénario breakdown, ils incarnent la fragmentation violente de la gouvernance : là où l'État a reculé, ces seigneurs de guerre comblent le vide en établissant des fiefs agro-territoriaux en compétition permanente.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - organisation_territoires
  - geopolitique_conflits
  - gouvernance_institutions

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Seigneurs de Guerre Agro-Territoriaux

## Rôle dans [[breakdown]]
Dans le scénario breakdown, ils incarnent la fragmentation violente de la gouvernance : là où l'État a reculé, ces seigneurs de guerre comblent le vide en établissant des fiefs agro-territoriaux en compétition permanente.

## Variables influencées
- [[organisation_territoires]]
- [[geopolitique_conflits]]
- [[gouvernance_institutions]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
