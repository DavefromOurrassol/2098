---
name: Réseau des Communs Numériques Globaux
type: instance
slug: reseau_des_communs_numeriques_globaux_new_sustainability
entite: reseau_des_communs_numeriques_globaux
scenario: new_sustainability
statut: officialise_minimal

type_dans_scenario: réseau

role_dans_scenario: >
  Dans le scénario new_sustainability, ce réseau incarne une alternative de gouvernance distribuée des ressources numériques, potentiellement en tension avec les acteurs privés et institutionnels dominants.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - technologie_information
  - gouvernance_institutions
  - systeme_economique_redistribution

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Réseau des Communs Numériques Globaux

## Rôle dans [[new_sustainability]]
Dans le scénario new_sustainability, ce réseau incarne une alternative de gouvernance distribuée des ressources numériques, potentiellement en tension avec les acteurs privés et institutionnels dominants.

## Variables influencées
- [[technologie_information]]
- [[gouvernance_institutions]]
- [[systeme_economique_redistribution]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
