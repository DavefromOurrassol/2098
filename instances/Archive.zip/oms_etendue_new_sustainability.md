---
name: OMS Étendue
type: instance
slug: oms_etendue_new_sustainability
entite: oms_etendue
scenario: new_sustainability
statut: officialise_minimal

type_dans_scenario: institution

role_dans_scenario: >
  Régule et coordonne les politiques de santé augmentée à l'échelle internationale dans un contexte de transitions écologiques et biotechnologiques majeures.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - sante_biotechnologies
  - gouvernance_institutions
  - demographie_mobilite_humaine

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# OMS Étendue

## Rôle dans [[new_sustainability]]
Régule et coordonne les politiques de santé augmentée à l'échelle internationale dans un contexte de transitions écologiques et biotechnologiques majeures.

## Variables influencées
- [[sante_biotechnologies]]
- [[gouvernance_institutions]]
- [[demographie_mobilite_humaine]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
