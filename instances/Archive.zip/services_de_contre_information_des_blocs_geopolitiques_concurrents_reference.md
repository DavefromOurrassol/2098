---
name: Services de contre-information des blocs géopolitiques concurrents
type: instance
slug: services_de_contre_information_des_blocs_geopolitiques_concurrents_reference
entite: services_de_contre_information_des_blocs_geopolitiques_concurrents
scenario: reference
statut: officialise_minimal

type_dans_scenario: organisation

role_dans_scenario: >
  Acteurs exogènes qui alimentent la guerre informationnelle en 2098, ciblant les médias, les IA éditoriales et les institutions de vérification des faits dans les zones de compétition géopolitique.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - geopolitique_conflits
  - technologie_information
  - gouvernance_institutions

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Services de contre-information des blocs géopolitiques concurrents

## Rôle dans [[reference]]
Acteurs exogènes qui alimentent la guerre informationnelle en 2098, ciblant les médias, les IA éditoriales et les institutions de vérification des faits dans les zones de compétition géopolitique.

## Variables influencées
- [[geopolitique_conflits]]
- [[technologie_information]]
- [[gouvernance_institutions]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
