---
name: AgriSynth
type: instance
slug: agrisynth_reference
entite: agrisynth
scenario: reference
statut: officialise_minimal

type_dans_scenario: entreprise

role_dans_scenario: >
  Dans le scénario de référence, AgriSynth fournit des infrastructures de données biologiques qui structurent la connaissance et le contrôle des systèmes agricoles.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - systemes_productifs_travail
  - sante_biotechnologies
  - technologie_information

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# AgriSynth

## Rôle dans [[reference]]
Dans le scénario de référence, AgriSynth fournit des infrastructures de données biologiques qui structurent la connaissance et le contrôle des systèmes agricoles.

## Variables influencées
- [[systemes_productifs_travail]]
- [[sante_biotechnologies]]
- [[technologie_information]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
