---
name: Conseil de Régulation Cognitive de l'ONU
type: instance
slug: conseil_de_regulation_cognitive_de_l_onu_new_sustainability
entite: conseil_de_regulation_cognitive_de_l_onu
scenario: new_sustainability
statut: officialise_minimal

type_dans_scenario: institution

role_dans_scenario: >
  Dans le scénario new_sustainability, agit comme cadre normatif international encadrant l'usage des technologies cognitives au service ou en opposition aux nouvelles logiques de durabilité.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - gouvernance_institutions
  - technologie_information
  - valeurs_culture_tempo_sociale

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Conseil de Régulation Cognitive de l'ONU

## Rôle dans [[new_sustainability]]
Dans le scénario new_sustainability, agit comme cadre normatif international encadrant l'usage des technologies cognitives au service ou en opposition aux nouvelles logiques de durabilité.

## Variables influencées
- [[gouvernance_institutions]]
- [[technologie_information]]
- [[valeurs_culture_tempo_sociale]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
