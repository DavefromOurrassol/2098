---
name: Régulateurs de l'Union Eurasiatique sur les Données Critiques
type: instance
slug: regulateurs_de_l_union_eurasiatique_sur_les_donnees_critiques_reference
entite: regulateurs_de_l_union_eurasiatique_sur_les_donnees_critiques
scenario: reference
statut: officialise_minimal

type_dans_scenario: institution

role_dans_scenario: >
  Exerce une pression institutionnelle sur les acteurs qui centralisent ou exploitent des données stratégiques, pouvant bloquer, fragmenter ou conditionner certains flux d'information.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - gouvernance_institutions
  - technologie_information
  - geopolitique_conflits

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Régulateurs de l'Union Eurasiatique sur les Données Critiques

## Rôle dans [[reference]]
Exerce une pression institutionnelle sur les acteurs qui centralisent ou exploitent des données stratégiques, pouvant bloquer, fragmenter ou conditionner certains flux d'information.

## Variables influencées
- [[gouvernance_institutions]]
- [[technologie_information]]
- [[geopolitique_conflits]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
