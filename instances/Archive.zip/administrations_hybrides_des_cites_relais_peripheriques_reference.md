---
name: Administrations Hybrides des Cités-Relais Périphériques
type: instance
slug: administrations_hybrides_des_cites_relais_peripheriques_reference
entite: administrations_hybrides_des_cites_relais_peripheriques
scenario: reference
statut: officialise_minimal

type_dans_scenario: institution

role_dans_scenario: >
  Dans le scénario reference, elles incarnent la recomposition territoriale des pouvoirs publics face à l'étalement et à la différenciation des zones habitées en 2098.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - organisation_territoires
  - gouvernance_institutions
  - demographie_mobilite_humaine

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Administrations Hybrides des Cités-Relais Périphériques

## Rôle dans [[reference]]
Dans le scénario reference, elles incarnent la recomposition territoriale des pouvoirs publics face à l'étalement et à la différenciation des zones habitées en 2098.

## Variables influencées
- [[organisation_territoires]]
- [[gouvernance_institutions]]
- [[demographie_mobilite_humaine]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
