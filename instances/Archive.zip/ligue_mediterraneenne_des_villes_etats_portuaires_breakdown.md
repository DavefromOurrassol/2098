---
name: Ligue Méditerranéenne des Villes-États Portuaires
type: instance
slug: ligue_mediterraneenne_des_villes_etats_portuaires_breakdown
entite: ligue_mediterraneenne_des_villes_etats_portuaires
scenario: breakdown
statut: officialise_minimal

type_dans_scenario: organisation

role_dans_scenario: >
  Dans le scénario breakdown, incarne la recomposition politique par les villes plutôt que par les États-nations effondrés, en assurant la continuité des échanges régionaux via ses infrastructures portuaires.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - organisation_territoires
  - gouvernance_institutions
  - geopolitique_conflits

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Ligue Méditerranéenne des Villes-États Portuaires

## Rôle dans [[breakdown]]
Dans le scénario breakdown, incarne la recomposition politique par les villes plutôt que par les États-nations effondrés, en assurant la continuité des échanges régionaux via ses infrastructures portuaires.

## Variables influencées
- [[organisation_territoires]]
- [[gouvernance_institutions]]
- [[geopolitique_conflits]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
