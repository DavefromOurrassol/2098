---
name: Internationale des Semenciers Agro-Pirates
type: instance
slug: internationale_des_semenciers_agro_pirates_fortress_world
entite: internationale_des_semenciers_agro_pirates
scenario: fortress_world
statut: officialise_minimal

type_dans_scenario: réseau

role_dans_scenario: >
  Dans fortress_world, représente une forme de résistance souterraine aux enclosures alimentaires, maintenant des circuits d'approvisionnement alternatifs pour les communautés exclues des systèmes agroalimentaires corporatifs.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - systemes_productifs_travail
  - frontieres_du_systeme
  - gouvernance_institutions

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Internationale des Semenciers Agro-Pirates

## Rôle dans [[fortress_world]]
Dans fortress_world, représente une forme de résistance souterraine aux enclosures alimentaires, maintenant des circuits d'approvisionnement alternatifs pour les communautés exclues des systèmes agroalimentaires corporatifs.

## Variables influencées
- [[systemes_productifs_travail]]
- [[frontieres_du_systeme]]
- [[gouvernance_institutions]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
