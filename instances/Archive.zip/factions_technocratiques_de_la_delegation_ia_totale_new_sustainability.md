---
name: Factions Technocratiques de la Délégation IA Totale
type: instance
slug: factions_technocratiques_de_la_delegation_ia_totale_new_sustainability
entite: factions_technocratiques_de_la_delegation_ia_totale
scenario: new_sustainability
statut: officialise_minimal

type_dans_scenario: organisation

role_dans_scenario: >
  Dans le scénario new_sustainability, ces factions poussent à retirer aux humains tout pouvoir de veto sur les décisions environnementales et économiques critiques, au nom de l'urgence climatique et de la rationalité algorithmique.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - gouvernance_institutions
  - technologie_information
  - valeurs_culture_tempo_sociale

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Factions Technocratiques de la Délégation IA Totale

## Rôle dans [[new_sustainability]]
Dans le scénario new_sustainability, ces factions poussent à retirer aux humains tout pouvoir de veto sur les décisions environnementales et économiques critiques, au nom de l'urgence climatique et de la rationalité algorithmique.

## Variables influencées
- [[gouvernance_institutions]]
- [[technologie_information]]
- [[valeurs_culture_tempo_sociale]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
