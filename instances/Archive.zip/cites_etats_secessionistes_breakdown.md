---
name: Cités-États Sécessionistes
type: instance
slug: cites_etats_secessionistes_breakdown
entite: cites_etats_secessionistes
scenario: breakdown
statut: officialise_minimal

type_dans_scenario: organisation

role_dans_scenario: >
  Dans le scénario breakdown, incarnent l'effondrement de la cohérence institutionnelle globale en constituant des pôles de gouvernance autonomes et incompatibles entre eux, accélérant la désintégration des cadres communs.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - gouvernance_institutions
  - organisation_territoires
  - geopolitique_conflits

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Cités-États Sécessionistes

## Rôle dans [[breakdown]]
Dans le scénario breakdown, incarnent l'effondrement de la cohérence institutionnelle globale en constituant des pôles de gouvernance autonomes et incompatibles entre eux, accélérant la désintégration des cadres communs.

## Variables influencées
- [[gouvernance_institutions]]
- [[organisation_territoires]]
- [[geopolitique_conflits]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
