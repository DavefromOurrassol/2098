---
name: Ligue des Métropoles du Sud pour les Infrastructures Libres
type: instance
slug: ligue_des_metropoles_du_sud_pour_les_infrastructures_libres_reference
entite: ligue_des_metropoles_du_sud_pour_les_infrastructures_libres
scenario: reference
statut: officialise_minimal

type_dans_scenario: organisation

role_dans_scenario: >
  Dans ce scénario, elle incarne la pression organisée des territoires périphériques pour redistribuer le contrôle des infrastructures mondiales, contestant les logiques de dépendance héritées.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - gouvernance_institutions
  - organisation_territoires
  - energie_ressources_critiques

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Ligue des Métropoles du Sud pour les Infrastructures Libres

## Rôle dans [[reference]]
Dans ce scénario, elle incarne la pression organisée des territoires périphériques pour redistribuer le contrôle des infrastructures mondiales, contestant les logiques de dépendance héritées.

## Variables influencées
- [[gouvernance_institutions]]
- [[organisation_territoires]]
- [[energie_ressources_critiques]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
