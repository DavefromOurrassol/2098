---
name: États-Fragments en Guerre pour les Stations Atmosphériques
type: instance
slug: etats_fragments_en_guerre_pour_les_stations_atmospheriques_breakdown
entite: etats_fragments_en_guerre_pour_les_stations_atmospheriques
scenario: breakdown
statut: officialise_minimal

type_dans_scenario: institution

role_dans_scenario: >
  Acteurs déstabilisateurs centraux du scénario breakdown, leur rivalité militarisée autour des stations atmosphériques illustre l'effondrement de la coopération internationale face aux crises climatiques.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - geopolitique_conflits
  - organisation_territoires
  - climat_environnement_global

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# États-Fragments en Guerre pour les Stations Atmosphériques

## Rôle dans [[breakdown]]
Acteurs déstabilisateurs centraux du scénario breakdown, leur rivalité militarisée autour des stations atmosphériques illustre l'effondrement de la coopération internationale face aux crises climatiques.

## Variables influencées
- [[geopolitique_conflits]]
- [[organisation_territoires]]
- [[climat_environnement_global]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
