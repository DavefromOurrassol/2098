---
name: Coalition Anti-Fiscalité Universelle
type: instance
slug: coalition_anti_fiscalite_universelle_new_sustainability
entite: coalition_anti_fiscalite_universelle
scenario: new_sustainability
statut: officialise_minimal

type_dans_scenario: organisation

role_dans_scenario: >
  Dans le scénario new_sustainability, représente la résistance organisée aux tentatives d'harmonisation fiscale mondiale, bloquant ou contournant les mécanismes de financement de la transition écologique.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - systeme_economique_redistribution
  - gouvernance_institutions
  - geopolitique_conflits

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Coalition Anti-Fiscalité Universelle

## Rôle dans [[new_sustainability]]
Dans le scénario new_sustainability, représente la résistance organisée aux tentatives d'harmonisation fiscale mondiale, bloquant ou contournant les mécanismes de financement de la transition écologique.

## Variables influencées
- [[systeme_economique_redistribution]]
- [[gouvernance_institutions]]
- [[geopolitique_conflits]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
