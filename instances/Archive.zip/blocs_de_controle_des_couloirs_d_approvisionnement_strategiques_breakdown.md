---
name: Blocs de Contrôle des Couloirs d'Approvisionnement Stratégiques
type: instance
slug: blocs_de_controle_des_couloirs_d_approvisionnement_strategiques_breakdown
entite: blocs_de_controle_des_couloirs_d_approvisionnement_strategiques
scenario: breakdown
statut: officialise_minimal

type_dans_scenario: organisation

role_dans_scenario: >
  Dans le scénario breakdown, ces blocs exercent une pression de recontrôle territorial sur les flux stratégiques, accélérant la fragmentation du système mondial plutôt que de le stabiliser.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - geopolitique_conflits
  - energie_ressources_critiques
  - organisation_territoires

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Blocs de Contrôle des Couloirs d'Approvisionnement Stratégiques

## Rôle dans [[breakdown]]
Dans le scénario breakdown, ces blocs exercent une pression de recontrôle territorial sur les flux stratégiques, accélérant la fragmentation du système mondial plutôt que de le stabiliser.

## Variables influencées
- [[geopolitique_conflits]]
- [[energie_ressources_critiques]]
- [[organisation_territoires]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
