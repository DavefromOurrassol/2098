---
name: Guildes des Semenciers Itinérants
type: instance
slug: guildes_des_semenciers_itinerants_eco_communalism
entite: guildes_des_semenciers_itinerants
scenario: eco_communalism
statut: officialise_minimal

type_dans_scenario: réseau

role_dans_scenario: >
  Dans le scénario éco-communaliste, ils assurent la circulation des ressources génétiques végétales et des savoir-faire entre communautés autonomes, jouant un rôle de liant territorial et de résistance à toute dépendance semencière externalisée.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - systemes_productifs_travail
  - organisation_territoires
  - demographie_mobilite_humaine

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Guildes des Semenciers Itinérants

## Rôle dans [[eco_communalism]]
Dans le scénario éco-communaliste, ils assurent la circulation des ressources génétiques végétales et des savoir-faire entre communautés autonomes, jouant un rôle de liant territorial et de résistance à toute dépendance semencière externalisée.

## Variables influencées
- [[systemes_productifs_travail]]
- [[organisation_territoires]]
- [[demographie_mobilite_humaine]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
