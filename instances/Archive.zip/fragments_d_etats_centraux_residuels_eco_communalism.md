---
name: Fragments d'États Centraux Résiduels
type: instance
slug: fragments_d_etats_centraux_residuels_eco_communalism
entite: fragments_d_etats_centraux_residuels
scenario: eco_communalism
statut: officialise_minimal

type_dans_scenario: institution

role_dans_scenario: >
  Pôles de résistance institutionnelle face à la montée du communalisme écologique, contestant la légitimité territoriale des réseaux décentralisés et tentant de réaffirmer un ordre juridique et administratif hérité.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - gouvernance_institutions
  - organisation_territoires
  - geopolitique_conflits

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Fragments d'États Centraux Résiduels

## Rôle dans [[eco_communalism]]
Pôles de résistance institutionnelle face à la montée du communalisme écologique, contestant la légitimité territoriale des réseaux décentralisés et tentant de réaffirmer un ordre juridique et administratif hérité.

## Variables influencées
- [[gouvernance_institutions]]
- [[organisation_territoires]]
- [[geopolitique_conflits]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
