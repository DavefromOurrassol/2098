---
name: Milices Concurrentes des Droits de Passage
type: instance
slug: milices_concurrentes_des_droits_de_passage_reference
entite: milices_concurrentes_des_droits_de_passage
scenario: reference
statut: officialise_minimal

type_dans_scenario: organisation

role_dans_scenario: >
  Dans ce scénario, elles incarnent la concurrence violente pour le contrôle des nœuds de mobilité, fragmentant l'espace en zones de friction où chaque passage est négocié ou imposé par la force.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - organisation_territoires
  - geopolitique_conflits
  - demographie_mobilite_humaine

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Milices Concurrentes des Droits de Passage

## Rôle dans [[reference]]
Dans ce scénario, elles incarnent la concurrence violente pour le contrôle des nœuds de mobilité, fragmentant l'espace en zones de friction où chaque passage est négocié ou imposé par la force.

## Variables influencées
- [[organisation_territoires]]
- [[geopolitique_conflits]]
- [[demographie_mobilite_humaine]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
