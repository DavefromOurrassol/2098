---
name: Front Techno-Reconstructionniste
type: instance
slug: front_techno_reconstructionniste_breakdown
entite: front_techno_reconstructionniste
scenario: breakdown
statut: officialise_minimal

type_dans_scenario: organisation

role_dans_scenario: >
  S'oppose aux courants effondristes dominants dans le scénario breakdown en défendant une relance techno-industrielle volontariste comme réponse aux crises systémiques.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - technologie_information
  - gouvernance_institutions
  - valeurs_culture_tempo_sociale

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Front Techno-Reconstructionniste

## Rôle dans [[breakdown]]
S'oppose aux courants effondristes dominants dans le scénario breakdown en défendant une relance techno-industrielle volontariste comme réponse aux crises systémiques.

## Variables influencées
- [[technologie_information]]
- [[gouvernance_institutions]]
- [[valeurs_culture_tempo_sociale]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
