---
name: Opérateurs de Zones Économiques Spéciales Périurbaines
type: instance
slug: operateurs_de_zones_economiques_speciales_periurbaines_reference
entite: operateurs_de_zones_economiques_speciales_periurbaines
scenario: reference
statut: officialise_minimal

type_dans_scenario: entreprise

role_dans_scenario: >
  Acteurs clés de l'organisation territoriale périurbaine, ils structurent des espaces économiques hybrides entre logique de marché dérégulé et gouvernance locale, influençant les flux de travail, de ressources et de populations.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - organisation_territoires
  - systeme_economique_redistribution
  - systemes_productifs_travail

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Opérateurs de Zones Économiques Spéciales Périurbaines

## Rôle dans [[reference]]
Acteurs clés de l'organisation territoriale périurbaine, ils structurent des espaces économiques hybrides entre logique de marché dérégulé et gouvernance locale, influençant les flux de travail, de ressources et de populations.

## Variables influencées
- [[organisation_territoires]]
- [[systeme_economique_redistribution]]
- [[systemes_productifs_travail]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
