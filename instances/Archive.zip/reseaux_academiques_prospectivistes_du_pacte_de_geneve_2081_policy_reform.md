---
name: Réseaux académiques prospectivistes du Pacte de Genève 2081
type: instance
slug: reseaux_academiques_prospectivistes_du_pacte_de_geneve_2081_policy_reform
entite: reseaux_academiques_prospectivistes_du_pacte_de_geneve_2081
scenario: policy_reform
statut: officialise_minimal

type_dans_scenario: réseau

role_dans_scenario: >
  Fournit des cadres analytiques et des scénarios prospectifs servant de base aux réformes politiques débattues dans le cadre du scénario policy_reform.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - gouvernance_institutions
  - frontieres_du_systeme
  - valeurs_culture_tempo_sociale

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Réseaux académiques prospectivistes du Pacte de Genève 2081

## Rôle dans [[policy_reform]]
Fournit des cadres analytiques et des scénarios prospectifs servant de base aux réformes politiques débattues dans le cadre du scénario policy_reform.

## Variables influencées
- [[gouvernance_institutions]]
- [[frontieres_du_systeme]]
- [[valeurs_culture_tempo_sociale]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
