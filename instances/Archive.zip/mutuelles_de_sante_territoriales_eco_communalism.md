---
name: Mutuelles de Santé Territoriales
type: instance
slug: mutuelles_de_sante_territoriales_eco_communalism
entite: mutuelles_de_sante_territoriales
scenario: eco_communalism
statut: officialise_minimal

type_dans_scenario: organisation

role_dans_scenario: >
  Dans le scénario éco-communaliste, elles constituent l'épine dorsale de la protection sociale de base, substituant aux systèmes nationaux défaillants une prise en charge ancrée dans les bassins de vie.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - sante_biotechnologies
  - organisation_territoires
  - systeme_economique_redistribution

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Mutuelles de Santé Territoriales

## Rôle dans [[eco_communalism]]
Dans le scénario éco-communaliste, elles constituent l'épine dorsale de la protection sociale de base, substituant aux systèmes nationaux défaillants une prise en charge ancrée dans les bassins de vie.

## Variables influencées
- [[sante_biotechnologies]]
- [[organisation_territoires]]
- [[systeme_economique_redistribution]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
