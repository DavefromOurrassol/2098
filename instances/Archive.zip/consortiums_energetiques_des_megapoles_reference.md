---
name: Consortiums Énergétiques des Mégapoles
type: instance
slug: consortiums_energetiques_des_megapoles_reference
entite: consortiums_energetiques_des_megapoles
scenario: reference
statut: officialise_minimal

type_dans_scenario: entreprise

role_dans_scenario: >
  Dans le scénario reference, ils exercent une pression pour absorber les corridors logistiques et énergétiques reliant les mégapoles, transformant des infrastructures potentiellement mutualisées en actifs privés captifs.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - energie_ressources_critiques
  - organisation_territoires
  - gouvernance_institutions

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Consortiums Énergétiques des Mégapoles

## Rôle dans [[reference]]
Dans le scénario reference, ils exercent une pression pour absorber les corridors logistiques et énergétiques reliant les mégapoles, transformant des infrastructures potentiellement mutualisées en actifs privés captifs.

## Variables influencées
- [[energie_ressources_critiques]]
- [[organisation_territoires]]
- [[gouvernance_institutions]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
