---
name: ONG de Gestion Migratoire Survivantes
type: instance
slug: ong_de_gestion_migratoire_survivantes_breakdown
entite: ong_de_gestion_migratoire_survivantes
scenario: breakdown
statut: officialise_minimal

type_dans_scenario: organisation

role_dans_scenario: >
  Dans le scénario breakdown, elles pallient l'absence ou l'incapacité des institutions étatiques à gérer les déplacements de population, assurant une fonction de facto de régulation et d'accueil là où les gouvernements ont cédé.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - demographie_mobilite_humaine
  - gouvernance_institutions
  - organisation_territoires

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# ONG de Gestion Migratoire Survivantes

## Rôle dans [[breakdown]]
Dans le scénario breakdown, elles pallient l'absence ou l'incapacité des institutions étatiques à gérer les déplacements de population, assurant une fonction de facto de régulation et d'accueil là où les gouvernements ont cédé.

## Variables influencées
- [[demographie_mobilite_humaine]]
- [[gouvernance_institutions]]
- [[organisation_territoires]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
