---
name: Cellules Universitaires Dissidentes des Zones Tampons
type: instance
slug: cellules_universitaires_dissidentes_des_zones_tampons_fortress_world
entite: cellules_universitaires_dissidentes_des_zones_tampons
scenario: fortress_world
statut: officialise_minimal

type_dans_scenario: organisation

role_dans_scenario: >
  Produisent et diffusent des savoirs alternatifs dans les marges du système, perturbant le contrôle informationnel exercé par les citadelles sur les zones périphériques.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - organisation_territoires
  - technologie_information
  - gouvernance_institutions

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Cellules Universitaires Dissidentes des Zones Tampons

## Rôle dans [[fortress_world]]
Produisent et diffusent des savoirs alternatifs dans les marges du système, perturbant le contrôle informationnel exercé par les citadelles sur les zones périphériques.

## Variables influencées
- [[organisation_territoires]]
- [[technologie_information]]
- [[gouvernance_institutions]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
