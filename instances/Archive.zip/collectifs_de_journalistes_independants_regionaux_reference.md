---
name: Collectifs de Journalistes Indépendants Régionaux
type: instance
slug: collectifs_de_journalistes_independants_regionaux_reference
entite: collectifs_de_journalistes_independants_regionaux
scenario: reference
statut: officialise_minimal

type_dans_scenario: réseau

role_dans_scenario: >
  Dans le scénario reference, ces collectifs incarnent une alternative aux médias institutionnels ou corporatifs, portant une information de proximité potentiellement résistante aux pressions éditoriales centrales.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - technologie_information
  - gouvernance_institutions
  - organisation_territoires

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Collectifs de Journalistes Indépendants Régionaux

## Rôle dans [[reference]]
Dans le scénario reference, ces collectifs incarnent une alternative aux médias institutionnels ou corporatifs, portant une information de proximité potentiellement résistante aux pressions éditoriales centrales.

## Variables influencées
- [[technologie_information]]
- [[gouvernance_institutions]]
- [[organisation_territoires]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
