---
name: Collectifs de Hackers Biosphériques
type: instance
slug: collectifs_de_hackers_biospheriques_policy_reform
entite: collectifs_de_hackers_biospheriques
scenario: policy_reform
statut: officialise_minimal

type_dans_scenario: réseau

role_dans_scenario: >
  Dans le scénario policy_reform, ils contestent le monopole institutionnel et corporatif sur les données environnementales, forçant le débat sur l'accès ouvert à l'information climatique dans les processus de réforme réglementaire.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - technologie_information
  - climat_environnement_global
  - gouvernance_institutions

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Collectifs de Hackers Biosphériques

## Rôle dans [[policy_reform]]
Dans le scénario policy_reform, ils contestent le monopole institutionnel et corporatif sur les données environnementales, forçant le débat sur l'accès ouvert à l'information climatique dans les processus de réforme réglementaire.

## Variables influencées
- [[technologie_information]]
- [[climat_environnement_global]]
- [[gouvernance_institutions]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
