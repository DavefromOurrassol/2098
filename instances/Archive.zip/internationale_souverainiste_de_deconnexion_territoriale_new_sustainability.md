---
name: Internationale Souverainiste de Déconnexion Territoriale
type: instance
slug: internationale_souverainiste_de_deconnexion_territoriale_new_sustainability
entite: internationale_souverainiste_de_deconnexion_territoriale
scenario: new_sustainability
statut: officialise_minimal

type_dans_scenario: organisation

role_dans_scenario: >
  Dans le scénario new_sustainability, représente une force de résistance aux modèles de durabilité planifiés à l'échelle globale, contestant leur légitimité et proposant des alternatives fondées sur la déconnexion volontaire des flux transfrontaliers.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - organisation_territoires
  - frontieres_du_systeme
  - gouvernance_institutions

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Internationale Souverainiste de Déconnexion Territoriale

## Rôle dans [[new_sustainability]]
Dans le scénario new_sustainability, représente une force de résistance aux modèles de durabilité planifiés à l'échelle globale, contestant leur légitimité et proposant des alternatives fondées sur la déconnexion volontaire des flux transfrontaliers.

## Variables influencées
- [[organisation_territoires]]
- [[frontieres_du_systeme]]
- [[gouvernance_institutions]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
