---
name: Réseaux de passeurs d'information aux frontières inter-blocs
type: instance
slug: reseaux_de_passeurs_d_information_aux_frontieres_inter_blocs_fortress_world
entite: reseaux_de_passeurs_d_information_aux_frontieres_inter_blocs
scenario: fortress_world
statut: officialise_minimal

type_dans_scenario: réseau

role_dans_scenario: >
  Dans fortress_world, assurent la perméabilité résiduelle entre blocs autrement étanches, rendant possible une circulation minimale de données, de savoirs et de récits alternatifs malgré les verrous institutionnels.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - frontieres_du_systeme
  - technologie_information
  - geopolitique_conflits

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Réseaux de passeurs d'information aux frontières inter-blocs

## Rôle dans [[fortress_world]]
Dans fortress_world, assurent la perméabilité résiduelle entre blocs autrement étanches, rendant possible une circulation minimale de données, de savoirs et de récits alternatifs malgré les verrous institutionnels.

## Variables influencées
- [[frontieres_du_systeme]]
- [[technologie_information]]
- [[geopolitique_conflits]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
