---
name: Consortiums d'Extraction Minière du Bassin Congolais
type: instance
slug: consortiums_d_extraction_miniere_du_bassin_congolais_reference
entite: consortiums_d_extraction_miniere_du_bassin_congolais
scenario: reference
statut: officialise_minimal

type_dans_scenario: entreprise

role_dans_scenario: >
  Dans le scénario reference, ils constituent un nœud de tension entre extraction des ressources critiques mondiales et dynamiques de pouvoir régionales, pesant sur les équilibres économiques et conflictuels de la zone.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - energie_ressources_critiques
  - geopolitique_conflits
  - systeme_economique_redistribution

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Consortiums d'Extraction Minière du Bassin Congolais

## Rôle dans [[reference]]
Dans le scénario reference, ils constituent un nœud de tension entre extraction des ressources critiques mondiales et dynamiques de pouvoir régionales, pesant sur les équilibres économiques et conflictuels de la zone.

## Variables influencées
- [[energie_ressources_critiques]]
- [[geopolitique_conflits]]
- [[systeme_economique_redistribution]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
