---
name: Lobbies des Énergies Fossiles Résiduelles
type: instance
slug: lobbies_des_energies_fossiles_residuelles_policy_reform
entite: lobbies_des_energies_fossiles_residuelles
scenario: policy_reform
statut: officialise_minimal

type_dans_scenario: organisation

role_dans_scenario: >
  Dans le scénario policy_reform, ils constituent un obstacle organisé aux réformes réglementaires, cherchant à préserver des niches d'extraction ou des subventions résiduelles face aux pressions institutionnelles de transformation.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - energie_ressources_critiques
  - gouvernance_institutions
  - climat_environnement_global

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Lobbies des Énergies Fossiles Résiduelles

## Rôle dans [[policy_reform]]
Dans le scénario policy_reform, ils constituent un obstacle organisé aux réformes réglementaires, cherchant à préserver des niches d'extraction ou des subventions résiduelles face aux pressions institutionnelles de transformation.

## Variables influencées
- [[energie_ressources_critiques]]
- [[gouvernance_institutions]]
- [[climat_environnement_global]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
