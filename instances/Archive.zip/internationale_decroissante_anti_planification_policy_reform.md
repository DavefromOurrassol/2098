---
name: Internationale Décroissante Anti-Planification
type: instance
slug: internationale_decroissante_anti_planification_policy_reform
entite: internationale_decroissante_anti_planification
scenario: policy_reform
statut: officialise_minimal

type_dans_scenario: organisation

role_dans_scenario: >
  Dans ce scénario de réforme des politiques, constitue une force d'opposition idéologique aux tentatives de régulation ou de planification top-down, pouvant bloquer ou délégitimer les réformes institutionnelles.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - gouvernance_institutions
  - valeurs_culture_tempo_sociale
  - systeme_economique_redistribution

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Internationale Décroissante Anti-Planification

## Rôle dans [[policy_reform]]
Dans ce scénario de réforme des politiques, constitue une force d'opposition idéologique aux tentatives de régulation ou de planification top-down, pouvant bloquer ou délégitimer les réformes institutionnelles.

## Variables influencées
- [[gouvernance_institutions]]
- [[valeurs_culture_tempo_sociale]]
- [[systeme_economique_redistribution]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
