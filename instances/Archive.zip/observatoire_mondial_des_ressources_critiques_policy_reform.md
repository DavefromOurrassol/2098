---
name: Observatoire Mondial des Ressources Critiques
type: instance
slug: observatoire_mondial_des_ressources_critiques_policy_reform
entite: observatoire_mondial_des_ressources_critiques
scenario: policy_reform
statut: officialise_minimal

type_dans_scenario: institution

role_dans_scenario: >
  Dans le scénario policy_reform, sert de socle factuel aux réformes en fournissant les indicateurs qui légitiment ou contestent les choix de régulation des ressources.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - energie_ressources_critiques
  - gouvernance_institutions
  - geopolitique_conflits

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Observatoire Mondial des Ressources Critiques

## Rôle dans [[policy_reform]]
Dans le scénario policy_reform, sert de socle factuel aux réformes en fournissant les indicateurs qui légitiment ou contestent les choix de régulation des ressources.

## Variables influencées
- [[energie_ressources_critiques]]
- [[gouvernance_institutions]]
- [[geopolitique_conflits]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
