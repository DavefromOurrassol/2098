---
name: Collectifs de Biohackers Agro-Communautaires
type: instance
slug: collectifs_de_biohackers_agro_communautaires_policy_reform
entite: collectifs_de_biohackers_agro_communautaires
scenario: policy_reform
statut: officialise_minimal

type_dans_scenario: réseau

role_dans_scenario: >
  Dans le scénario policy_reform, représentent une force de pression diffuse contestant les politiques agricoles et biotechnologiques institutionnelles, proposant des alternatives concrètes mais juridiquement ambiguës.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - sante_biotechnologies
  - systemes_productifs_travail
  - organisation_territoires

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Collectifs de Biohackers Agro-Communautaires

## Rôle dans [[policy_reform]]
Dans le scénario policy_reform, représentent une force de pression diffuse contestant les politiques agricoles et biotechnologiques institutionnelles, proposant des alternatives concrètes mais juridiquement ambiguës.

## Variables influencées
- [[sante_biotechnologies]]
- [[systemes_productifs_travail]]
- [[organisation_territoires]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
