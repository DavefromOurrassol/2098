---
name: Front Humanitaire d'Urgence Non Affilié
type: instance
slug: front_humanitaire_d_urgence_non_affilie_breakdown
entite: front_humanitaire_d_urgence_non_affilie
scenario: breakdown
statut: officialise_minimal

type_dans_scenario: réseau

role_dans_scenario: >
  Assure une continuité minimale de secours et de coordination dans les territoires abandonnés par les institutions lors des phases aiguës d'effondrement.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - gouvernance_institutions
  - demographie_mobilite_humaine
  - organisation_territoires

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Front Humanitaire d'Urgence Non Affilié

## Rôle dans [[breakdown]]
Assure une continuité minimale de secours et de coordination dans les territoires abandonnés par les institutions lors des phases aiguës d'effondrement.

## Variables influencées
- [[gouvernance_institutions]]
- [[demographie_mobilite_humaine]]
- [[organisation_territoires]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
