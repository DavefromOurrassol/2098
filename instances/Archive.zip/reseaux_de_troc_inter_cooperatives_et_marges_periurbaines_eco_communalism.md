---
name: Réseaux de troc inter-coopératives et marges périurbaines
type: instance
slug: reseaux_de_troc_inter_cooperatives_et_marges_periurbaines_eco_communalism
entite: reseaux_de_troc_inter_cooperatives_et_marges_periurbaines
scenario: eco_communalism
statut: officialise_minimal

type_dans_scenario: réseau

role_dans_scenario: >
  Constituent l'épine dorsale économique de l'éco-communalisme, permettant la circulation des biens et services entre entités productives sans recours aux marchés ou monnaies centralisées.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - systeme_economique_redistribution
  - organisation_territoires
  - systemes_productifs_travail

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Réseaux de troc inter-coopératives et marges périurbaines

## Rôle dans [[eco_communalism]]
Constituent l'épine dorsale économique de l'éco-communalisme, permettant la circulation des biens et services entre entités productives sans recours aux marchés ou monnaies centralisées.

## Variables influencées
- [[systeme_economique_redistribution]]
- [[organisation_territoires]]
- [[systemes_productifs_travail]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
