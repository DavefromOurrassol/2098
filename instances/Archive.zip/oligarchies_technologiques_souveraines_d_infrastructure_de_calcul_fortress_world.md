---
name: Oligarchies Technologiques Souveraines d'Infrastructure de Calcul
type: instance
slug: oligarchies_technologiques_souveraines_d_infrastructure_de_calcul_fortress_world
entite: oligarchies_technologiques_souveraines_d_infrastructure_de_calcul
scenario: fortress_world
statut: officialise_minimal

type_dans_scenario: entreprise

role_dans_scenario: >
  Dans fortress_world, elles fournissent les capacités de calcul qui conditionnent l'accès à l'IA et aux systèmes décisionnels, créant une dépendance structurelle des États et acteurs économiques à leur égard.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - technologie_information
  - energie_ressources_critiques
  - gouvernance_institutions

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Oligarchies Technologiques Souveraines d'Infrastructure de Calcul

## Rôle dans [[fortress_world]]
Dans fortress_world, elles fournissent les capacités de calcul qui conditionnent l'accès à l'IA et aux systèmes décisionnels, créant une dépendance structurelle des États et acteurs économiques à leur égard.

## Variables influencées
- [[technologie_information]]
- [[energie_ressources_critiques]]
- [[gouvernance_institutions]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
