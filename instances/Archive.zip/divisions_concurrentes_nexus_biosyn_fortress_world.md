---
name: Divisions Concurrentes Nexus BioSyn
type: instance
slug: divisions_concurrentes_nexus_biosyn_fortress_world
entite: divisions_concurrentes_nexus_biosyn
scenario: fortress_world
statut: officialise_minimal

type_dans_scenario: entreprise

role_dans_scenario: >
  Dans le scénario fortress_world, ces divisions exploitent les zones de friction géopolitique comme terrains de conquête commerciale, attisant parfois les tensions pour sécuriser des contrats exclusifs en biotechnologie militaire ou sanitaire.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - geopolitique_conflits
  - sante_biotechnologies
  - organisation_territoires

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Divisions Concurrentes Nexus BioSyn

## Rôle dans [[fortress_world]]
Dans le scénario fortress_world, ces divisions exploitent les zones de friction géopolitique comme terrains de conquête commerciale, attisant parfois les tensions pour sécuriser des contrats exclusifs en biotechnologie militaire ou sanitaire.

## Variables influencées
- [[geopolitique_conflits]]
- [[sante_biotechnologies]]
- [[organisation_territoires]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
