---
name: Assemblées Bioterritoriales Régionales
type: instance
slug: assemblees_bioterritoriales_regionales_eco_communalism
entite: assemblees_bioterritoriales_regionales
scenario: eco_communalism
statut: officialise_minimal

type_dans_scenario: institution

role_dans_scenario: >
  Exercent la souveraineté territoriale en articulant gouvernance politique et logique bioécologique à l'échelle régionale.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - organisation_territoires
  - gouvernance_institutions
  - climat_environnement_global

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Assemblées Bioterritoriales Régionales

## Rôle dans [[eco_communalism]]
Exercent la souveraineté territoriale en articulant gouvernance politique et logique bioécologique à l'échelle régionale.

## Variables influencées
- [[organisation_territoires]]
- [[gouvernance_institutions]]
- [[climat_environnement_global]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
