---
name: Consortium Énergétique des Mers du Nord
type: instance
slug: consortium_energetique_des_mers_du_nord_reference
entite: consortium_energetique_des_mers_du_nord
scenario: reference
statut: officialise_minimal

type_dans_scenario: entreprise

role_dans_scenario: >
  Partie prenante clé dans les équilibres énergétiques et géopolitiques du scénario de référence, pesant sur les décisions d'approvisionnement et les rapports de force entre territoires.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - energie_ressources_critiques
  - geopolitique_conflits
  - organisation_territoires

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Consortium Énergétique des Mers du Nord

## Rôle dans [[reference]]
Partie prenante clé dans les équilibres énergétiques et géopolitiques du scénario de référence, pesant sur les décisions d'approvisionnement et les rapports de force entre territoires.

## Variables influencées
- [[energie_ressources_critiques]]
- [[geopolitique_conflits]]
- [[organisation_territoires]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
