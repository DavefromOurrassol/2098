---
name: Réseaux de maintenance d'infrastructures critiques hors-blocs
type: instance
slug: reseaux_de_maintenance_d_infrastructures_critiques_hors_blocs_fortress_world
entite: reseaux_de_maintenance_d_infrastructures_critiques_hors_blocs
scenario: fortress_world
statut: officialise_minimal

type_dans_scenario: réseau

role_dans_scenario: >
  Dans fortress_world, ces réseaux maintiennent en fonctionnement minimal les infrastructures (eau, énergie, communications) des territoires hors-blocs, constituant une forme de gouvernance technique de fait dans les zones laissées pour compte.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - organisation_territoires
  - energie_ressources_critiques
  - gouvernance_institutions

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Réseaux de maintenance d'infrastructures critiques hors-blocs

## Rôle dans [[fortress_world]]
Dans fortress_world, ces réseaux maintiennent en fonctionnement minimal les infrastructures (eau, énergie, communications) des territoires hors-blocs, constituant une forme de gouvernance technique de fait dans les zones laissées pour compte.

## Variables influencées
- [[organisation_territoires]]
- [[energie_ressources_critiques]]
- [[gouvernance_institutions]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
