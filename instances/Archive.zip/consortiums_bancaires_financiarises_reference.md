---
name: Consortiums Bancaires Financiarisés
type: instance
slug: consortiums_bancaires_financiarises_reference
entite: consortiums_bancaires_financiarises
scenario: reference
statut: officialise_minimal

type_dans_scenario: entreprise

role_dans_scenario: >
  Dans ce scénario, ils incarnent une dépendance structurelle aux infrastructures de clearing — toute fragilité de ces couches menace leur fonctionnement et, par extension, la stabilité des marchés financiers globaux.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - systeme_economique_redistribution
  - gouvernance_institutions
  - technologie_information

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Consortiums Bancaires Financiarisés

## Rôle dans [[reference]]
Dans ce scénario, ils incarnent une dépendance structurelle aux infrastructures de clearing — toute fragilité de ces couches menace leur fonctionnement et, par extension, la stabilité des marchés financiers globaux.

## Variables influencées
- [[systeme_economique_redistribution]]
- [[gouvernance_institutions]]
- [[technologie_information]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
