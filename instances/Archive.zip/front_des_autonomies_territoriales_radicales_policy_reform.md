---
name: Front des Autonomies Territoriales Radicales
type: instance
slug: front_des_autonomies_territoriales_radicales_policy_reform
entite: front_des_autonomies_territoriales_radicales
scenario: policy_reform
statut: officialise_minimal

type_dans_scenario: organisation

role_dans_scenario: >
  Dans le scénario policy_reform, représente une force de pression et de blocage face aux réformes perçues comme imposées d'en haut, mobilisant des territoires entiers pour exiger une reconfiguration radicale des structures de gouvernance.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - organisation_territoires
  - gouvernance_institutions
  - valeurs_culture_tempo_sociale

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Front des Autonomies Territoriales Radicales

## Rôle dans [[policy_reform]]
Dans le scénario policy_reform, représente une force de pression et de blocage face aux réformes perçues comme imposées d'en haut, mobilisant des territoires entiers pour exiger une reconfiguration radicale des structures de gouvernance.

## Variables influencées
- [[organisation_territoires]]
- [[gouvernance_institutions]]
- [[valeurs_culture_tempo_sociale]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
