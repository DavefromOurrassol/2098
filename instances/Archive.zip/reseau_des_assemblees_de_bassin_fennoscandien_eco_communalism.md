---
name: Réseau des Assemblées de Bassin Fennoscandien
type: instance
slug: reseau_des_assemblees_de_bassin_fennoscandien_eco_communalism
entite: reseau_des_assemblees_de_bassin_fennoscandien
scenario: eco_communalism
statut: officialise_minimal

type_dans_scenario: réseau

role_dans_scenario: >
  Structure de coordination régionale dans le scénario éco-communaliste, servant de contre-modèle aux institutions étatiques centralisées en articulant souveraineté territoriale et gestion des communs naturels.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - organisation_territoires
  - gouvernance_institutions
  - climat_environnement_global

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Réseau des Assemblées de Bassin Fennoscandien

## Rôle dans [[eco_communalism]]
Structure de coordination régionale dans le scénario éco-communaliste, servant de contre-modèle aux institutions étatiques centralisées en articulant souveraineté territoriale et gestion des communs naturels.

## Variables influencées
- [[organisation_territoires]]
- [[gouvernance_institutions]]
- [[climat_environnement_global]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
