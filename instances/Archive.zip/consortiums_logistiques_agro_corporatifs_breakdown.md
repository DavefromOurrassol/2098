---
name: Consortiums Logistiques Agro-Corporatifs
type: instance
slug: consortiums_logistiques_agro_corporatifs_breakdown
entite: consortiums_logistiques_agro_corporatifs
scenario: breakdown
statut: officialise_minimal

type_dans_scenario: entreprise

role_dans_scenario: >
  Dans un contexte de rupture systémique, tentent de reconquérir le contrôle des ressources agricoles fragmentées, s'opposant aux logiques de relocalisation ou d'autonomie alimentaire.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - systemes_productifs_travail
  - energie_ressources_critiques
  - organisation_territoires

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Consortiums Logistiques Agro-Corporatifs

## Rôle dans [[breakdown]]
Dans un contexte de rupture systémique, tentent de reconquérir le contrôle des ressources agricoles fragmentées, s'opposant aux logiques de relocalisation ou d'autonomie alimentaire.

## Variables influencées
- [[systemes_productifs_travail]]
- [[energie_ressources_critiques]]
- [[organisation_territoires]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
