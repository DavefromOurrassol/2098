---
name: Factions Étatiques Résiduelles de Souveraineté Hydrique
type: instance
slug: factions_etatiques_residuelles_de_souverainete_hydrique_breakdown
entite: factions_etatiques_residuelles_de_souverainete_hydrique
scenario: breakdown
statut: officialise_minimal

type_dans_scenario: organisation

role_dans_scenario: >
  Dans le scénario breakdown, elles fragmentent davantage l'accès à l'eau en la transformant en levier géopolitique, alimentant conflits locaux et blocages coopératifs.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - geopolitique_conflits
  - gouvernance_institutions
  - energie_ressources_critiques

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Factions Étatiques Résiduelles de Souveraineté Hydrique

## Rôle dans [[breakdown]]
Dans le scénario breakdown, elles fragmentent davantage l'accès à l'eau en la transformant en levier géopolitique, alimentant conflits locaux et blocages coopératifs.

## Variables influencées
- [[geopolitique_conflits]]
- [[gouvernance_institutions]]
- [[energie_ressources_critiques]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
