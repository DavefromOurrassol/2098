---
name: Conseil Technocratique de Gouvernance Alimentaire
type: instance
slug: conseil_technocratique_de_gouvernance_alimentaire_new_sustainability
entite: conseil_technocratique_de_gouvernance_alimentaire
scenario: new_sustainability
statut: officialise_minimal

type_dans_scenario: institution

role_dans_scenario: >
  Régule et arbitre les choix agricoles et alimentaires à l'échelle supranationale dans un contexte de contraintes climatiques et de tensions sur les ressources.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - gouvernance_institutions
  - energie_ressources_critiques
  - climat_environnement_global

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Conseil Technocratique de Gouvernance Alimentaire

## Rôle dans [[new_sustainability]]
Régule et arbitre les choix agricoles et alimentaires à l'échelle supranationale dans un contexte de contraintes climatiques et de tensions sur les ressources.

## Variables influencées
- [[gouvernance_institutions]]
- [[energie_ressources_critiques]]
- [[climat_environnement_global]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
