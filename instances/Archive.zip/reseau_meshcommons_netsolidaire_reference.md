---
name: Réseau MeshCommons-NetSolidaire
type: instance
slug: reseau_meshcommons_netsolidaire_reference
entite: reseau_meshcommons_netsolidaire
scenario: reference
statut: officialise_minimal

type_dans_scenario: réseau

role_dans_scenario: >
  Fournit une infrastructure de communication décentralisée et solidaire, constituant un contrepoids aux acteurs commerciaux dans le scénario reference.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - technologie_information
  - systeme_economique_redistribution
  - organisation_territoires

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Réseau MeshCommons-NetSolidaire

## Rôle dans [[reference]]
Fournit une infrastructure de communication décentralisée et solidaire, constituant un contrepoids aux acteurs commerciaux dans le scénario reference.

## Variables influencées
- [[technologie_information]]
- [[systeme_economique_redistribution]]
- [[organisation_territoires]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
