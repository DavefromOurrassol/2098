---
name: Collectifs Citoyens pour l'Audit Algorithmique Ouvert
type: instance
slug: collectifs_citoyens_pour_l_audit_algorithmique_ouvert_policy_reform
entite: collectifs_citoyens_pour_l_audit_algorithmique_ouvert
scenario: policy_reform
statut: officialise_minimal

type_dans_scenario: réseau

role_dans_scenario: >
  Dans le scénario policy_reform, ils exercent une pression populaire pour que toute réforme législative inclue des mécanismes contraignants d'auditabilité algorithmique, s'opposant aux logiques de boîte noire défendues par certains acteurs industriels ou étatiques.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - gouvernance_institutions
  - technologie_information
  - valeurs_culture_tempo_sociale

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Collectifs Citoyens pour l'Audit Algorithmique Ouvert

## Rôle dans [[policy_reform]]
Dans le scénario policy_reform, ils exercent une pression populaire pour que toute réforme législative inclue des mécanismes contraignants d'auditabilité algorithmique, s'opposant aux logiques de boîte noire défendues par certains acteurs industriels ou étatiques.

## Variables influencées
- [[gouvernance_institutions]]
- [[technologie_information]]
- [[valeurs_culture_tempo_sociale]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
