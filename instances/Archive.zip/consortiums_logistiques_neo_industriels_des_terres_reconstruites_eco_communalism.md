---
name: Consortiums Logistiques Néo-Industriels des Terres Reconstruites
type: instance
slug: consortiums_logistiques_neo_industriels_des_terres_reconstruites_eco_communalism
entite: consortiums_logistiques_neo_industriels_des_terres_reconstruites
scenario: eco_communalism
statut: officialise_minimal

type_dans_scenario: entreprise

role_dans_scenario: >
  Exercent une pression extractive et normalisatrice sur les terres reconstruites, contestant le contrôle communautaire des ressources et des circuits productifs locaux.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - organisation_territoires
  - systemes_productifs_travail
  - energie_ressources_critiques

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Consortiums Logistiques Néo-Industriels des Terres Reconstruites

## Rôle dans [[eco_communalism]]
Exercent une pression extractive et normalisatrice sur les terres reconstruites, contestant le contrôle communautaire des ressources et des circuits productifs locaux.

## Variables influencées
- [[organisation_territoires]]
- [[systemes_productifs_travail]]
- [[energie_ressources_critiques]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
