---
name: Factions Autoritaires Locales Identitaires Exclusionnistes
type: instance
slug: factions_autoritaires_locales_identitaires_exclusionnistes_eco_communalism
entite: factions_autoritaires_locales_identitaires_exclusionnistes
scenario: eco_communalism
statut: officialise_minimal

type_dans_scenario: autre

role_dans_scenario: >
  Faction interne ou périphérique au scénario éco-communaliste, menaçant de dériver ses principes d'autogouvernance vers des formes d'autoritarisme de proximité fondées sur l'appartenance identitaire.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - organisation_territoires
  - valeurs_culture_tempo_sociale
  - demographie_mobilite_humaine

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Factions Autoritaires Locales Identitaires Exclusionnistes

## Rôle dans [[eco_communalism]]
Faction interne ou périphérique au scénario éco-communaliste, menaçant de dériver ses principes d'autogouvernance vers des formes d'autoritarisme de proximité fondées sur l'appartenance identitaire.

## Variables influencées
- [[organisation_territoires]]
- [[valeurs_culture_tempo_sociale]]
- [[demographie_mobilite_humaine]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
