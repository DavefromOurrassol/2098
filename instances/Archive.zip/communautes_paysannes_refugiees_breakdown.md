---
name: Communautés Paysannes Réfugiées
type: instance
slug: communautes_paysannes_refugiees_breakdown
entite: communautes_paysannes_refugiees
scenario: breakdown
statut: officialise_minimal

type_dans_scenario: réseau

role_dans_scenario: >
  Dans le scénario breakdown, incarnent la fragmentation des systèmes productifs alimentaires et la pression démographique sur les territoires d'accueil, tout en portant des savoir-faire agricoles menacés de disparition.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - demographie_mobilite_humaine
  - organisation_territoires
  - systemes_productifs_travail

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Communautés Paysannes Réfugiées

## Rôle dans [[breakdown]]
Dans le scénario breakdown, incarnent la fragmentation des systèmes productifs alimentaires et la pression démographique sur les territoires d'accueil, tout en portant des savoir-faire agricoles menacés de disparition.

## Variables influencées
- [[demographie_mobilite_humaine]]
- [[organisation_territoires]]
- [[systemes_productifs_travail]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
