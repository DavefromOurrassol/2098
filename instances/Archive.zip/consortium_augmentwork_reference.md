---
name: Consortium AugmentWork
type: instance
slug: consortium_augmentwork_reference
entite: consortium_augmentwork
scenario: reference
statut: officialise_minimal

type_dans_scenario: organisation

role_dans_scenario: >
  Exerce une pression institutionnelle pour favoriser les politiques d'augmentation cognitive et physique des travailleurs, s'opposant aux régulations restrictives sur le sujet.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - systemes_productifs_travail
  - gouvernance_institutions
  - sante_biotechnologies

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Consortium AugmentWork

## Rôle dans [[reference]]
Exerce une pression institutionnelle pour favoriser les politiques d'augmentation cognitive et physique des travailleurs, s'opposant aux régulations restrictives sur le sujet.

## Variables influencées
- [[systemes_productifs_travail]]
- [[gouvernance_institutions]]
- [[sante_biotechnologies]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
