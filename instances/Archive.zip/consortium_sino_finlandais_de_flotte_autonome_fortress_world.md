---
name: Consortium Sino-Finlandais de Flotte Autonome
type: instance
slug: consortium_sino_finlandais_de_flotte_autonome_fortress_world
entite: consortium_sino_finlandais_de_flotte_autonome
scenario: fortress_world
statut: officialise_minimal

type_dans_scenario: entreprise

role_dans_scenario: >
  Fournisseur d'infrastructure de transport autonome pour États et entités privées dans le scénario fortress_world, où la maîtrise des routes maritimes conditionne l'accès aux ressources et aux territoires verrouillés.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - demographie_mobilite_humaine
  - geopolitique_conflits
  - energie_ressources_critiques

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Consortium Sino-Finlandais de Flotte Autonome

## Rôle dans [[fortress_world]]
Fournisseur d'infrastructure de transport autonome pour États et entités privées dans le scénario fortress_world, où la maîtrise des routes maritimes conditionne l'accès aux ressources et aux territoires verrouillés.

## Variables influencées
- [[demographie_mobilite_humaine]]
- [[geopolitique_conflits]]
- [[energie_ressources_critiques]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
