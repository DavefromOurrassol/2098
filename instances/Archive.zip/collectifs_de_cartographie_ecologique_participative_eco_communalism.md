---
name: Collectifs de Cartographie Écologique Participative
type: instance
slug: collectifs_de_cartographie_ecologique_participative_eco_communalism
entite: collectifs_de_cartographie_ecologique_participative
scenario: eco_communalism
statut: officialise_minimal

type_dans_scenario: réseau

role_dans_scenario: >
  Dans le scénario eco_communalism, servent d'infrastructure cognitive distribuée permettant aux communautés de documenter, négocier et défendre leurs territoires écologiques sans dépendre d'institutions centralisées.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - organisation_territoires
  - climat_environnement_global
  - technologie_information

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Collectifs de Cartographie Écologique Participative

## Rôle dans [[eco_communalism]]
Dans le scénario eco_communalism, servent d'infrastructure cognitive distribuée permettant aux communautés de documenter, négocier et défendre leurs territoires écologiques sans dépendre d'institutions centralisées.

## Variables influencées
- [[organisation_territoires]]
- [[climat_environnement_global]]
- [[technologie_information]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
