---
name: Réseaux Noirs Pharmaceutiques
type: instance
slug: reseaux_noirs_pharmaceutiques_breakdown
entite: reseaux_noirs_pharmaceutiques
scenario: breakdown
statut: officialise_minimal

type_dans_scenario: réseau

role_dans_scenario: >
  Dans le scénario breakdown, comblent le vide laissé par l'effondrement des systèmes de santé officiels, devenant paradoxalement des fournisseurs de soins de facto pour des populations abandonnées.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - sante_biotechnologies
  - gouvernance_institutions
  - organisation_territoires

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Réseaux Noirs Pharmaceutiques

## Rôle dans [[breakdown]]
Dans le scénario breakdown, comblent le vide laissé par l'effondrement des systèmes de santé officiels, devenant paradoxalement des fournisseurs de soins de facto pour des populations abandonnées.

## Variables influencées
- [[sante_biotechnologies]]
- [[gouvernance_institutions]]
- [[organisation_territoires]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
