---
name: Front des Blocs Régionaux du Récit des Conflits-Ressources
type: instance
slug: front_des_blocs_regionaux_du_recit_des_conflits_ressources_breakdown
entite: front_des_blocs_regionaux_du_recit_des_conflits_ressources
scenario: breakdown
statut: officialise_minimal

type_dans_scenario: organisation

role_dans_scenario: >
  Dans le scénario breakdown, exerce une pression narrative concurrente pour légitimer ses positions dans les disputes territoriales et énergétiques au détriment d'un récit global cohérent.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - geopolitique_conflits
  - technologie_information
  - energie_ressources_critiques

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Front des Blocs Régionaux du Récit des Conflits-Ressources

## Rôle dans [[breakdown]]
Dans le scénario breakdown, exerce une pression narrative concurrente pour légitimer ses positions dans les disputes territoriales et énergétiques au détriment d'un récit global cohérent.

## Variables influencées
- [[geopolitique_conflits]]
- [[technologie_information]]
- [[energie_ressources_critiques]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
