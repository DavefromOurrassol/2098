---
name: Réseau des Communs Alimentaires Hors-Grille
type: instance
slug: reseau_des_communs_alimentaires_hors_grille_new_sustainability
entite: reseau_des_communs_alimentaires_hors_grille
scenario: new_sustainability
statut: officialise_minimal

type_dans_scenario: réseau

role_dans_scenario: >
  Représente une force de résistance et d'alternative concrète aux modèles alimentaires hégémoniques dans le scénario new_sustainability, incarnant la tension entre autonomie locale et intégration systémique.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - organisation_territoires
  - systemes_productifs_travail
  - climat_environnement_global

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Réseau des Communs Alimentaires Hors-Grille

## Rôle dans [[new_sustainability]]
Représente une force de résistance et d'alternative concrète aux modèles alimentaires hégémoniques dans le scénario new_sustainability, incarnant la tension entre autonomie locale et intégration systémique.

## Variables influencées
- [[organisation_territoires]]
- [[systemes_productifs_travail]]
- [[climat_environnement_global]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
