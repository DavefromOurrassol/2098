---
name: Collectifs d'Ingénieurs Dissidents Anti-Militarisation
type: instance
slug: collectifs_d_ingenieurs_dissidents_anti_militarisation_fortress_world
entite: collectifs_d_ingenieurs_dissidents_anti_militarisation
scenario: fortress_world
statut: officialise_minimal

type_dans_scenario: réseau

role_dans_scenario: >
  Dans fortress_world, ils constituent un point de friction interne au système de militarisation technologique, potentiellement saboteurs, fournisseurs de technologies alternatives ou alliés des mouvements civils d'opposition.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - technologie_information
  - geopolitique_conflits
  - gouvernance_institutions

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Collectifs d'Ingénieurs Dissidents Anti-Militarisation

## Rôle dans [[fortress_world]]
Dans fortress_world, ils constituent un point de friction interne au système de militarisation technologique, potentiellement saboteurs, fournisseurs de technologies alternatives ou alliés des mouvements civils d'opposition.

## Variables influencées
- [[technologie_information]]
- [[geopolitique_conflits]]
- [[gouvernance_institutions]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
