---
name: Collectifs de Gouvernance Communautaire Décentralisée
type: instance
slug: collectifs_de_gouvernance_communautaire_decentralisee_policy_reform
entite: collectifs_de_gouvernance_communautaire_decentralisee
scenario: policy_reform
statut: officialise_minimal

type_dans_scenario: réseau

role_dans_scenario: >
  Dans le scénario policy_reform, ces collectifs constituent une force de pression et d'expérimentation alternative aux réformes institutionnelles descendantes, portant des modèles de décision participatifs concurrents.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - gouvernance_institutions
  - organisation_territoires
  - valeurs_culture_tempo_sociale

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Collectifs de Gouvernance Communautaire Décentralisée

## Rôle dans [[policy_reform]]
Dans le scénario policy_reform, ces collectifs constituent une force de pression et d'expérimentation alternative aux réformes institutionnelles descendantes, portant des modèles de décision participatifs concurrents.

## Variables influencées
- [[gouvernance_institutions]]
- [[organisation_territoires]]
- [[valeurs_culture_tempo_sociale]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
