---
name: États Dissidents du Bloc Austral
type: instance
slug: etats_dissidents_du_bloc_austral_policy_reform
entite: etats_dissidents_du_bloc_austral
scenario: policy_reform
statut: officialise_minimal

type_dans_scenario: institution

role_dans_scenario: >
  Dans le scénario policy_reform, ces États constituent un point de résistance aux réformes de gouvernance supranationale, forçant les négociateurs à composer avec des logiques dissidentes au sein même du bloc.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - gouvernance_institutions
  - geopolitique_conflits
  - organisation_territoires

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# États Dissidents du Bloc Austral

## Rôle dans [[policy_reform]]
Dans le scénario policy_reform, ces États constituent un point de résistance aux réformes de gouvernance supranationale, forçant les négociateurs à composer avec des logiques dissidentes au sein même du bloc.

## Variables influencées
- [[gouvernance_institutions]]
- [[geopolitique_conflits]]
- [[organisation_territoires]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
