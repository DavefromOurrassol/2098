---
name: Factions Anti-Privatisation des Voies Souveraines Scandinaves
type: instance
slug: factions_anti_privatisation_des_voies_souveraines_scandinaves_fortress_world
entite: factions_anti_privatisation_des_voies_souveraines_scandinaves
scenario: fortress_world
statut: officialise_minimal

type_dans_scenario: organisation

role_dans_scenario: >
  Dans fortress_world, elles freinent ou contestent les transferts de contrôle des voies souveraines vers des opérateurs privés, maintenant un front institutionnel contre la marchandisation des accès territoriaux.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - gouvernance_institutions
  - organisation_territoires
  - frontieres_du_systeme

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Factions Anti-Privatisation des Voies Souveraines Scandinaves

## Rôle dans [[fortress_world]]
Dans fortress_world, elles freinent ou contestent les transferts de contrôle des voies souveraines vers des opérateurs privés, maintenant un front institutionnel contre la marchandisation des accès territoriaux.

## Variables influencées
- [[gouvernance_institutions]]
- [[organisation_territoires]]
- [[frontieres_du_systeme]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
