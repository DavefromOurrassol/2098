---
name: Mouvement pour la Libre Circulation des Personnes et des Données
type: instance
slug: mouvement_pour_la_libre_circulation_des_personnes_et_des_donnees_reference
entite: mouvement_pour_la_libre_circulation_des_personnes_et_des_donnees
scenario: reference
statut: officialise_minimal

type_dans_scenario: organisation

role_dans_scenario: >
  Pression sur les institutions pour abolir ou contourner les barrières à la mobilité humaine et numérique dans un contexte de re-fragmentation des espaces.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - demographie_mobilite_humaine
  - frontieres_du_systeme
  - technologie_information

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Mouvement pour la Libre Circulation des Personnes et des Données

## Rôle dans [[reference]]
Pression sur les institutions pour abolir ou contourner les barrières à la mobilité humaine et numérique dans un contexte de re-fragmentation des espaces.

## Variables influencées
- [[demographie_mobilite_humaine]]
- [[frontieres_du_systeme]]
- [[technologie_information]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
