---
name: Lobbies Industriels des États Non-Signataires
type: instance
slug: lobbies_industriels_des_etats_non_signataires_reference
entite: lobbies_industriels_des_etats_non_signataires
scenario: reference
statut: officialise_minimal

type_dans_scenario: organisation

role_dans_scenario: >
  Freinent l'adoption ou l'extension de normes contraignantes en jouant sur la souveraineté des États non-signataires et les asymétries compétitives avec les pays signataires.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - gouvernance_institutions
  - geopolitique_conflits
  - energie_ressources_critiques

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Lobbies Industriels des États Non-Signataires

## Rôle dans [[reference]]
Freinent l'adoption ou l'extension de normes contraignantes en jouant sur la souveraineté des États non-signataires et les asymétries compétitives avec les pays signataires.

## Variables influencées
- [[gouvernance_institutions]]
- [[geopolitique_conflits]]
- [[energie_ressources_critiques]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
