---
name: Conseils de Bassin Versant Éco-Communalistes
type: instance
slug: conseils_de_bassin_versant_eco_communalistes_eco_communalism
entite: conseils_de_bassin_versant_eco_communalistes
scenario: eco_communalism
statut: officialise_minimal

type_dans_scenario: institution

role_dans_scenario: >
  Dans le scénario eco_communalism, ces conseils constituent la colonne vertébrale institutionnelle du modèle éco-communaliste, gérant les communs naturels à l'échelle des écosystèmes plutôt que des frontières administratives héritées.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - organisation_territoires
  - gouvernance_institutions
  - climat_environnement_global

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Conseils de Bassin Versant Éco-Communalistes

## Rôle dans [[eco_communalism]]
Dans le scénario eco_communalism, ces conseils constituent la colonne vertébrale institutionnelle du modèle éco-communaliste, gérant les communs naturels à l'échelle des écosystèmes plutôt que des frontières administratives héritées.

## Variables influencées
- [[organisation_territoires]]
- [[gouvernance_institutions]]
- [[climat_environnement_global]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
