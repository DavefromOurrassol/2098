---
name: Cartels de Narration de Pénurie
type: instance
slug: cartels_de_narration_de_penurie_eco_communalism
entite: cartels_de_narration_de_penurie
scenario: eco_communalism
statut: officialise_minimal

type_dans_scenario: réseau

role_dans_scenario: >
  Dans le scénario eco_communalism, ils constituent une force de déstabilisation des économies communalistes en manipulant les croyances locales sur la rareté, fragilisant la confiance et la coopération entre communautés.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - technologie_information
  - systeme_economique_redistribution
  - valeurs_culture_tempo_sociale

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Cartels de Narration de Pénurie

## Rôle dans [[eco_communalism]]
Dans le scénario eco_communalism, ils constituent une force de déstabilisation des économies communalistes en manipulant les croyances locales sur la rareté, fragilisant la confiance et la coopération entre communautés.

## Variables influencées
- [[technologie_information]]
- [[systeme_economique_redistribution]]
- [[valeurs_culture_tempo_sociale]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
