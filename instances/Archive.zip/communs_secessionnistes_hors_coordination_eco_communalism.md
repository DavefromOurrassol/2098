---
name: Communs Sécessionnistes Hors-Coordination
type: instance
slug: communs_secessionnistes_hors_coordination_eco_communalism
entite: communs_secessionnistes_hors_coordination
scenario: eco_communalism
statut: officialise_minimal

type_dans_scenario: réseau

role_dans_scenario: >
  Représente la frange radicale de l'éco-communalisme qui pousse l'autonomie locale jusqu'à la sécession institutionnelle, mettant en tension les tentatives de coordination régionale ou globale.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - organisation_territoires
  - gouvernance_institutions
  - frontieres_du_systeme

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Communs Sécessionnistes Hors-Coordination

## Rôle dans [[eco_communalism]]
Représente la frange radicale de l'éco-communalisme qui pousse l'autonomie locale jusqu'à la sécession institutionnelle, mettant en tension les tentatives de coordination régionale ou globale.

## Variables influencées
- [[organisation_territoires]]
- [[gouvernance_institutions]]
- [[frontieres_du_systeme]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
