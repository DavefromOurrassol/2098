---
name: Factions Autoritaires de Contrôle du Savoir
type: instance
slug: factions_autoritaires_de_controle_du_savoir_eco_communalism
entite: factions_autoritaires_de_controle_du_savoir
scenario: eco_communalism
statut: officialise_minimal

type_dans_scenario: autre

role_dans_scenario: >
  Dans le scénario éco-communaliste, elles représentent une pression externe et interne cherchant à réintroduire des hiérarchies de contrôle informationnel contre les pratiques de partage horizontal des communautés.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - technologie_information
  - gouvernance_institutions
  - valeurs_culture_tempo_sociale

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Factions Autoritaires de Contrôle du Savoir

## Rôle dans [[eco_communalism]]
Dans le scénario éco-communaliste, elles représentent une pression externe et interne cherchant à réintroduire des hiérarchies de contrôle informationnel contre les pratiques de partage horizontal des communautés.

## Variables influencées
- [[technologie_information]]
- [[gouvernance_institutions]]
- [[valeurs_culture_tempo_sociale]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
