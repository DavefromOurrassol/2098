---
name: Fraternités Écospiritualistes des Anciens Survivalistes
type: instance
slug: fraternites_ecospiritualistes_des_anciens_survivalistes_eco_communalism
entite: fraternites_ecospiritualistes_des_anciens_survivalistes
scenario: eco_communalism
statut: officialise_minimal

type_dans_scenario: organisation

role_dans_scenario: >
  Dans le scénario eco_communalism, elles incarnent un modèle d'organisation territoriale autonome fondé sur des rituels écologiques et des savoirs de subsistance transmis entre générations, constituant des nœuds de gouvernance locale alternatifs aux structures institutionnelles dominantes.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - organisation_territoires
  - valeurs_culture_tempo_sociale
  - climat_environnement_global

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Fraternités Écospiritualistes des Anciens Survivalistes

## Rôle dans [[eco_communalism]]
Dans le scénario eco_communalism, elles incarnent un modèle d'organisation territoriale autonome fondé sur des rituels écologiques et des savoirs de subsistance transmis entre générations, constituant des nœuds de gouvernance locale alternatifs aux structures institutionnelles dominantes.

## Variables influencées
- [[organisation_territoires]]
- [[valeurs_culture_tempo_sociale]]
- [[climat_environnement_global]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
