---
name: Parlement Délibératif Mondial
type: instance
slug: parlement_deliberatif_mondial_new_sustainability
entite: parlement_deliberatif_mondial
scenario: new_sustainability
statut: officialise_minimal

type_dans_scenario: institution

role_dans_scenario: >
  Dans le scénario new_sustainability, sert d'arène de légitimation ou de contestation des grandes décisions environnementales et économiques globales, en tension avec les gouvernements nationaux et les blocs régionaux.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - gouvernance_institutions
  - climat_environnement_global
  - organisation_territoires

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Parlement Délibératif Mondial

## Rôle dans [[new_sustainability]]
Dans le scénario new_sustainability, sert d'arène de légitimation ou de contestation des grandes décisions environnementales et économiques globales, en tension avec les gouvernements nationaux et les blocs régionaux.

## Variables influencées
- [[gouvernance_institutions]]
- [[climat_environnement_global]]
- [[organisation_territoires]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
