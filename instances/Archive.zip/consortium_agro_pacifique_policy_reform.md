---
name: Consortium Agro-Pacifique
type: instance
slug: consortium_agro_pacifique_policy_reform
entite: consortium_agro_pacifique
scenario: policy_reform
statut: officialise_minimal

type_dans_scenario: entreprise

role_dans_scenario: >
  Acteur clé dans les négociations de réforme politique, pesant sur les régulations agricoles et les standards alimentaires à l'échelle régionale.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - systemes_productifs_travail
  - organisation_territoires
  - gouvernance_institutions

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Consortium Agro-Pacifique

## Rôle dans [[policy_reform]]
Acteur clé dans les négociations de réforme politique, pesant sur les régulations agricoles et les standards alimentaires à l'échelle régionale.

## Variables influencées
- [[systemes_productifs_travail]]
- [[organisation_territoires]]
- [[gouvernance_institutions]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
