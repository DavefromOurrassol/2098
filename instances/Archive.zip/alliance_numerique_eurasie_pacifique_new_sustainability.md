---
name: Alliance Numérique Eurasie-Pacifique
type: instance
slug: alliance_numerique_eurasie_pacifique_new_sustainability
entite: alliance_numerique_eurasie_pacifique
scenario: new_sustainability
statut: officialise_minimal

type_dans_scenario: organisation

role_dans_scenario: >
  Dans le scénario new_sustainability, cette alliance pèse sur la gouvernance des infrastructures numériques liées à la transition écologique, en imposant ses propres normes de durabilité et de partage des données.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - geopolitique_conflits
  - technologie_information
  - gouvernance_institutions

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Alliance Numérique Eurasie-Pacifique

## Rôle dans [[new_sustainability]]
Dans le scénario new_sustainability, cette alliance pèse sur la gouvernance des infrastructures numériques liées à la transition écologique, en imposant ses propres normes de durabilité et de partage des données.

## Variables influencées
- [[geopolitique_conflits]]
- [[technologie_information]]
- [[gouvernance_institutions]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
