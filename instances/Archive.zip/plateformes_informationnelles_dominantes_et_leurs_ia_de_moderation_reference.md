---
name: Plateformes Informationnelles Dominantes et leurs IA de Modération
type: instance
slug: plateformes_informationnelles_dominantes_et_leurs_ia_de_moderation_reference
entite: plateformes_informationnelles_dominantes_et_leurs_ia_de_moderation
scenario: reference
statut: officialise_minimal

type_dans_scenario: système

role_dans_scenario: >
  Dans le scénario reference, elles forment le substrat technologique sur lequel circule (ou est bloquée) l'information, agissant comme arbitres de facto de ce qui est visible, crédible ou audible.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - technologie_information
  - gouvernance_institutions
  - valeurs_culture_tempo_sociale

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Plateformes Informationnelles Dominantes et leurs IA de Modération

## Rôle dans [[reference]]
Dans le scénario reference, elles forment le substrat technologique sur lequel circule (ou est bloquée) l'information, agissant comme arbitres de facto de ce qui est visible, crédible ou audible.

## Variables influencées
- [[technologie_information]]
- [[gouvernance_institutions]]
- [[valeurs_culture_tempo_sociale]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
