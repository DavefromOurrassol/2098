---
name: Réseau des Anciens Financeurs Devenus Censeurs
type: instance
slug: reseau_des_anciens_financeurs_devenus_censeurs_breakdown
entite: reseau_des_anciens_financeurs_devenus_censeurs
scenario: breakdown
statut: officialise_minimal

type_dans_scenario: réseau

role_dans_scenario: >
  Dans le scénario breakdown, ils incarnent le retournement cynique des logiques de financement en instruments de censure, accélérant l'effondrement de la confiance dans les médias indépendants.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - technologie_information
  - gouvernance_institutions
  - systeme_economique_redistribution

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Réseau des Anciens Financeurs Devenus Censeurs

## Rôle dans [[breakdown]]
Dans le scénario breakdown, ils incarnent le retournement cynique des logiques de financement en instruments de censure, accélérant l'effondrement de la confiance dans les médias indépendants.

## Variables influencées
- [[technologie_information]]
- [[gouvernance_institutions]]
- [[systeme_economique_redistribution]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
