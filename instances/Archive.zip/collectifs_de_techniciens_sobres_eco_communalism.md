---
name: Collectifs de Techniciens Sobres
type: instance
slug: collectifs_de_techniciens_sobres_eco_communalism
entite: collectifs_de_techniciens_sobres
scenario: eco_communalism
statut: officialise_minimal

type_dans_scenario: réseau

role_dans_scenario: >
  Fournissent aux communautés éco-communalistes les compétences techniques nécessaires pour maintenir des infrastructures autonomes sans dépendre de chaînes d'approvisionnement industrielles.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - energie_ressources_critiques
  - systemes_productifs_travail
  - technologie_information

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Collectifs de Techniciens Sobres

## Rôle dans [[eco_communalism]]
Fournissent aux communautés éco-communalistes les compétences techniques nécessaires pour maintenir des infrastructures autonomes sans dépendre de chaînes d'approvisionnement industrielles.

## Variables influencées
- [[energie_ressources_critiques]]
- [[systemes_productifs_travail]]
- [[technologie_information]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
