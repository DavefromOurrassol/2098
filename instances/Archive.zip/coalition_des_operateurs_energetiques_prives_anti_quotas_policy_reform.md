---
name: Coalition des Opérateurs Énergétiques Privés Anti-Quotas
type: instance
slug: coalition_des_operateurs_energetiques_prives_anti_quotas_policy_reform
entite: coalition_des_operateurs_energetiques_prives_anti_quotas
scenario: policy_reform
statut: officialise_minimal

type_dans_scenario: organisation

role_dans_scenario: >
  Force d'opposition aux réformes réglementaires dans le secteur énergétique, pesant sur les négociations de politique publique pour limiter ou contourner les quotas contraignants.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - energie_ressources_critiques
  - gouvernance_institutions
  - systeme_economique_redistribution

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Coalition des Opérateurs Énergétiques Privés Anti-Quotas

## Rôle dans [[policy_reform]]
Force d'opposition aux réformes réglementaires dans le secteur énergétique, pesant sur les négociations de politique publique pour limiter ou contourner les quotas contraignants.

## Variables influencées
- [[energie_ressources_critiques]]
- [[gouvernance_institutions]]
- [[systeme_economique_redistribution]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
