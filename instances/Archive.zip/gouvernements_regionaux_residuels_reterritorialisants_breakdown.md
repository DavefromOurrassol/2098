---
name: Gouvernements Régionaux Résiduels Reterritorialisants
type: instance
slug: gouvernements_regionaux_residuels_reterritorialisants_breakdown
entite: gouvernements_regionaux_residuels_reterritorialisants
scenario: breakdown
statut: officialise_minimal

type_dans_scenario: institution

role_dans_scenario: >
  Acteurs de reconsolidation institutionnelle dans un contexte de breakdown, en compétition ou coopération conflictuelle avec d'autres forces (réseaux privés, communautés autonomes, IA de gestion) pour le contrôle de ressources et de populations.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - organisation_territoires
  - gouvernance_institutions
  - geopolitique_conflits

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Gouvernements Régionaux Résiduels Reterritorialisants

## Rôle dans [[breakdown]]
Acteurs de reconsolidation institutionnelle dans un contexte de breakdown, en compétition ou coopération conflictuelle avec d'autres forces (réseaux privés, communautés autonomes, IA de gestion) pour le contrôle de ressources et de populations.

## Variables influencées
- [[organisation_territoires]]
- [[gouvernance_institutions]]
- [[geopolitique_conflits]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
