---
name: Réseau des Métropoles Côtières Adaptées
type: instance
slug: reseau_des_metropoles_cotieres_adaptees_reference
entite: reseau_des_metropoles_cotieres_adaptees
scenario: reference
statut: officialise_minimal

type_dans_scenario: réseau

role_dans_scenario: >
  Acteur collectif structurant la gouvernance territoriale des zones côtières en 2098, pesant sur les arbitrages entre adaptation, relocalisation et maintien des populations littorales.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - organisation_territoires
  - climat_environnement_global
  - demographie_mobilite_humaine

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Réseau des Métropoles Côtières Adaptées

## Rôle dans [[reference]]
Acteur collectif structurant la gouvernance territoriale des zones côtières en 2098, pesant sur les arbitrages entre adaptation, relocalisation et maintien des populations littorales.

## Variables influencées
- [[organisation_territoires]]
- [[climat_environnement_global]]
- [[demographie_mobilite_humaine]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
