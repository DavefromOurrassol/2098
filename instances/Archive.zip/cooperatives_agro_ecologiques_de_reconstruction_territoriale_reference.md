---
name: Coopératives Agro-Écologiques de Reconstruction Territoriale
type: instance
slug: cooperatives_agro_ecologiques_de_reconstruction_territoriale_reference
entite: cooperatives_agro_ecologiques_de_reconstruction_territoriale
scenario: reference
statut: officialise_minimal

type_dans_scenario: organisation

role_dans_scenario: >
  Dans le scénario de référence, elles représentent un acteur clé de la reconstruction territoriale par l'agriculture, en tension ou en alliance avec d'autres forces économiques et institutionnelles.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - organisation_territoires
  - systemes_productifs_travail
  - climat_environnement_global

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Coopératives Agro-Écologiques de Reconstruction Territoriale

## Rôle dans [[reference]]
Dans le scénario de référence, elles représentent un acteur clé de la reconstruction territoriale par l'agriculture, en tension ou en alliance avec d'autres forces économiques et institutionnelles.

## Variables influencées
- [[organisation_territoires]]
- [[systemes_productifs_travail]]
- [[climat_environnement_global]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
