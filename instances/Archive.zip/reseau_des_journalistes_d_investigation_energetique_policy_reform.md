---
name: Réseau des Journalistes d'Investigation Énergétique
type: instance
slug: reseau_des_journalistes_d_investigation_energetique_policy_reform
entite: reseau_des_journalistes_d_investigation_energetique
scenario: policy_reform
statut: officialise_minimal

type_dans_scenario: réseau

role_dans_scenario: >
  Dans le scénario policy_reform, ce réseau exerce une pression informationnelle sur les institutions en exposant les opacités des réformes énergétiques et en alimentant le débat public avec des données vérifiées.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - energie_ressources_critiques
  - gouvernance_institutions
  - technologie_information

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Réseau des Journalistes d'Investigation Énergétique

## Rôle dans [[policy_reform]]
Dans le scénario policy_reform, ce réseau exerce une pression informationnelle sur les institutions en exposant les opacités des réformes énergétiques et en alimentant le débat public avec des données vérifiées.

## Variables influencées
- [[energie_ressources_critiques]]
- [[gouvernance_institutions]]
- [[technologie_information]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
