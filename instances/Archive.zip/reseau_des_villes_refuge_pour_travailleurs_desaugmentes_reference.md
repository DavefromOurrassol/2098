---
name: Réseau des Villes-Refuge pour Travailleurs Désaugmentés
type: instance
slug: reseau_des_villes_refuge_pour_travailleurs_desaugmentes_reference
entite: reseau_des_villes_refuge_pour_travailleurs_desaugmentes
scenario: reference
statut: officialise_minimal

type_dans_scenario: réseau

role_dans_scenario: >
  Fournit une infrastructure d'accueil et de reconversion pour les populations désaugmentées marginalisées, en tension avec les logiques économiques dominantes liées à l'augmentation.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - demographie_mobilite_humaine
  - systemes_productifs_travail
  - organisation_territoires

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Réseau des Villes-Refuge pour Travailleurs Désaugmentés

## Rôle dans [[reference]]
Fournit une infrastructure d'accueil et de reconversion pour les populations désaugmentées marginalisées, en tension avec les logiques économiques dominantes liées à l'augmentation.

## Variables influencées
- [[demographie_mobilite_humaine]]
- [[systemes_productifs_travail]]
- [[organisation_territoires]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
