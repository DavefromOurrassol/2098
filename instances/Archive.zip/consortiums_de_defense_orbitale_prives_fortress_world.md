---
name: Consortiums de Défense Orbitale Privés
type: instance
slug: consortiums_de_defense_orbitale_prives_fortress_world
entite: consortiums_de_defense_orbitale_prives
scenario: fortress_world
statut: officialise_minimal

type_dans_scenario: organisation

role_dans_scenario: >
  Dans fortress_world, ils constituent l'épine dorsale de l'architecture défensive des blocs dominants, gérant l'accès orbital comme un actif commercial et sécuritaire fusionné.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - geopolitique_conflits
  - frontieres_du_systeme
  - energie_ressources_critiques

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Consortiums de Défense Orbitale Privés

## Rôle dans [[fortress_world]]
Dans fortress_world, ils constituent l'épine dorsale de l'architecture défensive des blocs dominants, gérant l'accès orbital comme un actif commercial et sécuritaire fusionné.

## Variables influencées
- [[geopolitique_conflits]]
- [[frontieres_du_systeme]]
- [[energie_ressources_critiques]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
