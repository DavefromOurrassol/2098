---
name: Fronts Populistes Anti-Technocratiques
type: instance
slug: fronts_populistes_anti_technocratiques_breakdown
entite: fronts_populistes_anti_technocratiques
scenario: breakdown
statut: officialise_minimal

type_dans_scenario: organisation

role_dans_scenario: >
  Dans le scénario breakdown, ils incarnent la pression déstabilisatrice sur les institutions affaiblies, contestant la légitimité des mécanismes de décision technicisés au moment où ceux-ci montrent leurs limites.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - gouvernance_institutions
  - valeurs_culture_tempo_sociale
  - organisation_territoires

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Fronts Populistes Anti-Technocratiques

## Rôle dans [[breakdown]]
Dans le scénario breakdown, ils incarnent la pression déstabilisatrice sur les institutions affaiblies, contestant la légitimité des mécanismes de décision technicisés au moment où ceux-ci montrent leurs limites.

## Variables influencées
- [[gouvernance_institutions]]
- [[valeurs_culture_tempo_sociale]]
- [[organisation_territoires]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
