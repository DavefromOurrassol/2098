---
name: Consortium des Plateformes IA Centralisées Anti-Délibération
type: instance
slug: consortium_des_plateformes_ia_centralisees_anti_deliberation_reference
entite: consortium_des_plateformes_ia_centralisees_anti_deliberation
scenario: reference
statut: officialise_minimal

type_dans_scenario: organisation

role_dans_scenario: >
  Dans ce scénario, constitue le principal bloc de résistance institutionnelle aux mécanismes de délibération obligatoire imposés aux IA, lobbying actif contre les cadres réglementaires contraignants.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - technologie_information
  - gouvernance_institutions
  - systeme_economique_redistribution

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Consortium des Plateformes IA Centralisées Anti-Délibération

## Rôle dans [[reference]]
Dans ce scénario, constitue le principal bloc de résistance institutionnelle aux mécanismes de délibération obligatoire imposés aux IA, lobbying actif contre les cadres réglementaires contraignants.

## Variables influencées
- [[technologie_information]]
- [[gouvernance_institutions]]
- [[systeme_economique_redistribution]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
