---
name: Lobbies Agro-Industriels du Bassin du Congo
type: instance
slug: lobbies_agro_industriels_du_bassin_du_congo_new_sustainability
entite: lobbies_agro_industriels_du_bassin_du_congo
scenario: new_sustainability
statut: officialise_minimal

type_dans_scenario: organisation

role_dans_scenario: >
  Frein structurel aux politiques de durabilité dans la région, exerçant une pression sur les gouvernements locaux pour maintenir des régimes d'exploitation permissifs face aux nouvelles normes environnementales de 2098.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - climat_environnement_global
  - gouvernance_institutions
  - systemes_productifs_travail

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Lobbies Agro-Industriels du Bassin du Congo

## Rôle dans [[new_sustainability]]
Frein structurel aux politiques de durabilité dans la région, exerçant une pression sur les gouvernements locaux pour maintenir des régimes d'exploitation permissifs face aux nouvelles normes environnementales de 2098.

## Variables influencées
- [[climat_environnement_global]]
- [[gouvernance_institutions]]
- [[systemes_productifs_travail]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
