---
name: Réseaux privés de sécurité aux frontières
type: instance
slug: reseaux_prives_de_securite_aux_frontieres_fortress_world
entite: reseaux_prives_de_securite_aux_frontieres
scenario: fortress_world
statut: officialise_minimal

type_dans_scenario: organisation

role_dans_scenario: >
  Dans fortress_world, incarnent la privatisation du contrôle territorial et la marchandisation de la sécurité migratoire, substituant la logique commerciale à la responsabilité étatique aux marges du système.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - demographie_mobilite_humaine
  - organisation_territoires
  - gouvernance_institutions

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Réseaux privés de sécurité aux frontières

## Rôle dans [[fortress_world]]
Dans fortress_world, incarnent la privatisation du contrôle territorial et la marchandisation de la sécurité migratoire, substituant la logique commerciale à la responsabilité étatique aux marges du système.

## Variables influencées
- [[demographie_mobilite_humaine]]
- [[organisation_territoires]]
- [[gouvernance_institutions]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
