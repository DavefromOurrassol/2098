---
name: Fédération des Communs Territoriaux
type: instance
slug: federation_communs_territoriaux_reference
entite: federation_communs_territoriaux
scenario: reference
localisation:
  zone: null
  lieu: null
  type_lieu: null
  note: transnationale_sans_ancrage

type_dans_scenario: institution

role_dans_scenario: >
  Dans un monde en équilibre fragile, la FCT s'est imposée comme une architecture institutionnelle intermédiaire — ni État souverain, ni simple collectivité locale. Elle fédère quelque 340 bassins de vie à travers cinq continents, chacun gérant ses propres communs énergétiques, alimentaires et juridiques. Elle joue un rôle de contrepoids structurel aux mégapoles globales et aux plateformes techno-économiques dominantes, sans parvenir à s'y opposer frontalement. Sa légitimité repose sur sa capacité à absorber les chocs climatiques locaux là où les États centraux échouent, mais cette légitimité reste disputée et inégalement reconnue.

responsabilites: >
  La FCT coordonne les protocoles de souveraineté alimentaire entre bassins membres, négocie des accords d'interopérabilité énergétique avec des opérateurs privés et publics, et maintient un corpus juridique commun — le Droit des Communs Vivants — applicable à l'échelle des territoires affiliés. Elle gère également des fonds de résilience climatique mutualisés, abondés en partie par des mécanismes de compensation carbone contestés.

impact_local: 4
impact_systemique_global: 3
variables_influencees:
    - organisation_territoires
    - climat_environnement_global
    - systeme_economique_redistribution
    - energie_ressources_critiques

zone_geographique:
    - régionale
    - continentale

zone_systemique:
    - gouvernance
    - énergie
    - économie
    - société
    - infrastructure

alliances:
    - cooperatives_agro_ecologiques_du_bassin_mediterraneen_reference
    - observatoire_climatique_des_territoires_oct_reference
    - banque_des_communs_reference
    - syndicats_de_travailleurs_de_la_transition_energetique_reference

oppositions:
    - consortium_des_grandes_plateformes_logistiques_globales_reference
    - gouvernements_federaux_residuels_souverainistes_reference
    - operateurs_prives_d_energie_distribuee_hors_fct_reference
    - confederation_des_megapoles_autonomes_reference

type_relation_dominante: rivalité

annee_debut: 2041
annee_fin: 

etat_temporel: actif
age_historique: ascendant
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  Depuis son siège tournant — cette saison à Valparaíso, la prochaine à Tampere — la Fédération des Communs Territoriaux continue de défier les catégories politiques héritées du XXe siècle. Ni État, ni ONG, ni syndicat : quelque chose d'obstinément entre les deux. Ses délégués, élus dans des assemblées de bassin souvent houleuses, négocient chaque trimestre des protocoles d'urgence climatique que les gouvernements nationaux n'arrivent plus à imposer seuls. Mais la FCT montre aussi ses failles : des membres dissidents quittent le réseau pour rejoindre des blocs mégapolitains plus puissants, et ses fonds de résilience sont régulièrement insuffisants face à l'intensité des événements extrêmes. Elle tient, mais personne ne sait vraiment jusqu'à quand.

signes_distinctifs: >
  Le logo de la FCT représente un rhizome stylisé en fil de cuivre sur fond de cartographie topographique — symbole délibéré de l'horizontalité et de l'enracinement. Ses documents officiels sont bilingues en langue locale et en Commun Interterritorial, un créole administratif développé en interne. Les délégués portent un badge de bassin personnalisé, refus explicite de l'uniforme institutionnel classique.

tensions_narratives: >
  La FCT est tiraillée entre son idéal d'autonomie radicale et la nécessité croissante de s'interfacer avec des systèmes globaux qu'elle ne contrôle pas — réseaux d'IA industrielle, plateformes logistiques, marchés carbone. Certains bassins membres réclament une fédéralisation plus forte au risque de perdre leur souveraineté locale, tandis que d'autres menacent de sécession pour rejoindre des blocs concurrents. La question de la légitimité démocratique des assemblées de bassin face aux technocraties mégapolitaines reste ouverte et explosive.

date_creation: 2026-06-15
---

# Fédération des Communs Territoriaux

## Rôle dans [[reference]]
Dans un monde en équilibre fragile, la FCT s'est imposée comme une architecture institutionnelle intermédiaire — ni État souverain, ni simple collectivité locale. Elle fédère quelque 340 bassins de vie à travers cinq continents, chacun gérant ses propres communs énergétiques, alimentaires et juridiques. Elle joue un rôle de contrepoids structurel aux mégapoles globales et aux plateformes techno-économiques dominantes, sans parvenir à s'y opposer frontalement. Sa légitimité repose sur sa capacité à absorber les chocs climatiques locaux là où les États centraux échouent, mais cette légitimité reste disputée et inégalement reconnue.

## Responsabilités
La FCT coordonne les protocoles de souveraineté alimentaire entre bassins membres, négocie des accords d'interopérabilité énergétique avec des opérateurs privés et publics, et maintient un corpus juridique commun — le Droit des Communs Vivants — applicable à l'échelle des territoires affiliés. Elle gère également des fonds de résilience climatique mutualisés, abondés en partie par des mécanismes de compensation carbone contestés.

## Variables influencées
- [[organisation_territoires]]
- [[climat_environnement_global]]
- [[systeme_economique_redistribution]]
- [[energie_ressources_critiques]]

## Relations
**Alliés** : [[cooperatives_agro_ecologiques_du_bassin_mediterraneen_reference]], [[observatoire_climatique_des_territoires_oct_reference]], [[banque_des_communs_reference]], [[syndicats_de_travailleurs_de_la_transition_energetique_reference]]
**Opposants** : [[consortium_des_grandes_plateformes_logistiques_globales_reference]], [[gouvernements_federaux_residuels_souverainistes_reference]], [[operateurs_prives_d_energie_distribuee_hors_fct_reference]], [[confederation_des_megapoles_autonomes_reference]]

## Description journalistique
Depuis son siège tournant — cette saison à Valparaíso, la prochaine à Tampere — la Fédération des Communs Territoriaux continue de défier les catégories politiques héritées du XXe siècle. Ni État, ni ONG, ni syndicat : quelque chose d'obstinément entre les deux. Ses délégués, élus dans des assemblées de bassin souvent houleuses, négocient chaque trimestre des protocoles d'urgence climatique que les gouvernements nationaux n'arrivent plus à imposer seuls. Mais la FCT montre aussi ses failles : des membres dissidents quittent le réseau pour rejoindre des blocs mégapolitains plus puissants, et ses fonds de résilience sont régulièrement insuffisants face à l'intensité des événements extrêmes. Elle tient, mais personne ne sait vraiment jusqu'à quand.

## Tensions narratives
La FCT est tiraillée entre son idéal d'autonomie radicale et la nécessité croissante de s'interfacer avec des systèmes globaux qu'elle ne contrôle pas — réseaux d'IA industrielle, plateformes logistiques, marchés carbone. Certains bassins membres réclament une fédéralisation plus forte au risque de perdre leur souveraineté locale, tandis que d'autres menacent de sécession pour rejoindre des blocs concurrents. La question de la légitimité démocratique des assemblées de bassin face aux technocraties mégapolitaines reste ouverte et explosive.
