---
name: Factions Internes Dissidentes des Contributeurs Historiques
type: instance
slug: factions_internes_dissidentes_des_contributeurs_historiques_policy_reform
entite: factions_internes_dissidentes_des_contributeurs_historiques
scenario: policy_reform
statut: officialise_minimal

type_dans_scenario: organisation

role_dans_scenario: >
  Dans ce scénario de réforme politique, ces factions exercent une résistance interne qui complexifie ou bloque les tentatives de transformation institutionnelle, en invoquant la mémoire et les principes originels du système.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - gouvernance_institutions
  - valeurs_culture_tempo_sociale

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Factions Internes Dissidentes des Contributeurs Historiques

## Rôle dans [[policy_reform]]
Dans ce scénario de réforme politique, ces factions exercent une résistance interne qui complexifie ou bloque les tentatives de transformation institutionnelle, en invoquant la mémoire et les principes originels du système.

## Variables influencées
- [[gouvernance_institutions]]
- [[valeurs_culture_tempo_sociale]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
