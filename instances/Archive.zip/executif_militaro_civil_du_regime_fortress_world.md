---
name: Exécutif Militaro-Civil du Régime
type: instance
slug: executif_militaro_civil_du_regime_fortress_world
entite: executif_militaro_civil_du_regime
scenario: fortress_world
statut: officialise_minimal

type_dans_scenario: institution

role_dans_scenario: >
  Détient le monopole de la décision politique et stratégique dans le scénario fortress_world, arbitrant entre impératifs sécuritaires, contrôle territorial et maintien de l'ordre intérieur.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - gouvernance_institutions
  - geopolitique_conflits
  - organisation_territoires

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Exécutif Militaro-Civil du Régime

## Rôle dans [[fortress_world]]
Détient le monopole de la décision politique et stratégique dans le scénario fortress_world, arbitrant entre impératifs sécuritaires, contrôle territorial et maintien de l'ordre intérieur.

## Variables influencées
- [[gouvernance_institutions]]
- [[geopolitique_conflits]]
- [[organisation_territoires]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
