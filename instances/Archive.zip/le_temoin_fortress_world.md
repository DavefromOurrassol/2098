---
name: Vera Solano
type: instance
slug: le_temoin_fortress_world
entite: le_temoin
scenario: fortress_world
localisation:
  zone: bloc_atlantique
  lieu: Bloc Atlantique (adresses changeantes, mention du Midwest désertifié)
  type_lieu: region
  statut: review_manuelle
  note: "Vera Solano opère au sein du Bloc Atlantique (ANBA, Commandement, Midwest désertifié) mais sans ancrage local précis, depuis des adresses changeantes — la zone bloc_atlantique est le meilleur candidat mais reste large."
type_dans_scenario: humain
role_dans_scenario: >
  Journaliste clandestine de 44 ans, ancienne correspondante certifiée
  de l'Agence Atlantique d'Information qui a perdu son accréditation en
  2089 après avoir publié des données sur les conditions dans les zones
  abandonnées du Bloc. Opère désormais depuis des adresses changeantes
  via les réseaux mesh non certifiés.
responsabilites: >
  Collecte et diffusion d'informations non certifiées sur les zones
  d'exclusion du Bloc. Réseau de sources dans les couches basses de
  l'administration. Archive des incidents que l'ANBA efface.
impact_local: 2
impact_systemique_global: 2
variables_influencees:
  - technologie_information
  - valeurs_culture_tempo_sociale
zone_geographique:
  - continentale
zone_systemique:
  - information
  - société
alliances:
  - coalition_vivant_fortress_world
oppositions:
  - conseil_regulation_algorithmique_fortress_world
type_relation_dominante: conflit
annee_debut: 2079
annee_fin:
etat_temporel: clandestin
age_historique: ascendant
generation: forteresse
injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false
description_journalistique: >
  Vera Solano n'existe pas officiellement. Son identité numérique a été
  suspendue par l'ANBA en 2089. Ses textes circulent sous le pseudonyme
  "V.S." sur les canaux mesh que les techniciens du Bloc n'arrivent pas
  à fermer assez vite. Elle a 44 ans, des cheveux courts, une mémoire
  photographique et un réseau de sources qui s'étend des cuisines du
  Commandement aux zones de silence du Midwest désertifié.
signes_distinctifs: >
  Pseudonyme V.S. suivi d'une date. Style factuel, sans affect, chiffres
  systématiques. Jamais de photos — trop faciles à tracer. Ses textes
  sont toujours courts, denses, vérifiables.
tensions_narratives: >
  L'ANBA a offert une amnistie contre sa liste de sources. Elle a refusé.
  Ses lecteurs ne savent pas si elle est encore en vie — les publications
  se sont espacées depuis trois mois. Un de ses contacts proches a disparu
  en avril.
date_creation: 2098-01-01
---

# Vera Solano

## Rôle dans [[fortress_world]]
Journaliste clandestine opérant via réseaux mesh. Ancienne correspondante
certifiée devenue dissidente de l'information après 2089.

## Variables influencées
- [[technologie_information]]
- [[valeurs_culture_tempo_sociale]]

## Relations
**Alliés** : [[coalition_vivant_fortress_world]]
**Opposants** : [[conseil_regulation_algorithmique_fortress_world]]

## Description journalistique
Vera Solano n'existe pas officiellement. Son identité numérique a été
suspendue par l'ANBA en 2089. Ses textes circulent sous le pseudonyme
"V.S." sur les canaux mesh. Elle a 44 ans et une liste de sources que
l'ANBA veut à tout prix obtenir.

## Tensions narratives
L'ANBA a offert une amnistie contre sa liste de sources. Elle a refusé.
Ses publications se sont espacées depuis trois mois.
