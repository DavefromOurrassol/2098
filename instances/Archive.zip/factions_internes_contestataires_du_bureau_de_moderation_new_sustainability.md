---
name: Factions Internes Contestataires du Bureau de Modération
type: instance
slug: factions_internes_contestataires_du_bureau_de_moderation_new_sustainability
entite: factions_internes_contestataires_du_bureau_de_moderation
scenario: new_sustainability
statut: officialise_minimal

type_dans_scenario: organisation

role_dans_scenario: >
  Dans le scénario new_sustainability, ces factions incarnent les fractures internes qui fragilisent la capacité du Bureau de Modération à produire des décisions cohérentes et contraignantes sur les transitions écologiques.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - gouvernance_institutions
  - valeurs_culture_tempo_sociale
  - climat_environnement_global

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Factions Internes Contestataires du Bureau de Modération

## Rôle dans [[new_sustainability]]
Dans le scénario new_sustainability, ces factions incarnent les fractures internes qui fragilisent la capacité du Bureau de Modération à produire des décisions cohérentes et contraignantes sur les transitions écologiques.

## Variables influencées
- [[gouvernance_institutions]]
- [[valeurs_culture_tempo_sociale]]
- [[climat_environnement_global]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
