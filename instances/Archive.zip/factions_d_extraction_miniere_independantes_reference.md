---
name: Factions d'Extraction Minière Indépendantes
type: instance
slug: factions_d_extraction_miniere_independantes_reference
entite: factions_d_extraction_miniere_independantes
scenario: reference
statut: officialise_minimal

type_dans_scenario: organisation

role_dans_scenario: >
  Dans ce scénario, elles représentent une pression décentralisée sur les ressources critiques, échappant partiellement aux mécanismes de contrôle établis.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - energie_ressources_critiques
  - geopolitique_conflits
  - gouvernance_institutions

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Factions d'Extraction Minière Indépendantes

## Rôle dans [[reference]]
Dans ce scénario, elles représentent une pression décentralisée sur les ressources critiques, échappant partiellement aux mécanismes de contrôle établis.

## Variables influencées
- [[energie_ressources_critiques]]
- [[geopolitique_conflits]]
- [[gouvernance_institutions]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
