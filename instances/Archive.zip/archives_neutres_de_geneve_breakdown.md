---
name: Archives Neutres de Genève
type: instance
slug: archives_neutres_de_geneve_breakdown
entite: archives_neutres_de_geneve
scenario: breakdown
statut: officialise_minimal

type_dans_scenario: infrastructure

role_dans_scenario: >
  Dans le scénario breakdown, constitue l'un des derniers référentiels partagés de légitimité juridique internationale, un point d'ancrage physique pour des normes que les États ou blocs contestent ou ignorent.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - gouvernance_institutions
  - geopolitique_conflits
  - frontieres_du_systeme

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Archives Neutres de Genève

## Rôle dans [[breakdown]]
Dans le scénario breakdown, constitue l'un des derniers référentiels partagés de légitimité juridique internationale, un point d'ancrage physique pour des normes que les États ou blocs contestent ou ignorent.

## Variables influencées
- [[gouvernance_institutions]]
- [[geopolitique_conflits]]
- [[frontieres_du_systeme]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
