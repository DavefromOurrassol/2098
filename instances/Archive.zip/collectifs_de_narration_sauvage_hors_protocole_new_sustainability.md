---
name: Collectifs de Narration Sauvage Hors-Protocole
type: instance
slug: collectifs_de_narration_sauvage_hors_protocole_new_sustainability
entite: collectifs_de_narration_sauvage_hors_protocole
scenario: new_sustainability
statut: officialise_minimal

type_dans_scenario: réseau

role_dans_scenario: >
  Dans le scénario new_sustainability, ils représentent une friction culturelle vis-à-vis des récits dominants de transition, en proposant des versions dissidentes, locales ou non-conformes de ce que signifie 'vivre durablement'.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - valeurs_culture_tempo_sociale
  - technologie_information
  - gouvernance_institutions

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Collectifs de Narration Sauvage Hors-Protocole

## Rôle dans [[new_sustainability]]
Dans le scénario new_sustainability, ils représentent une friction culturelle vis-à-vis des récits dominants de transition, en proposant des versions dissidentes, locales ou non-conformes de ce que signifie 'vivre durablement'.

## Variables influencées
- [[valeurs_culture_tempo_sociale]]
- [[technologie_information]]
- [[gouvernance_institutions]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
