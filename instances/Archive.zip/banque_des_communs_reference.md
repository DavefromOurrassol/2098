---
name: Banque des Communs
type: instance
slug: banque_des_communs_reference
entite: banque_des_communs
scenario: reference
statut: officialise_minimal

type_dans_scenario: institution

role_dans_scenario: >
  Fournit des mécanismes de financement alternatifs aux structures et projets fondés sur les communs dans le scénario de référence.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - systeme_economique_redistribution
  - gouvernance_institutions
  - organisation_territoires

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Banque des Communs

## Rôle dans [[reference]]
Fournit des mécanismes de financement alternatifs aux structures et projets fondés sur les communs dans le scénario de référence.

## Variables influencées
- [[systeme_economique_redistribution]]
- [[gouvernance_institutions]]
- [[organisation_territoires]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
