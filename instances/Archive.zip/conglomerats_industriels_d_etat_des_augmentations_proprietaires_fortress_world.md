---
name: Conglomérats Industriels d'État des Augmentations Propriétaires
type: instance
slug: conglomerats_industriels_d_etat_des_augmentations_proprietaires_fortress_world
entite: conglomerats_industriels_d_etat_des_augmentations_proprietaires
scenario: fortress_world
statut: officialise_minimal

type_dans_scenario: entreprise

role_dans_scenario: >
  Dans fortress_world, ces conglomérats constituent l'épine dorsale économique et de contrôle des États forteresses, liant l'accès aux augmentations à la loyauté citoyenne et aux frontières territoriales.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - sante_biotechnologies
  - gouvernance_institutions
  - systemes_productifs_travail

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Conglomérats Industriels d'État des Augmentations Propriétaires

## Rôle dans [[fortress_world]]
Dans fortress_world, ces conglomérats constituent l'épine dorsale économique et de contrôle des États forteresses, liant l'accès aux augmentations à la loyauté citoyenne et aux frontières territoriales.

## Variables influencées
- [[sante_biotechnologies]]
- [[gouvernance_institutions]]
- [[systemes_productifs_travail]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
