---
name: Réseau des Communs Productifs Régénératifs
type: instance
slug: reseau_des_communs_productifs_regeneratifs_new_sustainability
entite: reseau_des_communs_productifs_regeneratifs
scenario: new_sustainability
statut: officialise_minimal

type_dans_scenario: réseau

role_dans_scenario: >
  Dans le scénario new_sustainability, ce réseau incarne une alternative concrète aux systèmes productifs extractivistes, en expérimentant des modèles économiques fondés sur la régénération des ressources et la gouvernance partagée.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - systemes_productifs_travail
  - organisation_territoires
  - systeme_economique_redistribution

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Réseau des Communs Productifs Régénératifs

## Rôle dans [[new_sustainability]]
Dans le scénario new_sustainability, ce réseau incarne une alternative concrète aux systèmes productifs extractivistes, en expérimentant des modèles économiques fondés sur la régénération des ressources et la gouvernance partagée.

## Variables influencées
- [[systemes_productifs_travail]]
- [[organisation_territoires]]
- [[systeme_economique_redistribution]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
