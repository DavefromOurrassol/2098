---
name: Fédération des Mutuelles Biotech
type: instance
slug: federation_des_mutuelles_biotech_policy_reform
entite: federation_des_mutuelles_biotech
scenario: policy_reform
statut: officialise_minimal

type_dans_scenario: organisation

role_dans_scenario: >
  Acteur de la réforme des politiques de santé et de couverture biotech, pesant sur les négociations réglementaires autour de l'accès aux thérapies et dispositifs biotechnologiques.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - sante_biotechnologies
  - systeme_economique_redistribution
  - gouvernance_institutions

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Fédération des Mutuelles Biotech

## Rôle dans [[policy_reform]]
Acteur de la réforme des politiques de santé et de couverture biotech, pesant sur les négociations réglementaires autour de l'accès aux thérapies et dispositifs biotechnologiques.

## Variables influencées
- [[sante_biotechnologies]]
- [[systeme_economique_redistribution]]
- [[gouvernance_institutions]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
