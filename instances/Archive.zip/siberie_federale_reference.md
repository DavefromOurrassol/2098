---
name: Sibérie Fédérale
type: instance
slug: siberie_federale_reference
entite: siberie_federale
scenario: reference
statut: officialise_minimal

type_dans_scenario: institution

role_dans_scenario: >
  Conteste les zones d'exclusion maritime définies dans le scénario de référence, s'opposant aux délimitations territoriales imposées par d'autres puissances ou institutions internationales sur les espaces sibériens et arctiques.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - geopolitique_conflits
  - organisation_territoires
  - energie_ressources_critiques

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Sibérie Fédérale

## Rôle dans [[reference]]
Conteste les zones d'exclusion maritime définies dans le scénario de référence, s'opposant aux délimitations territoriales imposées par d'autres puissances ou institutions internationales sur les espaces sibériens et arctiques.

## Variables influencées
- [[geopolitique_conflits]]
- [[organisation_territoires]]
- [[energie_ressources_critiques]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
