---
name: Milices Séparatistes du Conseil des Pêcheries d'Islande
type: instance
slug: milices_separatistes_du_conseil_des_pecheries_d_islande_breakdown
entite: milices_separatistes_du_conseil_des_pecheries_d_islande
scenario: breakdown
statut: officialise_minimal

type_dans_scenario: organisation

role_dans_scenario: >
  Dans le scénario breakdown, elles exercent un contrôle de facto sur des portions de l'Atlantique Nord, contestant la légitimité de toute gouvernance extérieure sur les droits de pêche et les eaux territoriales.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - geopolitique_conflits
  - energie_ressources_critiques
  - organisation_territoires

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Milices Séparatistes du Conseil des Pêcheries d'Islande

## Rôle dans [[breakdown]]
Dans le scénario breakdown, elles exercent un contrôle de facto sur des portions de l'Atlantique Nord, contestant la légitimité de toute gouvernance extérieure sur les droits de pêche et les eaux territoriales.

## Variables influencées
- [[geopolitique_conflits]]
- [[energie_ressources_critiques]]
- [[organisation_territoires]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
