---
name: Conseil des États Nordiques Intégrés
type: instance
slug: conseil_des_etats_nordiques_integres_reference
entite: conseil_des_etats_nordiques_integres
scenario: reference
statut: officialise_minimal

type_dans_scenario: institution

role_dans_scenario: >
  Acteur géopolitique régional structurant dans le scénario reference, incarnant une forme de fédéralisme nordique face aux dynamiques mondiales.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - gouvernance_institutions
  - geopolitique_conflits
  - organisation_territoires

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Conseil des États Nordiques Intégrés

## Rôle dans [[reference]]
Acteur géopolitique régional structurant dans le scénario reference, incarnant une forme de fédéralisme nordique face aux dynamiques mondiales.

## Variables influencées
- [[gouvernance_institutions]]
- [[geopolitique_conflits]]
- [[organisation_territoires]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
