---
name: Opérateurs Privés d'Énergie Distribuée Hors-FCT
type: instance
slug: operateurs_prives_d_energie_distribuee_hors_fct_reference
entite: operateurs_prives_d_energie_distribuee_hors_fct
scenario: reference
statut: officialise_minimal

type_dans_scenario: organisation

role_dans_scenario: >
  Dans ce scénario, ils incarnent une résistance opérationnelle aux protocoles FCT, créant des zones d'énergie parallèles échappant partiellement au contrôle institutionnel.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - energie_ressources_critiques
  - gouvernance_institutions
  - organisation_territoires

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Opérateurs Privés d'Énergie Distribuée Hors-FCT

## Rôle dans [[reference]]
Dans ce scénario, ils incarnent une résistance opérationnelle aux protocoles FCT, créant des zones d'énergie parallèles échappant partiellement au contrôle institutionnel.

## Variables influencées
- [[energie_ressources_critiques]]
- [[gouvernance_institutions]]
- [[organisation_territoires]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
