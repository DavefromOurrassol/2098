---
name: Dissidences Internes aux Blocs Minoritaires
type: instance
slug: dissidences_internes_aux_blocs_minoritaires_fortress_world
entite: dissidences_internes_aux_blocs_minoritaires
scenario: fortress_world
statut: officialise_minimal

type_dans_scenario: réseau

role_dans_scenario: >
  Dans le scénario fortress_world, ces dissidences fragilisent la cohésion des blocs minoritaires face aux blocs dominants, tout en portant des revendications d'autonomie radicale que les directions officielles refusent d'assumer.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - gouvernance_institutions
  - demographie_mobilite_humaine
  - valeurs_culture_tempo_sociale

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Dissidences Internes aux Blocs Minoritaires

## Rôle dans [[fortress_world]]
Dans le scénario fortress_world, ces dissidences fragilisent la cohésion des blocs minoritaires face aux blocs dominants, tout en portant des revendications d'autonomie radicale que les directions officielles refusent d'assumer.

## Variables influencées
- [[gouvernance_institutions]]
- [[demographie_mobilite_humaine]]
- [[valeurs_culture_tempo_sociale]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
