---
name: Alliance Sanitaire des Populations Exclues
type: instance
slug: alliance_sanitaire_des_populations_exclues_fortress_world
entite: alliance_sanitaire_des_populations_exclues
scenario: fortress_world
statut: officialise_minimal

type_dans_scenario: organisation

role_dans_scenario: >
  Dans fortress_world, constitue un réseau de résistance humanitaire aux logiques d'exclusion sanitaire imposées par les blocs fermés, en organisant une médecine parallèle pour les laissés-pour-compte des frontières.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - sante_biotechnologies
  - demographie_mobilite_humaine
  - organisation_territoires

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Alliance Sanitaire des Populations Exclues

## Rôle dans [[fortress_world]]
Dans fortress_world, constitue un réseau de résistance humanitaire aux logiques d'exclusion sanitaire imposées par les blocs fermés, en organisant une médecine parallèle pour les laissés-pour-compte des frontières.

## Variables influencées
- [[sante_biotechnologies]]
- [[demographie_mobilite_humaine]]
- [[organisation_territoires]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
