---
name: Consortium de Géo-ingénierie Atmosphérique Pacifique
type: instance
slug: consortium_de_geo_ingenierie_atmospherique_pacifique_policy_reform
entite: consortium_de_geo_ingenierie_atmospherique_pacifique
scenario: policy_reform
statut: officialise_minimal

type_dans_scenario: organisation

role_dans_scenario: >
  Acteur clé ou objet de controverse dans le cadre d'une réforme des politiques climatiques, dont les activités soulèvent des questions de gouvernance transnationale et de légitimité décisionnelle.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - climat_environnement_global
  - gouvernance_institutions
  - geopolitique_conflits

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Consortium de Géo-ingénierie Atmosphérique Pacifique

## Rôle dans [[policy_reform]]
Acteur clé ou objet de controverse dans le cadre d'une réforme des politiques climatiques, dont les activités soulèvent des questions de gouvernance transnationale et de légitimité décisionnelle.

## Variables influencées
- [[climat_environnement_global]]
- [[gouvernance_institutions]]
- [[geopolitique_conflits]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
