---
name: ONG de Traçabilité des Ressources Critiques
type: instance
slug: ong_de_tracabilite_des_ressources_critiques_reference
entite: ong_de_tracabilite_des_ressources_critiques
scenario: reference
statut: officialise_minimal

type_dans_scenario: organisation

role_dans_scenario: >
  Dénonce publiquement les pratiques d'une entité du scénario liées à l'extraction ou à la gestion de ressources critiques, en s'appuyant sur des données de traçabilité.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - energie_ressources_critiques
  - gouvernance_institutions
  - climat_environnement_global

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# ONG de Traçabilité des Ressources Critiques

## Rôle dans [[reference]]
Dénonce publiquement les pratiques d'une entité du scénario liées à l'extraction ou à la gestion de ressources critiques, en s'appuyant sur des données de traçabilité.

## Variables influencées
- [[energie_ressources_critiques]]
- [[gouvernance_institutions]]
- [[climat_environnement_global]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
