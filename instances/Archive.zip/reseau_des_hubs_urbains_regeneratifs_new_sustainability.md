---
name: Réseau des Hubs Urbains Régénératifs
type: instance
slug: reseau_des_hubs_urbains_regeneratifs_new_sustainability
entite: reseau_des_hubs_urbains_regeneratifs
scenario: new_sustainability
statut: officialise_minimal

type_dans_scenario: réseau

role_dans_scenario: >
  Dans le scénario new_sustainability, ce réseau incarne une alternative concrète aux modèles extractivistes, servant de vitrine opérationnelle pour les transitions systémiques locales et de contre-pouvoir aux logiques de croissance conventionnelles.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - organisation_territoires
  - climat_environnement_global
  - systemes_productifs_travail

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Réseau des Hubs Urbains Régénératifs

## Rôle dans [[new_sustainability]]
Dans le scénario new_sustainability, ce réseau incarne une alternative concrète aux modèles extractivistes, servant de vitrine opérationnelle pour les transitions systémiques locales et de contre-pouvoir aux logiques de croissance conventionnelles.

## Variables influencées
- [[organisation_territoires]]
- [[climat_environnement_global]]
- [[systemes_productifs_travail]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
