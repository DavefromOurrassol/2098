---
name: Réseaux de gouvernance territoriale distribués
type: instance
slug: reseaux_de_gouvernance_territoriale_distribues_new_sustainability
entite: reseaux_de_gouvernance_territoriale_distribues
scenario: new_sustainability
statut: officialise_minimal

type_dans_scenario: réseau

role_dans_scenario: >
  Dans le scénario new_sustainability, constituent l'ossature institutionnelle permettant de coordonner les transitions écologiques et économiques à l'échelle des territoires, en contournant ou complétant les États défaillants.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - organisation_territoires
  - gouvernance_institutions
  - systeme_economique_redistribution

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Réseaux de gouvernance territoriale distribués

## Rôle dans [[new_sustainability]]
Dans le scénario new_sustainability, constituent l'ossature institutionnelle permettant de coordonner les transitions écologiques et économiques à l'échelle des territoires, en contournant ou complétant les États défaillants.

## Variables influencées
- [[organisation_territoires]]
- [[gouvernance_institutions]]
- [[systeme_economique_redistribution]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
