---
name: Mouvement pour la Souveraineté Énergétique Commune (MSEC)
type: instance
slug: mouvement_pour_la_souverainete_energetique_commune_msec_policy_reform
entite: mouvement_pour_la_souverainete_energetique_commune_msec
scenario: policy_reform
statut: officialise_minimal

type_dans_scenario: organisation

role_dans_scenario: >
  Acteur de pression dans le scénario de réforme politique, cherchant à influencer les régulations énergétiques vers un modèle de souveraineté populaire et de redistribution collective.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - energie_ressources_critiques
  - gouvernance_institutions
  - systeme_economique_redistribution

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Mouvement pour la Souveraineté Énergétique Commune (MSEC)

## Rôle dans [[policy_reform]]
Acteur de pression dans le scénario de réforme politique, cherchant à influencer les régulations énergétiques vers un modèle de souveraineté populaire et de redistribution collective.

## Variables influencées
- [[energie_ressources_critiques]]
- [[gouvernance_institutions]]
- [[systeme_economique_redistribution]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
