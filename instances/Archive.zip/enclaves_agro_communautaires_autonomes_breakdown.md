---
name: Enclaves Agro-Communautaires Autonomes
type: instance
slug: enclaves_agro_communautaires_autonomes_breakdown
entite: enclaves_agro_communautaires_autonomes
scenario: breakdown
statut: officialise_minimal

type_dans_scenario: organisation

role_dans_scenario: >
  Dans le scénario breakdown, elles incarnent les poches de résilience localiste qui émergent en réponse à la désintégration des institutions et des chaînes d'approvisionnement globales.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - organisation_territoires
  - systemes_productifs_travail
  - gouvernance_institutions

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Enclaves Agro-Communautaires Autonomes

## Rôle dans [[breakdown]]
Dans le scénario breakdown, elles incarnent les poches de résilience localiste qui émergent en réponse à la désintégration des institutions et des chaînes d'approvisionnement globales.

## Variables influencées
- [[organisation_territoires]]
- [[systemes_productifs_travail]]
- [[gouvernance_institutions]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
