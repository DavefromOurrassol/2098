---
name: Courants Post-Technocratiques de Reconquête Démocratique
type: instance
slug: courants_post_technocratiques_de_reconquete_democratique_policy_reform
entite: courants_post_technocratiques_de_reconquete_democratique
scenario: policy_reform
statut: officialise_minimal

type_dans_scenario: organisation

role_dans_scenario: >
  Dans le scénario policy_reform, ils exercent une pression critique sur les réformes institutionnelles en contestant la légitimité des architectures décisionnelles dominées par des systèmes algorithmiques ou des corps d'experts non élus.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - gouvernance_institutions
  - valeurs_culture_tempo_sociale
  - technologie_information

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Courants Post-Technocratiques de Reconquête Démocratique

## Rôle dans [[policy_reform]]
Dans le scénario policy_reform, ils exercent une pression critique sur les réformes institutionnelles en contestant la légitimité des architectures décisionnelles dominées par des systèmes algorithmiques ou des corps d'experts non élus.

## Variables influencées
- [[gouvernance_institutions]]
- [[valeurs_culture_tempo_sociale]]
- [[technologie_information]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
