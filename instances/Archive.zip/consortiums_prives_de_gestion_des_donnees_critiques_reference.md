---
name: Consortiums Privés de Gestion des Données Critiques
type: instance
slug: consortiums_prives_de_gestion_des_donnees_critiques_reference
entite: consortiums_prives_de_gestion_des_donnees_critiques
scenario: reference
statut: officialise_minimal

type_dans_scenario: entreprise

role_dans_scenario: >
  Dans le scénario reference, ils incarnent la privatisation avancée de fonctions autrefois régaliennes, pesant sur l'équilibre entre gouvernance publique et pouvoir économique informationnel.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - technologie_information
  - gouvernance_institutions
  - energie_ressources_critiques

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Consortiums Privés de Gestion des Données Critiques

## Rôle dans [[reference]]
Dans le scénario reference, ils incarnent la privatisation avancée de fonctions autrefois régaliennes, pesant sur l'équilibre entre gouvernance publique et pouvoir économique informationnel.

## Variables influencées
- [[technologie_information]]
- [[gouvernance_institutions]]
- [[energie_ressources_critiques]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
