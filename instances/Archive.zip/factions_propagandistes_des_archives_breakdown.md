---
name: Factions Propagandistes des Archives
type: instance
slug: factions_propagandistes_des_archives_breakdown
entite: factions_propagandistes_des_archives
scenario: breakdown
statut: officialise_minimal

type_dans_scenario: organisation

role_dans_scenario: >
  Dans le scénario breakdown, elles exploitent l'effondrement des structures de gouvernance pour infiltrer et corrompre les dépôts d'archives, fragilisant la capacité collective à maintenir une mémoire historique partagée.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - technologie_information
  - gouvernance_institutions
  - valeurs_culture_tempo_sociale

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Factions Propagandistes des Archives

## Rôle dans [[breakdown]]
Dans le scénario breakdown, elles exploitent l'effondrement des structures de gouvernance pour infiltrer et corrompre les dépôts d'archives, fragilisant la capacité collective à maintenir une mémoire historique partagée.

## Variables influencées
- [[technologie_information]]
- [[gouvernance_institutions]]
- [[valeurs_culture_tempo_sociale]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
