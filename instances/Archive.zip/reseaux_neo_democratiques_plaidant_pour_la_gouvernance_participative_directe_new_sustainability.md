---
name: Réseaux néo-démocratiques plaidant pour la gouvernance participative directe
type: instance
slug: reseaux_neo_democratiques_plaidant_pour_la_gouvernance_participative_directe_new_sustainability
entite: reseaux_neo_democratiques_plaidant_pour_la_gouvernance_participative_directe
scenario: new_sustainability
statut: officialise_minimal

type_dans_scenario: réseau

role_dans_scenario: >
  Dans le scénario new_sustainability, constituent une pression citoyenne pour que les décisions environnementales et de transition écologique soient prises collectivement plutôt que déléguées à des experts ou élites économiques.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - gouvernance_institutions
  - valeurs_culture_tempo_sociale
  - organisation_territoires

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Réseaux néo-démocratiques plaidant pour la gouvernance participative directe

## Rôle dans [[new_sustainability]]
Dans le scénario new_sustainability, constituent une pression citoyenne pour que les décisions environnementales et de transition écologique soient prises collectivement plutôt que déléguées à des experts ou élites économiques.

## Variables influencées
- [[gouvernance_institutions]]
- [[valeurs_culture_tempo_sociale]]
- [[organisation_territoires]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
