---
name: Confédération des Mégapoles Autonomes
type: instance
slug: confederation_des_megapoles_autonomes_reference
entite: confederation_des_megapoles_autonomes
scenario: reference
statut: officialise_minimal

type_dans_scenario: organisation

role_dans_scenario: >
  Incarne la fragmentation géopolitique en blocs mégapolitains concurrents, substituant la rivalité inter-urbaine à la rivalité interétatique classique.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - organisation_territoires
  - gouvernance_institutions
  - geopolitique_conflits

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Confédération des Mégapoles Autonomes

## Rôle dans [[reference]]
Incarne la fragmentation géopolitique en blocs mégapolitains concurrents, substituant la rivalité inter-urbaine à la rivalité interétatique classique.

## Variables influencées
- [[organisation_territoires]]
- [[gouvernance_institutions]]
- [[geopolitique_conflits]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
