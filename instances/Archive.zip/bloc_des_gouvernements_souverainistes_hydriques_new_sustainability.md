---
name: Bloc des Gouvernements Souverainistes Hydriques
type: instance
slug: bloc_des_gouvernements_souverainistes_hydriques_new_sustainability
entite: bloc_des_gouvernements_souverainistes_hydriques
scenario: new_sustainability
statut: officialise_minimal

type_dans_scenario: organisation

role_dans_scenario: >
  Opposant structurel aux accords de gouvernance hydrique partagée dans le scénario new_sustainability, bloquant ou fragilisant les mécanismes de coopération transnationale sur l'eau.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - geopolitique_conflits
  - gouvernance_institutions
  - energie_ressources_critiques

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Bloc des Gouvernements Souverainistes Hydriques

## Rôle dans [[new_sustainability]]
Opposant structurel aux accords de gouvernance hydrique partagée dans le scénario new_sustainability, bloquant ou fragilisant les mécanismes de coopération transnationale sur l'eau.

## Variables influencées
- [[geopolitique_conflits]]
- [[gouvernance_institutions]]
- [[energie_ressources_critiques]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
