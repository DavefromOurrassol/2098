---
name: Collectifs de Facilitateurs Délibératifs Itinérants
type: instance
slug: collectifs_de_facilitateurs_deliberatifs_itinerants_eco_communalism
entite: collectifs_de_facilitateurs_deliberatifs_itinerants
scenario: eco_communalism
statut: officialise_minimal

type_dans_scenario: réseau

role_dans_scenario: >
  Dans le scénario eco_communalism, ils soutiennent la cohésion et la prise de décision collective des communautés autonomes, assurant une circulation des méthodes démocratiques entre les territoires dispersés.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - gouvernance_institutions
  - organisation_territoires
  - valeurs_culture_tempo_sociale

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Collectifs de Facilitateurs Délibératifs Itinérants

## Rôle dans [[eco_communalism]]
Dans le scénario eco_communalism, ils soutiennent la cohésion et la prise de décision collective des communautés autonomes, assurant une circulation des méthodes démocratiques entre les territoires dispersés.

## Variables influencées
- [[gouvernance_institutions]]
- [[organisation_territoires]]
- [[valeurs_culture_tempo_sociale]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
