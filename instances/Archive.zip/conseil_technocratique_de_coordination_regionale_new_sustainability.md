---
name: Conseil Technocratique de Coordination Régionale
type: instance
slug: conseil_technocratique_de_coordination_regionale_new_sustainability
entite: conseil_technocratique_de_coordination_regionale
scenario: new_sustainability
statut: officialise_minimal

type_dans_scenario: institution

role_dans_scenario: >
  Dans le scénario new_sustainability, le Conseil orchestre la mise en œuvre des transitions écologiques à l'échelle régionale, arbitrant les conflits de ressources et imposant des standards aux entités locales.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - gouvernance_institutions
  - organisation_territoires
  - energie_ressources_critiques

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Conseil Technocratique de Coordination Régionale

## Rôle dans [[new_sustainability]]
Dans le scénario new_sustainability, le Conseil orchestre la mise en œuvre des transitions écologiques à l'échelle régionale, arbitrant les conflits de ressources et imposant des standards aux entités locales.

## Variables influencées
- [[gouvernance_institutions]]
- [[organisation_territoires]]
- [[energie_ressources_critiques]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
