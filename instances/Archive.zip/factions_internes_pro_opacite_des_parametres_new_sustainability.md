---
name: Factions Internes Pro-Opacité des Paramètres
type: instance
slug: factions_internes_pro_opacite_des_parametres_new_sustainability
entite: factions_internes_pro_opacite_des_parametres
scenario: new_sustainability
statut: officialise_minimal

type_dans_scenario: autre

role_dans_scenario: >
  Dans le scénario new_sustainability, ces factions s'opposent à la mise en visibilité des critères et pondérations qui orientent les politiques de durabilité, cherchant à préserver des marges de manœuvre discrétionnaires au sein des institutions.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - gouvernance_institutions
  - technologie_information
  - frontieres_du_systeme

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Factions Internes Pro-Opacité des Paramètres

## Rôle dans [[new_sustainability]]
Dans le scénario new_sustainability, ces factions s'opposent à la mise en visibilité des critères et pondérations qui orientent les politiques de durabilité, cherchant à préserver des marges de manœuvre discrétionnaires au sein des institutions.

## Variables influencées
- [[gouvernance_institutions]]
- [[technologie_information]]
- [[frontieres_du_systeme]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
