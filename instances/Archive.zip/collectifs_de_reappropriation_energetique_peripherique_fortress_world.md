---
name: Collectifs de Réappropriation Énergétique Périphérique
type: instance
slug: collectifs_de_reappropriation_energetique_peripherique_fortress_world
entite: collectifs_de_reappropriation_energetique_peripherique
scenario: fortress_world
statut: officialise_minimal

type_dans_scenario: organisation

role_dans_scenario: >
  Acteurs de résistance infraterritoriale qui contestent le monopole énergétique des zones protégées en développant des alternatives décentralisées dans les marges, fragilisant ou contournant la logique d'enclavement du scénario fortress_world.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - energie_ressources_critiques
  - organisation_territoires
  - gouvernance_institutions

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Collectifs de Réappropriation Énergétique Périphérique

## Rôle dans [[fortress_world]]
Acteurs de résistance infraterritoriale qui contestent le monopole énergétique des zones protégées en développant des alternatives décentralisées dans les marges, fragilisant ou contournant la logique d'enclavement du scénario fortress_world.

## Variables influencées
- [[energie_ressources_critiques]]
- [[organisation_territoires]]
- [[gouvernance_institutions]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
