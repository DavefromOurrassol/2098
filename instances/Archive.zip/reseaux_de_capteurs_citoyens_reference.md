---
name: Réseaux de Capteurs Citoyens
type: instance
slug: reseaux_de_capteurs_citoyens_reference
entite: reseaux_de_capteurs_citoyens
scenario: reference
statut: officialise_minimal

type_dans_scenario: réseau

role_dans_scenario: >
  Fournit des données terrain décentralisées dans le scénario de référence, potentiellement en tension ou en complémentarité avec les systèmes institutionnels de monitoring.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - technologie_information
  - climat_environnement_global
  - gouvernance_institutions

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Réseaux de Capteurs Citoyens

## Rôle dans [[reference]]
Fournit des données terrain décentralisées dans le scénario de référence, potentiellement en tension ou en complémentarité avec les systèmes institutionnels de monitoring.

## Variables influencées
- [[technologie_information]]
- [[climat_environnement_global]]
- [[gouvernance_institutions]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
