---
name: Programme ONU de Restauration des Sols
type: instance
slug: programme_onu_de_restauration_des_sols_new_sustainability
entite: programme_onu_de_restauration_des_sols
scenario: new_sustainability
statut: officialise_minimal

type_dans_scenario: institution

role_dans_scenario: >
  Dans le scénario new_sustainability, ce programme structure les politiques globales de transition vers des pratiques agricoles régénératives et arbitre les tensions entre États sur l'accès aux terres viables.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - climat_environnement_global
  - gouvernance_institutions
  - organisation_territoires

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Programme ONU de Restauration des Sols

## Rôle dans [[new_sustainability]]
Dans le scénario new_sustainability, ce programme structure les politiques globales de transition vers des pratiques agricoles régénératives et arbitre les tensions entre États sur l'accès aux terres viables.

## Variables influencées
- [[climat_environnement_global]]
- [[gouvernance_institutions]]
- [[organisation_territoires]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
