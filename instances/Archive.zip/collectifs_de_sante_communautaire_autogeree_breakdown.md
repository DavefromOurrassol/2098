---
name: Collectifs de Santé Communautaire Autogérée
type: instance
slug: collectifs_de_sante_communautaire_autogeree_breakdown
entite: collectifs_de_sante_communautaire_autogeree
scenario: breakdown
statut: officialise_minimal

type_dans_scenario: réseau

role_dans_scenario: >
  Dans un contexte de breakdown, ces collectifs pallient l'effondrement des systèmes de santé publics en organisant des soins de base à l'échelle communautaire.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - sante_biotechnologies
  - organisation_territoires
  - gouvernance_institutions

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Collectifs de Santé Communautaire Autogérée

## Rôle dans [[breakdown]]
Dans un contexte de breakdown, ces collectifs pallient l'effondrement des systèmes de santé publics en organisant des soins de base à l'échelle communautaire.

## Variables influencées
- [[sante_biotechnologies]]
- [[organisation_territoires]]
- [[gouvernance_institutions]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
