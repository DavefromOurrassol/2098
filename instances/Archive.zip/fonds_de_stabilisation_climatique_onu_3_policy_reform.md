---
name: Fonds de Stabilisation Climatique ONU-3
type: instance
slug: fonds_de_stabilisation_climatique_onu_3_policy_reform
entite: fonds_de_stabilisation_climatique_onu_3
scenario: policy_reform
statut: officialise_minimal

type_dans_scenario: institution

role_dans_scenario: >
  Dans le scénario policy_reform, constitue un levier de conditionnalité et de redistribution autour duquel se cristallisent les tensions entre États donateurs, bénéficiaires et réformateurs des architectures de gouvernance globale.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - gouvernance_institutions
  - climat_environnement_global
  - systeme_economique_redistribution

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Fonds de Stabilisation Climatique ONU-3

## Rôle dans [[policy_reform]]
Dans le scénario policy_reform, constitue un levier de conditionnalité et de redistribution autour duquel se cristallisent les tensions entre États donateurs, bénéficiaires et réformateurs des architectures de gouvernance globale.

## Variables influencées
- [[gouvernance_institutions]]
- [[climat_environnement_global]]
- [[systeme_economique_redistribution]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
