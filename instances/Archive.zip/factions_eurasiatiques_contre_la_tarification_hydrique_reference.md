---
name: Factions Eurasiatiques contre la Tarification Hydrique
type: instance
slug: factions_eurasiatiques_contre_la_tarification_hydrique_reference
entite: factions_eurasiatiques_contre_la_tarification_hydrique
scenario: reference
statut: officialise_minimal

type_dans_scenario: organisation

role_dans_scenario: >
  Opposant structurel aux régimes de tarification hydrique globalisés, exerçant une pression géopolitique pour maintenir des modèles d'accès à l'eau hors des marchés internationaux.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - geopolitique_conflits
  - energie_ressources_critiques
  - gouvernance_institutions

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Factions Eurasiatiques contre la Tarification Hydrique

## Rôle dans [[reference]]
Opposant structurel aux régimes de tarification hydrique globalisés, exerçant une pression géopolitique pour maintenir des modèles d'accès à l'eau hors des marchés internationaux.

## Variables influencées
- [[geopolitique_conflits]]
- [[energie_ressources_critiques]]
- [[gouvernance_institutions]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
