---
name: Collectifs de Désobéissance Algorithmique
type: instance
slug: collectifs_de_desobeissance_algorithmique_new_sustainability
entite: collectifs_de_desobeissance_algorithmique
scenario: new_sustainability
statut: officialise_minimal

type_dans_scenario: réseau

role_dans_scenario: >
  Dans new_sustainability, ils représentent une friction organisée contre les logiques d'optimisation automatisée imposées au nom de la durabilité, questionnant qui contrôle les algorithmes de transition.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - technologie_information
  - valeurs_culture_tempo_sociale
  - gouvernance_institutions

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Collectifs de Désobéissance Algorithmique

## Rôle dans [[new_sustainability]]
Dans new_sustainability, ils représentent une friction organisée contre les logiques d'optimisation automatisée imposées au nom de la durabilité, questionnant qui contrôle les algorithmes de transition.

## Variables influencées
- [[technologie_information]]
- [[valeurs_culture_tempo_sociale]]
- [[gouvernance_institutions]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
