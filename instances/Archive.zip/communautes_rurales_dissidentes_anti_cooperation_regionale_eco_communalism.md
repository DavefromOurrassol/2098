---
name: Communautés Rurales Dissidentes Anti-Coopération Régionale
type: instance
slug: communautes_rurales_dissidentes_anti_cooperation_regionale_eco_communalism
entite: communautes_rurales_dissidentes_anti_cooperation_regionale
scenario: eco_communalism
statut: officialise_minimal

type_dans_scenario: réseau

role_dans_scenario: >
  Constituent un point de friction interne au modèle éco-communaliste en refusant les protocoles de mutualisation régionale, testant ainsi les limites de la gouvernance horizontale.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - organisation_territoires
  - gouvernance_institutions
  - frontieres_du_systeme

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Communautés Rurales Dissidentes Anti-Coopération Régionale

## Rôle dans [[eco_communalism]]
Constituent un point de friction interne au modèle éco-communaliste en refusant les protocoles de mutualisation régionale, testant ainsi les limites de la gouvernance horizontale.

## Variables influencées
- [[organisation_territoires]]
- [[gouvernance_institutions]]
- [[frontieres_du_systeme]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
