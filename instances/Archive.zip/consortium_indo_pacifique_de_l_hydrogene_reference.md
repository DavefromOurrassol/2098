---
name: Consortium Indo-Pacifique de l'Hydrogène
type: instance
slug: consortium_indo_pacifique_de_l_hydrogene_reference
entite: consortium_indo_pacifique_de_l_hydrogene
scenario: reference
statut: officialise_minimal

type_dans_scenario: entreprise

role_dans_scenario: >
  Dans le scénario reference, le Consortium structure les flux d'hydrogène à l'échelle Indo-Pacifique et constitue un nœud de pouvoir énergétique et géopolitique dont les décisions influencent les équilibres régionaux.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - energie_ressources_critiques
  - geopolitique_conflits
  - systeme_economique_redistribution

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Consortium Indo-Pacifique de l'Hydrogène

## Rôle dans [[reference]]
Dans le scénario reference, le Consortium structure les flux d'hydrogène à l'échelle Indo-Pacifique et constitue un nœud de pouvoir énergétique et géopolitique dont les décisions influencent les équilibres régionaux.

## Variables influencées
- [[energie_ressources_critiques]]
- [[geopolitique_conflits]]
- [[systeme_economique_redistribution]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
