---
name: Hanse Baltique Recomposée
type: instance
slug: hanse_baltique_recomposee_breakdown
entite: hanse_baltique_recomposee
scenario: breakdown
statut: officialise_minimal

type_dans_scenario: organisation

role_dans_scenario: >
  Dans le scénario breakdown, constitue un bloc de résistance régionale structuré, capable de maintenir des flux économiques et une cohérence institutionnelle là où les cadres globaux se sont effondrés.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - gouvernance_institutions
  - geopolitique_conflits
  - organisation_territoires

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Hanse Baltique Recomposée

## Rôle dans [[breakdown]]
Dans le scénario breakdown, constitue un bloc de résistance régionale structuré, capable de maintenir des flux économiques et une cohérence institutionnelle là où les cadres globaux se sont effondrés.

## Variables influencées
- [[gouvernance_institutions]]
- [[geopolitique_conflits]]
- [[organisation_territoires]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
