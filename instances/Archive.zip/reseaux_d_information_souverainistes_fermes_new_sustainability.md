---
name: Réseaux d'information souverainistes fermés
type: instance
slug: reseaux_d_information_souverainistes_fermes_new_sustainability
entite: reseaux_d_information_souverainistes_fermes
scenario: new_sustainability
statut: officialise_minimal

type_dans_scenario: réseau

role_dans_scenario: >
  Dans le scénario new_sustainability, ces réseaux fragmentent la circulation des savoirs liés aux enjeux écologiques et technologiques, créant des bulles informationnelles concurrentes aux consensus globaux.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - technologie_information
  - gouvernance_institutions
  - frontieres_du_systeme

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Réseaux d'information souverainistes fermés

## Rôle dans [[new_sustainability]]
Dans le scénario new_sustainability, ces réseaux fragmentent la circulation des savoirs liés aux enjeux écologiques et technologiques, créant des bulles informationnelles concurrentes aux consensus globaux.

## Variables influencées
- [[technologie_information]]
- [[gouvernance_institutions]]
- [[frontieres_du_systeme]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
