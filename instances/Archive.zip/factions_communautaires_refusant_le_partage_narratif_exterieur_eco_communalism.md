---
name: Factions Communautaires Refusant le Partage Narratif Extérieur
type: instance
slug: factions_communautaires_refusant_le_partage_narratif_exterieur_eco_communalism
entite: factions_communautaires_refusant_le_partage_narratif_exterieur
scenario: eco_communalism
statut: officialise_minimal

type_dans_scenario: autre

role_dans_scenario: >
  Dans le scénario eco_communalism, elles incarnent la frange radicale du repli communautaire, résistant aux tentatives de mise en réseau ou de fédération des communes écologistes.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - frontieres_du_systeme
  - valeurs_culture_tempo_sociale
  - organisation_territoires

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Factions Communautaires Refusant le Partage Narratif Extérieur

## Rôle dans [[eco_communalism]]
Dans le scénario eco_communalism, elles incarnent la frange radicale du repli communautaire, résistant aux tentatives de mise en réseau ou de fédération des communes écologistes.

## Variables influencées
- [[frontieres_du_systeme]]
- [[valeurs_culture_tempo_sociale]]
- [[organisation_territoires]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
