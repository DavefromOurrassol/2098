---
name: Factions Djihadistes Logistiques d'Asie Centrale
type: instance
slug: factions_djihadistes_logistiques_d_asie_centrale_fortress_world
entite: factions_djihadistes_logistiques_d_asie_centrale
scenario: fortress_world
statut: officialise_minimal

type_dans_scenario: organisation

role_dans_scenario: >
  Acteurs déstabilisateurs des flux logistiques intercontinentaux dans le scénario fortress_world, ils fragmentent et taxent les corridors terrestres alternatifs aux routes maritimes contrôlées par les grandes puissances.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - geopolitique_conflits
  - organisation_territoires
  - energie_ressources_critiques

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Factions Djihadistes Logistiques d'Asie Centrale

## Rôle dans [[fortress_world]]
Acteurs déstabilisateurs des flux logistiques intercontinentaux dans le scénario fortress_world, ils fragmentent et taxent les corridors terrestres alternatifs aux routes maritimes contrôlées par les grandes puissances.

## Variables influencées
- [[geopolitique_conflits]]
- [[organisation_territoires]]
- [[energie_ressources_critiques]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
