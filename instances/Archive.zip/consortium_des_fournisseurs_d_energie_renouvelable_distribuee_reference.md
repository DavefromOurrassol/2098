---
name: Consortium des Fournisseurs d'Énergie Renouvelable Distribuée
type: instance
slug: consortium_des_fournisseurs_d_energie_renouvelable_distribuee_reference
entite: consortium_des_fournisseurs_d_energie_renouvelable_distribuee
scenario: reference
statut: officialise_minimal

type_dans_scenario: réseau

role_dans_scenario: >
  Dans le scénario de référence, assure le couplage opérationnel entre réseaux énergétiques distribués et infrastructures numériques, constituant un nœud critique de la résilience systémique.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - energie_ressources_critiques
  - technologie_information
  - organisation_territoires

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Consortium des Fournisseurs d'Énergie Renouvelable Distribuée

## Rôle dans [[reference]]
Dans le scénario de référence, assure le couplage opérationnel entre réseaux énergétiques distribués et infrastructures numériques, constituant un nœud critique de la résilience systémique.

## Variables influencées
- [[energie_ressources_critiques]]
- [[technologie_information]]
- [[organisation_territoires]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
