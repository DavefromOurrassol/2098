---
name: Fédération des Cliniques Autonomes
type: instance
slug: federation_des_cliniques_autonomes_reference
entite: federation_des_cliniques_autonomes
scenario: reference
statut: officialise_minimal

type_dans_scenario: organisation

role_dans_scenario: >
  Acteur clé dans la structuration décentralisée de l'accès aux soins dans le scénario reference, en tension ou en complémentarité avec les institutions sanitaires dominantes.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - sante_biotechnologies
  - gouvernance_institutions
  - organisation_territoires

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Fédération des Cliniques Autonomes

## Rôle dans [[reference]]
Acteur clé dans la structuration décentralisée de l'accès aux soins dans le scénario reference, en tension ou en complémentarité avec les institutions sanitaires dominantes.

## Variables influencées
- [[sante_biotechnologies]]
- [[gouvernance_institutions]]
- [[organisation_territoires]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
