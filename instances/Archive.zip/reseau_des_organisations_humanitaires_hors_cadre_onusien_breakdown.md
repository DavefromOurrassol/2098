---
name: Réseau des Organisations Humanitaires Hors Cadre Onusien
type: instance
slug: reseau_des_organisations_humanitaires_hors_cadre_onusien_breakdown
entite: reseau_des_organisations_humanitaires_hors_cadre_onusien
scenario: breakdown
statut: officialise_minimal

type_dans_scenario: réseau

role_dans_scenario: >
  Assure une continuité minimale de l'aide humanitaire là où les mécanismes multilatéraux classiques ont cessé de fonctionner, en substituant des logiques de réseau décentralisé à la coordination étatique défaillante.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - gouvernance_institutions
  - demographie_mobilite_humaine
  - geopolitique_conflits

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Réseau des Organisations Humanitaires Hors Cadre Onusien

## Rôle dans [[breakdown]]
Assure une continuité minimale de l'aide humanitaire là où les mécanismes multilatéraux classiques ont cessé de fonctionner, en substituant des logiques de réseau décentralisé à la coordination étatique défaillante.

## Variables influencées
- [[gouvernance_institutions]]
- [[demographie_mobilite_humaine]]
- [[geopolitique_conflits]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
