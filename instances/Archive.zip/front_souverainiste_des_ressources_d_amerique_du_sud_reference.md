---
name: Front Souverainiste des Ressources d'Amérique du Sud
type: instance
slug: front_souverainiste_des_ressources_d_amerique_du_sud_reference
entite: front_souverainiste_des_ressources_d_amerique_du_sud
scenario: reference
statut: officialise_minimal

type_dans_scenario: organisation

role_dans_scenario: >
  Acteur de pression géopolitique contestant les accords d'exploitation imposés par les puissances économiques dominantes, potentiellement allié ou opposant selon les intérêts en jeu dans le scénario de référence.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - energie_ressources_critiques
  - geopolitique_conflits
  - gouvernance_institutions

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Front Souverainiste des Ressources d'Amérique du Sud

## Rôle dans [[reference]]
Acteur de pression géopolitique contestant les accords d'exploitation imposés par les puissances économiques dominantes, potentiellement allié ou opposant selon les intérêts en jeu dans le scénario de référence.

## Variables influencées
- [[energie_ressources_critiques]]
- [[geopolitique_conflits]]
- [[gouvernance_institutions]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
