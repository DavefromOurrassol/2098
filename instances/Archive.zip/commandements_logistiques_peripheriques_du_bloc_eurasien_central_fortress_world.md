---
name: Commandements Logistiques Périphériques du Bloc Eurasien Central
type: instance
slug: commandements_logistiques_peripheriques_du_bloc_eurasien_central_fortress_world
entite: commandements_logistiques_peripheriques_du_bloc_eurasien_central
scenario: fortress_world
statut: officialise_minimal

type_dans_scenario: institution

role_dans_scenario: >
  Dans fortress_world, ces commandements assurent la tenue des frontières forteresses et la gestion des corridors logistiques stratégiques face aux pressions extérieures.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - geopolitique_conflits
  - organisation_territoires
  - energie_ressources_critiques

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Commandements Logistiques Périphériques du Bloc Eurasien Central

## Rôle dans [[fortress_world]]
Dans fortress_world, ces commandements assurent la tenue des frontières forteresses et la gestion des corridors logistiques stratégiques face aux pressions extérieures.

## Variables influencées
- [[geopolitique_conflits]]
- [[organisation_territoires]]
- [[energie_ressources_critiques]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
