---
name: Factions Para-Étatiques Hydriques
type: instance
slug: factions_para_etatiques_hydriques_breakdown
entite: factions_para_etatiques_hydriques
scenario: breakdown
statut: officialise_minimal

type_dans_scenario: organisation

role_dans_scenario: >
  Dans le scénario breakdown, elles incarnent la fragmentation du pouvoir territorial autour des ressources hydriques, substituant une gouvernance coercitive locale à l'autorité étatique défaillante.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - energie_ressources_critiques
  - gouvernance_institutions
  - organisation_territoires

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Factions Para-Étatiques Hydriques

## Rôle dans [[breakdown]]
Dans le scénario breakdown, elles incarnent la fragmentation du pouvoir territorial autour des ressources hydriques, substituant une gouvernance coercitive locale à l'autorité étatique défaillante.

## Variables influencées
- [[energie_ressources_critiques]]
- [[gouvernance_institutions]]
- [[organisation_territoires]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
