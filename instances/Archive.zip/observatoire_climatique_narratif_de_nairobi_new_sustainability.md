---
name: Observatoire Climatique Narratif de Nairobi
type: instance
slug: observatoire_climatique_narratif_de_nairobi_new_sustainability
entite: observatoire_climatique_narratif_de_nairobi
scenario: new_sustainability
statut: officialise_minimal

type_dans_scenario: institution

role_dans_scenario: >
  Produit des données sur les dynamiques narratives climatiques en Afrique subsaharienne, servant de référence pour calibrer les discours médiatiques et politiques dans le scénario new_sustainability.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - climat_environnement_global
  - technologie_information
  - valeurs_culture_tempo_sociale

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Observatoire Climatique Narratif de Nairobi

## Rôle dans [[new_sustainability]]
Produit des données sur les dynamiques narratives climatiques en Afrique subsaharienne, servant de référence pour calibrer les discours médiatiques et politiques dans le scénario new_sustainability.

## Variables influencées
- [[climat_environnement_global]]
- [[technologie_information]]
- [[valeurs_culture_tempo_sociale]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
