---
name: Gouvernement d'Israël
type: instance
slug: gouvernement_israel_policy_reform
entite: gouvernement_israel
scenario: policy_reform
statut: officialise_minimal

type_dans_scenario: institution

role_dans_scenario: >
  Partie prenante directe du conflit israélo-iranien de 2026-2027 dans ce scénario policy_reform — acteur étatique dont les frappes initiales déclenchent la crise, contenue par une médiation institutionnelle internationale rapide.

responsabilites: >
  (à développer en phase 2 — fiche créée pour combler une référence d'événement custom)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - geopolitique_conflits
  - gouvernance_institutions
  - energie_ressources_critiques

zone_geographique:
  - nationale

zone_systemique:
  - gouvernance

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: dominant
generation: transition

injection:
  type: canonique
  annee_injection: 2027
  contexte_injection: Conflit Israël-Iran 2026-2027 (événement custom conflit_israel_iran_2026)
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Gouvernement d'Israël

## Rôle dans [[policy_reform]]
Partie prenante directe du conflit israélo-iranien de 2026-2027 dans ce scénario policy_reform — acteur étatique dont les frappes initiales déclenchent la crise, contenue par une médiation institutionnelle internationale rapide.

## Variables influencées
- [[geopolitique_conflits]]
- [[gouvernance_institutions]]
- [[energie_ressources_critiques]]

## Notes
Fiche créée manuellement pour combler une référence d'acteur dans l'événement custom
conflit_israel_iran_2026 (event_instances/conflit_israel_iran_2026_policy_reform.md).
À enrichir en phase 2.
