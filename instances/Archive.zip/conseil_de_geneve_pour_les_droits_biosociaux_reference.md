---
name: Conseil de Genève pour les Droits Biosociaux
type: instance
slug: conseil_de_geneve_pour_les_droits_biosociaux_reference
entite: conseil_de_geneve_pour_les_droits_biosociaux
scenario: reference
statut: officialise_minimal

type_dans_scenario: institution

role_dans_scenario: >
  Dans le scénario de référence, sert de cadre institutionnel de légitimation ou de contestation des pratiques biotechnologiques et de leurs impacts sur les populations.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - sante_biotechnologies
  - gouvernance_institutions
  - demographie_mobilite_humaine

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Conseil de Genève pour les Droits Biosociaux

## Rôle dans [[reference]]
Dans le scénario de référence, sert de cadre institutionnel de légitimation ou de contestation des pratiques biotechnologiques et de leurs impacts sur les populations.

## Variables influencées
- [[sante_biotechnologies]]
- [[gouvernance_institutions]]
- [[demographie_mobilite_humaine]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
