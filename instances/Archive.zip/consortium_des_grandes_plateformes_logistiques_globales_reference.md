---
name: Consortium des Grandes Plateformes Logistiques Globales
type: instance
slug: consortium_des_grandes_plateformes_logistiques_globales_reference
entite: consortium_des_grandes_plateformes_logistiques_globales
scenario: reference
statut: officialise_minimal

type_dans_scenario: entreprise

role_dans_scenario: >
  Dans le scénario de référence, représente l'épine dorsale matérielle de l'économie globale, dont la concentration et la puissance conditionnent les équilibres de pouvoir entre États, entreprises et territoires.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - systemes_productifs_travail
  - organisation_territoires
  - energie_ressources_critiques

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Consortium des Grandes Plateformes Logistiques Globales

## Rôle dans [[reference]]
Dans le scénario de référence, représente l'épine dorsale matérielle de l'économie globale, dont la concentration et la puissance conditionnent les équilibres de pouvoir entre États, entreprises et territoires.

## Variables influencées
- [[systemes_productifs_travail]]
- [[organisation_territoires]]
- [[energie_ressources_critiques]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
