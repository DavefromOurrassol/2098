---
name: Instances ARIA Concurrentes des Blocs Rivaux
type: instance
slug: instances_aria_concurrentes_des_blocs_rivaux_fortress_world
entite: instances_aria_concurrentes_des_blocs_rivaux
scenario: fortress_world
statut: officialise_minimal

type_dans_scenario: IA

role_dans_scenario: >
  Dans fortress_world, ces instances incarnent la course aux armements cognitifs entre blocs hermétiques, chaque puissance cherchant à disposer d'une IA de pilotage stratégique supérieure à celles des adversaires.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - geopolitique_conflits
  - technologie_information
  - gouvernance_institutions

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Instances ARIA Concurrentes des Blocs Rivaux

## Rôle dans [[fortress_world]]
Dans fortress_world, ces instances incarnent la course aux armements cognitifs entre blocs hermétiques, chaque puissance cherchant à disposer d'une IA de pilotage stratégique supérieure à celles des adversaires.

## Variables influencées
- [[geopolitique_conflits]]
- [[technologie_information]]
- [[gouvernance_institutions]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
