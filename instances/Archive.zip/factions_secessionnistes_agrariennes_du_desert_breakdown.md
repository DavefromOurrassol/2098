---
name: Factions Sécessionnistes Agrariennes du Désert
type: instance
slug: factions_secessionnistes_agrariennes_du_desert_breakdown
entite: factions_secessionnistes_agrariennes_du_desert
scenario: breakdown
statut: officialise_minimal

type_dans_scenario: organisation

role_dans_scenario: >
  Dans un scénario de breakdown, ces factions accélèrent la fragmentation des autorités centrales en contestant la légitimité des États sur les territoires en crise climatique, créant des zones grises de gouvernance où s'affrontent logiques de subsistance et logiques de contrôle.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - organisation_territoires
  - climat_environnement_global
  - geopolitique_conflits

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Factions Sécessionnistes Agrariennes du Désert

## Rôle dans [[breakdown]]
Dans un scénario de breakdown, ces factions accélèrent la fragmentation des autorités centrales en contestant la légitimité des États sur les territoires en crise climatique, créant des zones grises de gouvernance où s'affrontent logiques de subsistance et logiques de contrôle.

## Variables influencées
- [[organisation_territoires]]
- [[climat_environnement_global]]
- [[geopolitique_conflits]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
