---
name: Réseau des Lobbyistes Techniques ONU-Énergie
type: instance
slug: reseau_des_lobbyistes_techniques_onu_energie_policy_reform
entite: reseau_des_lobbyistes_techniques_onu_energie
scenario: policy_reform
statut: officialise_minimal

type_dans_scenario: réseau

role_dans_scenario: >
  Pèse sur la rédaction des normes et standards techniques au sein des comités ONU-Énergie, orientant les réformes de politique énergétique en faveur de ses mandants industriels.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - energie_ressources_critiques
  - gouvernance_institutions

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Réseau des Lobbyistes Techniques ONU-Énergie

## Rôle dans [[policy_reform]]
Pèse sur la rédaction des normes et standards techniques au sein des comités ONU-Énergie, orientant les réformes de politique énergétique en faveur de ses mandants industriels.

## Variables influencées
- [[energie_ressources_critiques]]
- [[gouvernance_institutions]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
