---
name: Archives Ouvertes des Jurisprudences Communales (AOJC)
type: instance
slug: archives_ouvertes_des_jurisprudences_communales_aojc_eco_communalism
entite: archives_ouvertes_des_jurisprudences_communales_aojc
scenario: eco_communalism
statut: officialise_minimal

type_dans_scenario: infrastructure

role_dans_scenario: >
  Fournit une référence jurisprudentielle commune aux communautés pour résoudre les conflits de droit local et harmoniser les pratiques sans recourir à un État central.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - gouvernance_institutions
  - organisation_territoires
  - technologie_information

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Archives Ouvertes des Jurisprudences Communales (AOJC)

## Rôle dans [[eco_communalism]]
Fournit une référence jurisprudentielle commune aux communautés pour résoudre les conflits de droit local et harmoniser les pratiques sans recourir à un État central.

## Variables influencées
- [[gouvernance_institutions]]
- [[organisation_territoires]]
- [[technologie_information]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
