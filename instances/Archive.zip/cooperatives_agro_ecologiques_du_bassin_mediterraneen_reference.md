---
name: Coopératives Agro-Écologiques du Bassin Méditerranéen
type: instance
slug: cooperatives_agro_ecologiques_du_bassin_mediterraneen_reference
entite: cooperatives_agro_ecologiques_du_bassin_mediterraneen
scenario: reference
statut: officialise_minimal

type_dans_scenario: réseau

role_dans_scenario: >
  Acteur clé de la souveraineté alimentaire régionale dans le scénario de référence, structurant des échanges et des solidarités productives entre communautés rurales méditerranéennes.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - systemes_productifs_travail
  - climat_environnement_global
  - organisation_territoires

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Coopératives Agro-Écologiques du Bassin Méditerranéen

## Rôle dans [[reference]]
Acteur clé de la souveraineté alimentaire régionale dans le scénario de référence, structurant des échanges et des solidarités productives entre communautés rurales méditerranéennes.

## Variables influencées
- [[systemes_productifs_travail]]
- [[climat_environnement_global]]
- [[organisation_territoires]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
