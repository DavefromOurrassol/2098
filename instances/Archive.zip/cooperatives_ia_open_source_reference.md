---
name: Coopératives IA Open-Source
type: instance
slug: cooperatives_ia_open_source_reference
entite: cooperatives_ia_open_source
scenario: reference
statut: officialise_minimal

type_dans_scenario: réseau

role_dans_scenario: >
  Dans le scénario de référence, elles représentent un contre-poids décentralisé aux IA propriétaires, offrant des alternatives accessibles et auditable à des acteurs publics ou communautaires.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - technologie_information
  - systeme_economique_redistribution
  - gouvernance_institutions

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Coopératives IA Open-Source

## Rôle dans [[reference]]
Dans le scénario de référence, elles représentent un contre-poids décentralisé aux IA propriétaires, offrant des alternatives accessibles et auditable à des acteurs publics ou communautaires.

## Variables influencées
- [[technologie_information]]
- [[systeme_economique_redistribution]]
- [[gouvernance_institutions]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
