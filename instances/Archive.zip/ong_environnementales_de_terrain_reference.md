---
name: ONG Environnementales de Terrain
type: instance
slug: ong_environnementales_de_terrain_reference
entite: ong_environnementales_de_terrain
scenario: reference
statut: officialise_minimal

type_dans_scenario: organisation

role_dans_scenario: >
  Dans le scénario de référence, elles constituent un contrepoids civil aux logiques institutionnelles ou économiques, portant une observation de terrain irremplaçable sur l'état réel de l'environnement en 2098.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - climat_environnement_global
  - organisation_territoires
  - gouvernance_institutions

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# ONG Environnementales de Terrain

## Rôle dans [[reference]]
Dans le scénario de référence, elles constituent un contrepoids civil aux logiques institutionnelles ou économiques, portant une observation de terrain irremplaçable sur l'état réel de l'environnement en 2098.

## Variables influencées
- [[climat_environnement_global]]
- [[organisation_territoires]]
- [[gouvernance_institutions]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
