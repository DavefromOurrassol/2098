---
name: Réseaux de renseignement informels issus de l'ancienne structure militaire eurasienne
type: instance
slug: reseaux_de_renseignement_informels_issus_de_l_ancienne_structure_militaire_eurasienne_breakdown
entite: reseaux_de_renseignement_informels_issus_de_l_ancienne_structure_militaire_eurasienne
scenario: breakdown
statut: officialise_minimal

type_dans_scenario: réseau

role_dans_scenario: >
  Dans un scénario de breakdown, ces réseaux constituent des acteurs de pouvoir souterrain capables d'infléchir les dynamiques locales sans apparaître dans les structures de gouvernance visibles.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - geopolitique_conflits
  - gouvernance_institutions
  - technologie_information

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Réseaux de renseignement informels issus de l'ancienne structure militaire eurasienne

## Rôle dans [[breakdown]]
Dans un scénario de breakdown, ces réseaux constituent des acteurs de pouvoir souterrain capables d'infléchir les dynamiques locales sans apparaître dans les structures de gouvernance visibles.

## Variables influencées
- [[geopolitique_conflits]]
- [[gouvernance_institutions]]
- [[technologie_information]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
