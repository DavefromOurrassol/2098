---
name: Autorités Régionales de Régulation Hydrologique
type: instance
slug: autorites_regionales_de_regulation_hydrologique_reference
entite: autorites_regionales_de_regulation_hydrologique
scenario: reference
statut: officialise_minimal

type_dans_scenario: institution

role_dans_scenario: >
  Dans ce scénario, elles constituent un acteur de régulation territoriale des ressources hydriques, arbitrant entre usages concurrents et contraintes environnementales.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - gouvernance_institutions
  - climat_environnement_global
  - organisation_territoires

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Autorités Régionales de Régulation Hydrologique

## Rôle dans [[reference]]
Dans ce scénario, elles constituent un acteur de régulation territoriale des ressources hydriques, arbitrant entre usages concurrents et contraintes environnementales.

## Variables influencées
- [[gouvernance_institutions]]
- [[climat_environnement_global]]
- [[organisation_territoires]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
