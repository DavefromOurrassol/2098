---
name: Commission Hydrique de l'Union Africaine
type: instance
slug: commission_hydrique_de_l_union_africaine_reference
entite: commission_hydrique_de_l_union_africaine
scenario: reference
statut: officialise_minimal

type_dans_scenario: institution

role_dans_scenario: >
  Acteur institutionnel de référence sur les questions d'accès à l'eau en Afrique, elle intervient comme autorité de régulation et de médiation entre États membres confrontés à des tensions hydriques croissantes.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - climat_environnement_global
  - gouvernance_institutions
  - geopolitique_conflits

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Commission Hydrique de l'Union Africaine

## Rôle dans [[reference]]
Acteur institutionnel de référence sur les questions d'accès à l'eau en Afrique, elle intervient comme autorité de régulation et de médiation entre États membres confrontés à des tensions hydriques croissantes.

## Variables influencées
- [[climat_environnement_global]]
- [[gouvernance_institutions]]
- [[geopolitique_conflits]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
