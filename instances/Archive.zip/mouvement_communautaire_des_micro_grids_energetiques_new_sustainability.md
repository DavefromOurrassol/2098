---
name: Mouvement Communautaire des Micro-Grids Énergétiques
type: instance
slug: mouvement_communautaire_des_micro_grids_energetiques_new_sustainability
entite: mouvement_communautaire_des_micro_grids_energetiques
scenario: new_sustainability
statut: officialise_minimal

type_dans_scenario: réseau

role_dans_scenario: >
  Dans le scénario new_sustainability, incarne la dynamique de réappropriation citoyenne des ressources énergétiques, en tension ou en complémentarité avec les acteurs institutionnels et industriels du secteur.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - energie_ressources_critiques
  - organisation_territoires
  - gouvernance_institutions

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Mouvement Communautaire des Micro-Grids Énergétiques

## Rôle dans [[new_sustainability]]
Dans le scénario new_sustainability, incarne la dynamique de réappropriation citoyenne des ressources énergétiques, en tension ou en complémentarité avec les acteurs institutionnels et industriels du secteur.

## Variables influencées
- [[energie_ressources_critiques]]
- [[organisation_territoires]]
- [[gouvernance_institutions]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
