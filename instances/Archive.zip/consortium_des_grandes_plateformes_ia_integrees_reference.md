---
name: Consortium des Grandes Plateformes IA Intégrées
type: instance
slug: consortium_des_grandes_plateformes_ia_integrees_reference
entite: consortium_des_grandes_plateformes_ia_integrees
scenario: reference
statut: officialise_minimal

type_dans_scenario: entreprise

role_dans_scenario: >
  Dans ce scénario, elles exercent un pouvoir structurant sur les flux informationnels et économiques globaux, agissant comme acteurs de référence incontournables face auxquels les autres entités se positionnent.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - technologie_information
  - gouvernance_institutions
  - systeme_economique_redistribution

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Consortium des Grandes Plateformes IA Intégrées

## Rôle dans [[reference]]
Dans ce scénario, elles exercent un pouvoir structurant sur les flux informationnels et économiques globaux, agissant comme acteurs de référence incontournables face auxquels les autres entités se positionnent.

## Variables influencées
- [[technologie_information]]
- [[gouvernance_institutions]]
- [[systeme_economique_redistribution]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
