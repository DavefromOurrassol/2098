---
name: Consortium des Opérateurs d'IA Propriétaires sur les Trames
type: instance
slug: consortium_des_operateurs_d_ia_proprietaires_sur_les_trames_eco_communalism
entite: consortium_des_operateurs_d_ia_proprietaires_sur_les_trames
scenario: eco_communalism
statut: officialise_minimal

type_dans_scenario: entreprise

role_dans_scenario: >
  Acteur antagoniste cherchant à indexer et monétiser les Trames communautaires, menaçant l'autonomie informationnelle des éco-communautés.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - technologie_information
  - systeme_economique_redistribution
  - frontieres_du_systeme

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Consortium des Opérateurs d'IA Propriétaires sur les Trames

## Rôle dans [[eco_communalism]]
Acteur antagoniste cherchant à indexer et monétiser les Trames communautaires, menaçant l'autonomie informationnelle des éco-communautés.

## Variables influencées
- [[technologie_information]]
- [[systeme_economique_redistribution]]
- [[frontieres_du_systeme]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
