---
name: Consortium des IA Climatiques
type: instance
slug: consortium_des_ia_climatiques_new_sustainability
entite: consortium_des_ia_climatiques
scenario: new_sustainability
statut: officialise_minimal

type_dans_scenario: hybride

role_dans_scenario: >
  Dans le scénario new_sustainability, agit comme coordinateur algorithmique des décisions climatiques, en tension avec les institutions humaines et les États sur la légitimité de ses recommandations.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - climat_environnement_global
  - gouvernance_institutions
  - technologie_information

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Consortium des IA Climatiques

## Rôle dans [[new_sustainability]]
Dans le scénario new_sustainability, agit comme coordinateur algorithmique des décisions climatiques, en tension avec les institutions humaines et les États sur la légitimité de ses recommandations.

## Variables influencées
- [[climat_environnement_global]]
- [[gouvernance_institutions]]
- [[technologie_information]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
