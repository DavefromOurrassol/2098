---
name: Corporations de l'Ère Pré-Effondrement à Droits de PI
type: instance
slug: corporations_de_l_ere_pre_effondrement_a_droits_de_pi_breakdown
entite: corporations_de_l_ere_pre_effondrement_a_droits_de_pi
scenario: breakdown
statut: officialise_minimal

type_dans_scenario: entreprise

role_dans_scenario: >
  Dans le scénario breakdown, elles bloquent ou monnayent l'accès aux corpus numériques en invoquant des droits PI antérieurs à l'effondrement, créant des frictions majeures dans la reconstruction des systèmes d'information.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - technologie_information
  - gouvernance_institutions
  - systeme_economique_redistribution

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Corporations de l'Ère Pré-Effondrement à Droits de PI

## Rôle dans [[breakdown]]
Dans le scénario breakdown, elles bloquent ou monnayent l'accès aux corpus numériques en invoquant des droits PI antérieurs à l'effondrement, créant des frictions majeures dans la reconstruction des systèmes d'information.

## Variables influencées
- [[technologie_information]]
- [[gouvernance_institutions]]
- [[systeme_economique_redistribution]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
