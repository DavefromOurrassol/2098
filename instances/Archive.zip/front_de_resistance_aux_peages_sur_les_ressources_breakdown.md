---
name: Front de Résistance aux Péages sur les Ressources
type: instance
slug: front_de_resistance_aux_peages_sur_les_ressources_breakdown
entite: front_de_resistance_aux_peages_sur_les_ressources
scenario: breakdown
statut: officialise_minimal

type_dans_scenario: organisation

role_dans_scenario: >
  Dans le scénario breakdown, incarne la friction sociale face à la fragmentation des droits d'accès aux ressources fondamentales, cristallisant les tensions entre survie locale et logiques extractives dominantes.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - energie_ressources_critiques
  - gouvernance_institutions
  - organisation_territoires

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Front de Résistance aux Péages sur les Ressources

## Rôle dans [[breakdown]]
Dans le scénario breakdown, incarne la friction sociale face à la fragmentation des droits d'accès aux ressources fondamentales, cristallisant les tensions entre survie locale et logiques extractives dominantes.

## Variables influencées
- [[energie_ressources_critiques]]
- [[gouvernance_institutions]]
- [[organisation_territoires]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
