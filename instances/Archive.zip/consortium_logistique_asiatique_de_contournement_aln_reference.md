---
name: Consortium Logistique Asiatique de Contournement ALN
type: instance
slug: consortium_logistique_asiatique_de_contournement_aln_reference
entite: consortium_logistique_asiatique_de_contournement_aln
scenario: reference
statut: officialise_minimal

type_dans_scenario: entreprise

role_dans_scenario: >
  Dans ce scénario, il agit comme faction de contournement structurel face aux infrastructures ALN, fragilisant leur emprise sur les flux de marchandises.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - geopolitique_conflits
  - organisation_territoires
  - systeme_economique_redistribution

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Consortium Logistique Asiatique de Contournement ALN

## Rôle dans [[reference]]
Dans ce scénario, il agit comme faction de contournement structurel face aux infrastructures ALN, fragilisant leur emprise sur les flux de marchandises.

## Variables influencées
- [[geopolitique_conflits]]
- [[organisation_territoires]]
- [[systeme_economique_redistribution]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
