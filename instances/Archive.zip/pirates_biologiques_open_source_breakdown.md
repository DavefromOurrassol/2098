---
name: Pirates Biologiques Open-Source
type: instance
slug: pirates_biologiques_open_source_breakdown
entite: pirates_biologiques_open_source
scenario: breakdown
statut: officialise_minimal

type_dans_scenario: réseau

role_dans_scenario: >
  Dans un contexte de breakdown, ils représentent une force de contournement des infrastructures sanitaires et industrielles effondrées, diffusant des solutions biologiques bricolées face à la défaillance des systèmes officiels.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - sante_biotechnologies
  - gouvernance_institutions
  - technologie_information

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Pirates Biologiques Open-Source

## Rôle dans [[breakdown]]
Dans un contexte de breakdown, ils représentent une force de contournement des infrastructures sanitaires et industrielles effondrées, diffusant des solutions biologiques bricolées face à la défaillance des systèmes officiels.

## Variables influencées
- [[sante_biotechnologies]]
- [[gouvernance_institutions]]
- [[technologie_information]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
