---
name: Collège des Auditeurs Indépendants du Parlement Biotechnologique Mondial
type: instance
slug: college_des_auditeurs_independants_du_parlement_biotechnologique_mondial_new_sustainability
entite: college_des_auditeurs_independants_du_parlement_biotechnologique_mondial
scenario: new_sustainability
statut: officialise_minimal

type_dans_scenario: organisation

role_dans_scenario: >
  Dans le scénario new_sustainability, assure la surveillance externe des orientations biotechnologiques adoptées par le Parlement, signalant les dérives ou conflits d'intérêts dans un secteur à enjeux existentiels.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - gouvernance_institutions
  - sante_biotechnologies
  - frontieres_du_systeme

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Collège des Auditeurs Indépendants du Parlement Biotechnologique Mondial

## Rôle dans [[new_sustainability]]
Dans le scénario new_sustainability, assure la surveillance externe des orientations biotechnologiques adoptées par le Parlement, signalant les dérives ou conflits d'intérêts dans un secteur à enjeux existentiels.

## Variables influencées
- [[gouvernance_institutions]]
- [[sante_biotechnologies]]
- [[frontieres_du_systeme]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
