---
name: Front de Souveraineté Biologique Eurasiatique
type: instance
slug: front_de_souverainete_biologique_eurasiatique_policy_reform
entite: front_de_souverainete_biologique_eurasiatique
scenario: policy_reform
statut: officialise_minimal

type_dans_scenario: organisation

role_dans_scenario: >
  Dans le scénario policy_reform, constitue un bloc de résistance aux réformes de gouvernance biotech proposées à l'échelle internationale, en revendiquant le droit absolu des États eurasiatiques à définir leurs propres standards biologiques et génétiques.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - sante_biotechnologies
  - geopolitique_conflits
  - gouvernance_institutions

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Front de Souveraineté Biologique Eurasiatique

## Rôle dans [[policy_reform]]
Dans le scénario policy_reform, constitue un bloc de résistance aux réformes de gouvernance biotech proposées à l'échelle internationale, en revendiquant le droit absolu des États eurasiatiques à définir leurs propres standards biologiques et génétiques.

## Variables influencées
- [[sante_biotechnologies]]
- [[geopolitique_conflits]]
- [[gouvernance_institutions]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
