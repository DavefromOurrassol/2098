---
name: Brigades de Restauration Écologique
type: instance
slug: brigades_de_restauration_ecologique_eco_communalism
entite: brigades_de_restauration_ecologique
scenario: eco_communalism
statut: officialise_minimal

type_dans_scenario: organisation

role_dans_scenario: >
  Assurent sur le terrain la réhabilitation des milieux naturels dans le cadre des engagements communautaires du scénario écocommounaliste.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - climat_environnement_global
  - organisation_territoires
  - systemes_productifs_travail

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Brigades de Restauration Écologique

## Rôle dans [[eco_communalism]]
Assurent sur le terrain la réhabilitation des milieux naturels dans le cadre des engagements communautaires du scénario écocommounaliste.

## Variables influencées
- [[climat_environnement_global]]
- [[organisation_territoires]]
- [[systemes_productifs_travail]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
