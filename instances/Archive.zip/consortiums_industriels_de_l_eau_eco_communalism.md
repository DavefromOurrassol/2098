---
name: Consortiums Industriels de l'Eau
type: instance
slug: consortiums_industriels_de_l_eau_eco_communalism
entite: consortiums_industriels_de_l_eau
scenario: eco_communalism
statut: officialise_minimal

type_dans_scenario: entreprise

role_dans_scenario: >
  Dans le scénario eco_communalism, ils constituent la principale force antagoniste aux communautés autogérées, tentant de reprendre la main sur les nappes phréatiques que ces dernières gèrent collectivement.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - energie_ressources_critiques
  - gouvernance_institutions
  - organisation_territoires

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Consortiums Industriels de l'Eau

## Rôle dans [[eco_communalism]]
Dans le scénario eco_communalism, ils constituent la principale force antagoniste aux communautés autogérées, tentant de reprendre la main sur les nappes phréatiques que ces dernières gèrent collectivement.

## Variables influencées
- [[energie_ressources_critiques]]
- [[gouvernance_institutions]]
- [[organisation_territoires]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
