---
name: Conseil de Délibération Augmentée de l'Union Nordique
type: instance
slug: conseil_de_deliberation_augmentee_de_l_union_nordique_new_sustainability
entite: conseil_de_deliberation_augmentee_de_l_union_nordique
scenario: new_sustainability
statut: officialise_minimal

type_dans_scenario: institution

role_dans_scenario: >
  Dans le scénario new_sustainability, sert de cadre institutionnel pour arbitrer les orientations de durabilité systémique au sein de l'Union Nordique, en articulant données environnementales et légitimité délibérative.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - gouvernance_institutions
  - technologie_information
  - climat_environnement_global

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Conseil de Délibération Augmentée de l'Union Nordique

## Rôle dans [[new_sustainability]]
Dans le scénario new_sustainability, sert de cadre institutionnel pour arbitrer les orientations de durabilité systémique au sein de l'Union Nordique, en articulant données environnementales et légitimité délibérative.

## Variables influencées
- [[gouvernance_institutions]]
- [[technologie_information]]
- [[climat_environnement_global]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
