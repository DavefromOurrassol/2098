---
name: Réseaux de juristes spécialisés en droit corporel souverain
type: instance
slug: reseaux_de_juristes_specialises_en_droit_corporel_souverain_fortress_world
entite: reseaux_de_juristes_specialises_en_droit_corporel_souverain
scenario: fortress_world
statut: officialise_minimal

type_dans_scenario: réseau

role_dans_scenario: >
  Fournissent un cadre légal aux individus et communautés cherchant à protéger l'intégrité corporelle contre les empiètements des États-forteresses et des corporations biotechnologiques.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - gouvernance_institutions
  - sante_biotechnologies
  - organisation_territoires

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Réseaux de juristes spécialisés en droit corporel souverain

## Rôle dans [[fortress_world]]
Fournissent un cadre légal aux individus et communautés cherchant à protéger l'intégrité corporelle contre les empiètements des États-forteresses et des corporations biotechnologiques.

## Variables influencées
- [[gouvernance_institutions]]
- [[sante_biotechnologies]]
- [[organisation_territoires]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
