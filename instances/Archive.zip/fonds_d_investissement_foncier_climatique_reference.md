---
name: Fonds d'Investissement Foncier Climatique
type: instance
slug: fonds_d_investissement_foncier_climatique_reference
entite: fonds_d_investissement_foncier_climatique
scenario: reference
statut: officialise_minimal

type_dans_scenario: institution

role_dans_scenario: >
  Dans le scénario de référence, constitue un acteur structurant des dynamiques territoriales en orientant les flux de capital vers des logiques foncières climatiques, influençant l'accès à la terre et sa redistribution.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - organisation_territoires
  - systeme_economique_redistribution
  - climat_environnement_global

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Fonds d'Investissement Foncier Climatique

## Rôle dans [[reference]]
Dans le scénario de référence, constitue un acteur structurant des dynamiques territoriales en orientant les flux de capital vers des logiques foncières climatiques, influençant l'accès à la terre et sa redistribution.

## Variables influencées
- [[organisation_territoires]]
- [[systeme_economique_redistribution]]
- [[climat_environnement_global]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
