---
name: Factions Technocratiques de la Marchandisation Hydrique
type: instance
slug: factions_technocratiques_de_la_marchandisation_hydrique_policy_reform
entite: factions_technocratiques_de_la_marchandisation_hydrique
scenario: policy_reform
statut: officialise_minimal

type_dans_scenario: organisation

role_dans_scenario: >
  Dans ce scénario de réforme politique, elles s'opposent aux régulations publiques de l'eau en défendant des modèles de gouvernance techno-marchands face aux partisans d'un accès universel garanti.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - energie_ressources_critiques
  - gouvernance_institutions
  - systeme_economique_redistribution

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Factions Technocratiques de la Marchandisation Hydrique

## Rôle dans [[policy_reform]]
Dans ce scénario de réforme politique, elles s'opposent aux régulations publiques de l'eau en défendant des modèles de gouvernance techno-marchands face aux partisans d'un accès universel garanti.

## Variables influencées
- [[energie_ressources_critiques]]
- [[gouvernance_institutions]]
- [[systeme_economique_redistribution]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
