---
name: Collectifs de Pêche Inuit et Sami
type: instance
slug: collectifs_de_peche_inuit_et_sami_reference
entite: collectifs_de_peche_inuit_et_sami
scenario: reference
statut: officialise_minimal

type_dans_scenario: organisation

role_dans_scenario: >
  Acteurs en résistance contre la spoliation de territoires ancestraux rendus accessibles et exploitables par le recul des glaces, porteurs de revendications juridiques et culturelles sur ces espaces.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - organisation_territoires
  - climat_environnement_global
  - valeurs_culture_tempo_sociale

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Collectifs de Pêche Inuit et Sami

## Rôle dans [[reference]]
Acteurs en résistance contre la spoliation de territoires ancestraux rendus accessibles et exploitables par le recul des glaces, porteurs de revendications juridiques et culturelles sur ces espaces.

## Variables influencées
- [[organisation_territoires]]
- [[climat_environnement_global]]
- [[valeurs_culture_tempo_sociale]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
