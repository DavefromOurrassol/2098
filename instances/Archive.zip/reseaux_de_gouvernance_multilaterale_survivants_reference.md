---
name: Réseaux de gouvernance multilatérale survivants
type: instance
slug: reseaux_de_gouvernance_multilaterale_survivants_reference
entite: reseaux_de_gouvernance_multilaterale_survivants
scenario: reference
statut: officialise_minimal

type_dans_scenario: réseau

role_dans_scenario: >
  Représente la persistance — fragile et contestée — d'une logique de coopération internationale dans un monde où les logiques souverainistes et les puissances privées ont largement pris le dessus.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - gouvernance_institutions
  - geopolitique_conflits
  - organisation_territoires

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Réseaux de gouvernance multilatérale survivants

## Rôle dans [[reference]]
Représente la persistance — fragile et contestée — d'une logique de coopération internationale dans un monde où les logiques souverainistes et les puissances privées ont largement pris le dessus.

## Variables influencées
- [[gouvernance_institutions]]
- [[geopolitique_conflits]]
- [[organisation_territoires]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
