---
name: Collectifs Riverains du Bassin du Congo
type: instance
slug: collectifs_riverains_du_bassin_du_congo_new_sustainability
entite: collectifs_riverains_du_bassin_du_congo
scenario: new_sustainability
statut: officialise_minimal

type_dans_scenario: réseau

role_dans_scenario: >
  Dans le scénario new_sustainability, représentent une voix de terrain contestant ou conditionnant les grandes décisions environnementales globales, en revendiquant la souveraineté locale sur la gestion durable de la forêt tropicale.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - organisation_territoires
  - climat_environnement_global
  - gouvernance_institutions

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Collectifs Riverains du Bassin du Congo

## Rôle dans [[new_sustainability]]
Dans le scénario new_sustainability, représentent une voix de terrain contestant ou conditionnant les grandes décisions environnementales globales, en revendiquant la souveraineté locale sur la gestion durable de la forêt tropicale.

## Variables influencées
- [[organisation_territoires]]
- [[climat_environnement_global]]
- [[gouvernance_institutions]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
