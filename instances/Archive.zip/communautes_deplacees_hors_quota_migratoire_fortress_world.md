---
name: Communautés Déplacées Hors Quota Migratoire
type: instance
slug: communautes_deplacees_hors_quota_migratoire_fortress_world
entite: communautes_deplacees_hors_quota_migratoire
scenario: fortress_world
statut: officialise_minimal

type_dans_scenario: réseau

role_dans_scenario: >
  Dans le scénario fortress_world, elles représentent la masse de personnes rejetées hors des flux migratoires légitimés, contraintes à des trajectoires informelles, précaires ou clandestines aux marges des territoires fortifiés.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - demographie_mobilite_humaine
  - organisation_territoires
  - gouvernance_institutions

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Communautés Déplacées Hors Quota Migratoire

## Rôle dans [[fortress_world]]
Dans le scénario fortress_world, elles représentent la masse de personnes rejetées hors des flux migratoires légitimés, contraintes à des trajectoires informelles, précaires ou clandestines aux marges des territoires fortifiés.

## Variables influencées
- [[demographie_mobilite_humaine]]
- [[organisation_territoires]]
- [[gouvernance_institutions]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
