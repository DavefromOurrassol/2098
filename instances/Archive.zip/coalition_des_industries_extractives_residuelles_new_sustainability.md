---
name: Coalition des Industries Extractives Résiduelles
type: instance
slug: coalition_des_industries_extractives_residuelles_new_sustainability
entite: coalition_des_industries_extractives_residuelles
scenario: new_sustainability
statut: officialise_minimal

type_dans_scenario: organisation

role_dans_scenario: >
  Dans le scénario new_sustainability, représente une force d'inertie et de résistance aux nouvelles normes de durabilité, cherchant à préserver des droits d'exploitation et des subventions dans un contexte de redéfinition des modèles productifs.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - energie_ressources_critiques
  - systemes_productifs_travail
  - gouvernance_institutions

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Coalition des Industries Extractives Résiduelles

## Rôle dans [[new_sustainability]]
Dans le scénario new_sustainability, représente une force d'inertie et de résistance aux nouvelles normes de durabilité, cherchant à préserver des droits d'exploitation et des subventions dans un contexte de redéfinition des modèles productifs.

## Variables influencées
- [[energie_ressources_critiques]]
- [[systemes_productifs_travail]]
- [[gouvernance_institutions]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
