---
name: Réseau de Récupération Industrielle Illicite
type: instance
slug: reseau_de_recuperation_industrielle_illicite_breakdown
entite: reseau_de_recuperation_industrielle_illicite
scenario: breakdown
statut: officialise_minimal

type_dans_scenario: réseau

role_dans_scenario: >
  Accélère la dégradation des infrastructures productives en prélevant les équipements récupérables avant toute tentative de relance. Constitue un obstacle majeur à toute reconstruction économique locale.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - energie_ressources_critiques
  - gouvernance_institutions
  - systemes_productifs_travail

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Réseau de Récupération Industrielle Illicite

## Rôle dans [[breakdown]]
Accélère la dégradation des infrastructures productives en prélevant les équipements récupérables avant toute tentative de relance. Constitue un obstacle majeur à toute reconstruction économique locale.

## Variables influencées
- [[energie_ressources_critiques]]
- [[gouvernance_institutions]]
- [[systemes_productifs_travail]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
