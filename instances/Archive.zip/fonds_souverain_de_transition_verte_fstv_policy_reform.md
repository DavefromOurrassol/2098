---
name: Fonds Souverain de Transition Verte (FSTV)
type: instance
slug: fonds_souverain_de_transition_verte_fstv_policy_reform
entite: fonds_souverain_de_transition_verte_fstv
scenario: policy_reform
statut: officialise_minimal

type_dans_scenario: institution

role_dans_scenario: >
  Dans le scénario policy_reform, le FSTV est un levier central de réorientation des investissements publics, potentiellement enjeu de réforme ou acteur de résistance selon les arbitrages politiques en cours.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - systeme_economique_redistribution
  - gouvernance_institutions
  - climat_environnement_global

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Fonds Souverain de Transition Verte (FSTV)

## Rôle dans [[policy_reform]]
Dans le scénario policy_reform, le FSTV est un levier central de réorientation des investissements publics, potentiellement enjeu de réforme ou acteur de résistance selon les arbitrages politiques en cours.

## Variables influencées
- [[systeme_economique_redistribution]]
- [[gouvernance_institutions]]
- [[climat_environnement_global]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
