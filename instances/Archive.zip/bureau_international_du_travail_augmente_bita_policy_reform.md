---
name: Bureau International du Travail Augmenté (BITA)
type: instance
slug: bureau_international_du_travail_augmente_bita_policy_reform
entite: bureau_international_du_travail_augmente_bita
scenario: policy_reform
statut: officialise_minimal

type_dans_scenario: institution

role_dans_scenario: >
  Dans le scénario policy_reform, le BITA constitue un levier institutionnel central pour faire passer ou bloquer des réformes liées aux droits des travailleurs augmentés et aux conditions d'emploi dans les systèmes productifs hybrides.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - systemes_productifs_travail
  - gouvernance_institutions
  - systeme_economique_redistribution

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Bureau International du Travail Augmenté (BITA)

## Rôle dans [[policy_reform]]
Dans le scénario policy_reform, le BITA constitue un levier institutionnel central pour faire passer ou bloquer des réformes liées aux droits des travailleurs augmentés et aux conditions d'emploi dans les systèmes productifs hybrides.

## Variables influencées
- [[systemes_productifs_travail]]
- [[gouvernance_institutions]]
- [[systeme_economique_redistribution]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
