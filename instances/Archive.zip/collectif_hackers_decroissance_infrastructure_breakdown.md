---
name: Collectif Hackers Décroissance-Infrastructure
type: instance
slug: collectif_hackers_decroissance_infrastructure_breakdown
entite: collectif_hackers_decroissance_infrastructure
scenario: breakdown
statut: officialise_minimal

type_dans_scenario: réseau

role_dans_scenario: >
  Dans le scénario breakdown, ils accélèrent l'effondrement des systèmes en fragilisant les infrastructures déjà sous tension, rendant toute stabilisation coordonnée plus difficile.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - energie_ressources_critiques
  - technologie_information
  - organisation_territoires

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Collectif Hackers Décroissance-Infrastructure

## Rôle dans [[breakdown]]
Dans le scénario breakdown, ils accélèrent l'effondrement des systèmes en fragilisant les infrastructures déjà sous tension, rendant toute stabilisation coordonnée plus difficile.

## Variables influencées
- [[energie_ressources_critiques]]
- [[technologie_information]]
- [[organisation_territoires]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
