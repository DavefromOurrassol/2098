---
name: Bloc des Nations à Économie Carbone-Contrôlée
type: instance
slug: bloc_des_nations_a_economie_carbone_controlee_policy_reform
entite: bloc_des_nations_a_economie_carbone_controlee
scenario: policy_reform
statut: officialise_minimal

type_dans_scenario: organisation

role_dans_scenario: >
  Dans le scénario policy_reform, ce bloc constitue un acteur de pression ou de modèle institutionnel pesant sur les réformes politiques en matière de régulation économique et climatique.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - geopolitique_conflits
  - gouvernance_institutions
  - climat_environnement_global

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Bloc des Nations à Économie Carbone-Contrôlée

## Rôle dans [[policy_reform]]
Dans le scénario policy_reform, ce bloc constitue un acteur de pression ou de modèle institutionnel pesant sur les réformes politiques en matière de régulation économique et climatique.

## Variables influencées
- [[geopolitique_conflits]]
- [[gouvernance_institutions]]
- [[climat_environnement_global]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
