---
name: Factions Technocratiques du Conseil de Régulation Informationnelle Global
type: instance
slug: factions_technocratiques_du_conseil_de_regulation_informationnelle_global_new_sustainability
entite: factions_technocratiques_du_conseil_de_regulation_informationnelle_global
scenario: new_sustainability
statut: officialise_minimal

type_dans_scenario: organisation

role_dans_scenario: >
  Exercent une pression structurelle au sein du Conseil pour orienter les normes informationnelles mondiales vers des modèles de contrôle centralisé, en s'opposant aux logiques de souveraineté numérique décentralisée portées par d'autres acteurs du scénario new_sustainability.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - gouvernance_institutions
  - technologie_information
  - geopolitique_conflits

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Factions Technocratiques du Conseil de Régulation Informationnelle Global

## Rôle dans [[new_sustainability]]
Exercent une pression structurelle au sein du Conseil pour orienter les normes informationnelles mondiales vers des modèles de contrôle centralisé, en s'opposant aux logiques de souveraineté numérique décentralisée portées par d'autres acteurs du scénario new_sustainability.

## Variables influencées
- [[gouvernance_institutions]]
- [[technologie_information]]
- [[geopolitique_conflits]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
