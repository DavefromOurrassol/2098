---
name: Cartel des Terres Rares d'Asie Centrale
type: instance
slug: cartel_des_terres_rares_d_asie_centrale_reference
entite: cartel_des_terres_rares_d_asie_centrale
scenario: reference
statut: officialise_minimal

type_dans_scenario: entreprise

role_dans_scenario: >
  Acteur de pression sur les équilibres géopolitiques et économiques du scénario, capable de conditionner l'accès aux ressources critiques nécessaires aux technologies de 2098.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - energie_ressources_critiques
  - geopolitique_conflits
  - systeme_economique_redistribution

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Cartel des Terres Rares d'Asie Centrale

## Rôle dans [[reference]]
Acteur de pression sur les équilibres géopolitiques et économiques du scénario, capable de conditionner l'accès aux ressources critiques nécessaires aux technologies de 2098.

## Variables influencées
- [[energie_ressources_critiques]]
- [[geopolitique_conflits]]
- [[systeme_economique_redistribution]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
