---
name: Réseaux d'échange clandestin inter-zones
type: instance
slug: reseaux_d_echange_clandestin_inter_zones_fortress_world
entite: reseaux_d_echange_clandestin_inter_zones
scenario: fortress_world
statut: officialise_minimal

type_dans_scenario: réseau

role_dans_scenario: >
  Constituent une porosité de fait dans un système conçu pour l'étanchéité totale, fragilisant ou contournant la logique de cloisonnement territorial sur laquelle repose le scénario fortress_world.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - frontieres_du_systeme
  - organisation_territoires
  - demographie_mobilite_humaine

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Réseaux d'échange clandestin inter-zones

## Rôle dans [[fortress_world]]
Constituent une porosité de fait dans un système conçu pour l'étanchéité totale, fragilisant ou contournant la logique de cloisonnement territorial sur laquelle repose le scénario fortress_world.

## Variables influencées
- [[frontieres_du_systeme]]
- [[organisation_territoires]]
- [[demographie_mobilite_humaine]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
