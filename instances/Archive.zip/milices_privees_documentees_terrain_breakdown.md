---
name: Milices Privées Documentées Terrain
type: instance
slug: milices_privees_documentees_terrain_breakdown
entite: milices_privees_documentees_terrain
scenario: breakdown
statut: officialise_minimal

type_dans_scenario: organisation

role_dans_scenario: >
  Dans le scénario breakdown, elles constituent des acteurs de substitution aux institutions défaillantes, contrôlant des territoires ou des ressources là où l'État s'est retiré.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - geopolitique_conflits
  - gouvernance_institutions
  - organisation_territoires

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Milices Privées Documentées Terrain

## Rôle dans [[breakdown]]
Dans le scénario breakdown, elles constituent des acteurs de substitution aux institutions défaillantes, contrôlant des territoires ou des ressources là où l'État s'est retiré.

## Variables influencées
- [[geopolitique_conflits]]
- [[gouvernance_institutions]]
- [[organisation_territoires]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
