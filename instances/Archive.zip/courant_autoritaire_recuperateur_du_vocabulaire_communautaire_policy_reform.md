---
name: Courant Autoritaire Récupérateur du Vocabulaire Communautaire
type: instance
slug: courant_autoritaire_recuperateur_du_vocabulaire_communautaire_policy_reform
entite: courant_autoritaire_recuperateur_du_vocabulaire_communautaire
scenario: policy_reform
statut: officialise_minimal

type_dans_scenario: autre

role_dans_scenario: >
  Dans ce scénario de réforme des politiques publiques, ce courant détourne les discours réformateurs pour imposer des régulations sans transparence ni redevabilité réelle.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - gouvernance_institutions
  - valeurs_culture_tempo_sociale
  - technologie_information

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Courant Autoritaire Récupérateur du Vocabulaire Communautaire

## Rôle dans [[policy_reform]]
Dans ce scénario de réforme des politiques publiques, ce courant détourne les discours réformateurs pour imposer des régulations sans transparence ni redevabilité réelle.

## Variables influencées
- [[gouvernance_institutions]]
- [[valeurs_culture_tempo_sociale]]
- [[technologie_information]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
