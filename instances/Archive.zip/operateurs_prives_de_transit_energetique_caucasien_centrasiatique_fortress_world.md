---
name: Opérateurs Privés de Transit Énergétique Caucasien-Centrasiatique
type: instance
slug: operateurs_prives_de_transit_energetique_caucasien_centrasiatique_fortress_world
entite: operateurs_prives_de_transit_energetique_caucasien_centrasiatique
scenario: fortress_world
statut: officialise_minimal

type_dans_scenario: entreprise

role_dans_scenario: >
  Dans le scénario fortress_world, ils exploitent l'absence de gouvernance centralisée pour contrôler des flux énergétiques critiques, servant d'intermédiaires incontournables entre blocs rivaux tout en extrayant des rentes de leur position de passage obligé.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - energie_ressources_critiques
  - geopolitique_conflits
  - organisation_territoires

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Opérateurs Privés de Transit Énergétique Caucasien-Centrasiatique

## Rôle dans [[fortress_world]]
Dans le scénario fortress_world, ils exploitent l'absence de gouvernance centralisée pour contrôler des flux énergétiques critiques, servant d'intermédiaires incontournables entre blocs rivaux tout en extrayant des rentes de leur position de passage obligé.

## Variables influencées
- [[energie_ressources_critiques]]
- [[geopolitique_conflits]]
- [[organisation_territoires]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
