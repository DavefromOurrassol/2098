---
name: Conseils Territoriaux Opaques sur la Gestion des Ressources
type: instance
slug: conseils_territoriaux_opaques_sur_la_gestion_des_ressources_eco_communalism
entite: conseils_territoriaux_opaques_sur_la_gestion_des_ressources
scenario: eco_communalism
statut: officialise_minimal

type_dans_scenario: institution

role_dans_scenario: >
  Nœuds de gouvernance opaque qui contrôlent les flux de ressources critiques à l'échelle territoriale, pouvant bloquer ou favoriser certains groupes selon des logiques internes non rendues publiques.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - organisation_territoires
  - gouvernance_institutions
  - energie_ressources_critiques

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Conseils Territoriaux Opaques sur la Gestion des Ressources

## Rôle dans [[eco_communalism]]
Nœuds de gouvernance opaque qui contrôlent les flux de ressources critiques à l'échelle territoriale, pouvant bloquer ou favoriser certains groupes selon des logiques internes non rendues publiques.

## Variables influencées
- [[organisation_territoires]]
- [[gouvernance_institutions]]
- [[energie_ressources_critiques]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
