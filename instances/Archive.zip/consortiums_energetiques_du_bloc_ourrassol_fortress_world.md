---
name: Consortiums Énergétiques du Bloc Ourrassol
type: instance
slug: consortiums_energetiques_du_bloc_ourrassol_fortress_world
entite: consortiums_energetiques_du_bloc_ourrassol
scenario: fortress_world
statut: officialise_minimal

type_dans_scenario: entreprise

role_dans_scenario: >
  Dans le scénario fortress_world, ces consortiums constituent l'un des piliers du repli souverain : ils sécurisent l'autonomie énergétique du bloc tout en conditionnant l'accès aux ressources comme levier de pouvoir géopolitique.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - energie_ressources_critiques
  - geopolitique_conflits
  - systeme_economique_redistribution

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Consortiums Énergétiques du Bloc Ourrassol

## Rôle dans [[fortress_world]]
Dans le scénario fortress_world, ces consortiums constituent l'un des piliers du repli souverain : ils sécurisent l'autonomie énergétique du bloc tout en conditionnant l'accès aux ressources comme levier de pouvoir géopolitique.

## Variables influencées
- [[energie_ressources_critiques]]
- [[geopolitique_conflits]]
- [[systeme_economique_redistribution]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
