---
name: Institut de Thérapeutique Intégrée de Nairobi
type: instance
slug: institut_de_therapeutique_integree_de_nairobi_policy_reform
entite: institut_de_therapeutique_integree_de_nairobi
scenario: policy_reform
statut: officialise_minimal

type_dans_scenario: institution

role_dans_scenario: >
  Acteur clé dans les débats de réforme des politiques de santé, portant une vision alternative aux standards thérapeutiques imposés par les grandes puissances pharmaceutiques mondiales.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - sante_biotechnologies
  - gouvernance_institutions
  - valeurs_culture_tempo_sociale

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Institut de Thérapeutique Intégrée de Nairobi

## Rôle dans [[policy_reform]]
Acteur clé dans les débats de réforme des politiques de santé, portant une vision alternative aux standards thérapeutiques imposés par les grandes puissances pharmaceutiques mondiales.

## Variables influencées
- [[sante_biotechnologies]]
- [[gouvernance_institutions]]
- [[valeurs_culture_tempo_sociale]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
