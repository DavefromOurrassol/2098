---
name: Communautés Isolationnistes Refusant la Continuité Écologique
type: instance
slug: communautes_isolationnistes_refusant_la_continuite_ecologique_eco_communalism
entite: communautes_isolationnistes_refusant_la_continuite_ecologique
scenario: eco_communalism
statut: officialise_minimal

type_dans_scenario: réseau

role_dans_scenario: >
  Opposants actifs aux obligations de continuité écologique dans le scénario eco_communalism, leur résistance crée des discontinuités dans les trames écologiques planifiées à l'échelle régionale ou planétaire.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - organisation_territoires
  - climat_environnement_global
  - gouvernance_institutions

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Communautés Isolationnistes Refusant la Continuité Écologique

## Rôle dans [[eco_communalism]]
Opposants actifs aux obligations de continuité écologique dans le scénario eco_communalism, leur résistance crée des discontinuités dans les trames écologiques planifiées à l'échelle régionale ou planétaire.

## Variables influencées
- [[organisation_territoires]]
- [[climat_environnement_global]]
- [[gouvernance_institutions]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
