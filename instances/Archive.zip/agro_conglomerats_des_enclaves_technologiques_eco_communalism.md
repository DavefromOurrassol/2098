---
name: Agro-Conglomérats des Enclaves Technologiques
type: instance
slug: agro_conglomerats_des_enclaves_technologiques_eco_communalism
entite: agro_conglomerats_des_enclaves_technologiques
scenario: eco_communalism
statut: officialise_minimal

type_dans_scenario: entreprise

role_dans_scenario: >
  Représentent le pôle extractif et concentré de la production alimentaire, en tension structurelle avec les logiques communalistes et les réseaux alimentaires décentralisés du scénario.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - systemes_productifs_travail
  - organisation_territoires
  - energie_ressources_critiques

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Agro-Conglomérats des Enclaves Technologiques

## Rôle dans [[eco_communalism]]
Représentent le pôle extractif et concentré de la production alimentaire, en tension structurelle avec les logiques communalistes et les réseaux alimentaires décentralisés du scénario.

## Variables influencées
- [[systemes_productifs_travail]]
- [[organisation_territoires]]
- [[energie_ressources_critiques]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
