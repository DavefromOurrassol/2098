---
name: Collectifs de Biopiraterie Inversée
type: instance
slug: collectifs_de_biopiraterie_inversee_reference
entite: collectifs_de_biopiraterie_inversee
scenario: reference
statut: officialise_minimal

type_dans_scenario: réseau

role_dans_scenario: >
  Dans ce scénario, ils agissent comme vecteurs de friction juridique et symbolique contre les monopoles biotechnologiques, en opérant dans les zones grises du droit international.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - sante_biotechnologies
  - gouvernance_institutions
  - systeme_economique_redistribution

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Collectifs de Biopiraterie Inversée

## Rôle dans [[reference]]
Dans ce scénario, ils agissent comme vecteurs de friction juridique et symbolique contre les monopoles biotechnologiques, en opérant dans les zones grises du droit international.

## Variables influencées
- [[sante_biotechnologies]]
- [[gouvernance_institutions]]
- [[systeme_economique_redistribution]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
