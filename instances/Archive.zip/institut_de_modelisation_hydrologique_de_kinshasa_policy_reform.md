---
name: Institut de Modélisation Hydrologique de Kinshasa
type: instance
slug: institut_de_modelisation_hydrologique_de_kinshasa_policy_reform
entite: institut_de_modelisation_hydrologique_de_kinshasa
scenario: policy_reform
statut: officialise_minimal

type_dans_scenario: institution

role_dans_scenario: >
  Fournit l'expertise technique et les modèles prévisionnels qui alimentent les réformes de politique hydrique, notamment en matière d'allocation des ressources en eau et d'adaptation climatique.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - climat_environnement_global
  - gouvernance_institutions
  - organisation_territoires

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Institut de Modélisation Hydrologique de Kinshasa

## Rôle dans [[policy_reform]]
Fournit l'expertise technique et les modèles prévisionnels qui alimentent les réformes de politique hydrique, notamment en matière d'allocation des ressources en eau et d'adaptation climatique.

## Variables influencées
- [[climat_environnement_global]]
- [[gouvernance_institutions]]
- [[organisation_territoires]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
