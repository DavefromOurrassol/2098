---
name: Collectifs de Résistance aux Relocalisations Forcées
type: instance
slug: collectifs_de_resistance_aux_relocalisations_forcees_policy_reform
entite: collectifs_de_resistance_aux_relocalisations_forcees
scenario: policy_reform
statut: officialise_minimal

type_dans_scenario: réseau

role_dans_scenario: >
  Dans le scénario policy_reform, ces collectifs constituent une force de résistance aux politiques de réaménagement territorial, pesant sur les arbitrages institutionnels et compliquant la mise en œuvre des réformes de gouvernance spatiale.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - organisation_territoires
  - demographie_mobilite_humaine
  - gouvernance_institutions

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Collectifs de Résistance aux Relocalisations Forcées

## Rôle dans [[policy_reform]]
Dans le scénario policy_reform, ces collectifs constituent une force de résistance aux politiques de réaménagement territorial, pesant sur les arbitrages institutionnels et compliquant la mise en œuvre des réformes de gouvernance spatiale.

## Variables influencées
- [[organisation_territoires]]
- [[demographie_mobilite_humaine]]
- [[gouvernance_institutions]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
