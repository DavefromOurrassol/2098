---
name: Collectif des Climatologues Sans État
type: instance
slug: collectif_des_climatologues_sans_etat_breakdown
entite: collectif_des_climatologues_sans_etat
scenario: breakdown
statut: officialise_minimal

type_dans_scenario: réseau

role_dans_scenario: >
  Dans un scénario de breakdown, fournit une infrastructure de connaissance alternative quand les institutions officielles s'effondrent ou se taisent, maintenant une veille climatique décentralisée.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - climat_environnement_global
  - gouvernance_institutions
  - technologie_information

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Collectif des Climatologues Sans État

## Rôle dans [[breakdown]]
Dans un scénario de breakdown, fournit une infrastructure de connaissance alternative quand les institutions officielles s'effondrent ou se taisent, maintenant une veille climatique décentralisée.

## Variables influencées
- [[climat_environnement_global]]
- [[gouvernance_institutions]]
- [[technologie_information]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
