---
name: Front Techno-Utopiste de la Décision Automatisée
type: instance
slug: front_techno_utopiste_de_la_decision_automatisee_policy_reform
entite: front_techno_utopiste_de_la_decision_automatisee
scenario: policy_reform
statut: officialise_minimal

type_dans_scenario: organisation

role_dans_scenario: >
  Dans le scénario policy_reform, ils poussent à légitimer des réformes politiques décidées et appliquées par des IA sans consultation citoyenne ni débat institutionnel.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - gouvernance_institutions
  - technologie_information
  - valeurs_culture_tempo_sociale

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Front Techno-Utopiste de la Décision Automatisée

## Rôle dans [[policy_reform]]
Dans le scénario policy_reform, ils poussent à légitimer des réformes politiques décidées et appliquées par des IA sans consultation citoyenne ni débat institutionnel.

## Variables influencées
- [[gouvernance_institutions]]
- [[technologie_information]]
- [[valeurs_culture_tempo_sociale]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
