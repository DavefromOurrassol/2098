---
name: Collectifs de Défense Hydrique Sahéliens
type: instance
slug: collectifs_de_defense_hydrique_saheliens_policy_reform
entite: collectifs_de_defense_hydrique_saheliens
scenario: policy_reform
statut: officialise_minimal

type_dans_scenario: organisation

role_dans_scenario: >
  Acteurs de pression dans les processus de réforme des politiques hydriques, portant des revendications de souveraineté locale sur la gestion de l'eau face aux institutions nationales et internationales.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - energie_ressources_critiques
  - gouvernance_institutions
  - organisation_territoires

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Collectifs de Défense Hydrique Sahéliens

## Rôle dans [[policy_reform]]
Acteurs de pression dans les processus de réforme des politiques hydriques, portant des revendications de souveraineté locale sur la gestion de l'eau face aux institutions nationales et internationales.

## Variables influencées
- [[energie_ressources_critiques]]
- [[gouvernance_institutions]]
- [[organisation_territoires]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
