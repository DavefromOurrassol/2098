---
name: Réseau Logistique Criminel Concurrent
type: instance
slug: reseau_logistique_criminel_concurrent_breakdown
entite: reseau_logistique_criminel_concurrent
scenario: breakdown
statut: officialise_minimal

type_dans_scenario: réseau

role_dans_scenario: >
  Acteur hostile cherchant à éliminer ou intégrer de force les réseaux logistiques criminels rivaux dans un contexte de délitement institutionnel.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - organisation_territoires
  - geopolitique_conflits
  - frontieres_du_systeme

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Réseau Logistique Criminel Concurrent

## Rôle dans [[breakdown]]
Acteur hostile cherchant à éliminer ou intégrer de force les réseaux logistiques criminels rivaux dans un contexte de délitement institutionnel.

## Variables influencées
- [[organisation_territoires]]
- [[geopolitique_conflits]]
- [[frontieres_du_systeme]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
