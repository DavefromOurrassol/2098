---
name: Plateformes Centralisées de Narration Officielle
type: instance
slug: plateformes_centralisees_de_narration_officielle_reference
entite: plateformes_centralisees_de_narration_officielle
scenario: reference
statut: officialise_minimal

type_dans_scenario: infrastructure

role_dans_scenario: >
  Dans le scénario reference, elles constituent le cadre dominant contre lequel s'inscrit toute forme de journalisme alternatif ou indépendant.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - technologie_information
  - gouvernance_institutions
  - valeurs_culture_tempo_sociale

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Plateformes Centralisées de Narration Officielle

## Rôle dans [[reference]]
Dans le scénario reference, elles constituent le cadre dominant contre lequel s'inscrit toute forme de journalisme alternatif ou indépendant.

## Variables influencées
- [[technologie_information]]
- [[gouvernance_institutions]]
- [[valeurs_culture_tempo_sociale]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
