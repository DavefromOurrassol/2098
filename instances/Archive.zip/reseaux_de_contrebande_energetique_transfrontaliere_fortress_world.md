---
name: Réseaux de contrebande énergétique transfrontalière
type: instance
slug: reseaux_de_contrebande_energetique_transfrontaliere_fortress_world
entite: reseaux_de_contrebande_energetique_transfrontaliere
scenario: fortress_world
statut: officialise_minimal

type_dans_scenario: réseau

role_dans_scenario: >
  Fournissent un accès énergétique alternatif aux populations exclues des infrastructures légales, tout en fragilisant l'autorité des blocs souverains sur leurs ressources critiques.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - energie_ressources_critiques
  - frontieres_du_systeme
  - geopolitique_conflits

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Réseaux de contrebande énergétique transfrontalière

## Rôle dans [[fortress_world]]
Fournissent un accès énergétique alternatif aux populations exclues des infrastructures légales, tout en fragilisant l'autorité des blocs souverains sur leurs ressources critiques.

## Variables influencées
- [[energie_ressources_critiques]]
- [[frontieres_du_systeme]]
- [[geopolitique_conflits]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
