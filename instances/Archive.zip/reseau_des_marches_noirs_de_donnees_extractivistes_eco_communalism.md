---
name: Réseau des Marchés Noirs de Données Extractivistes
type: instance
slug: reseau_des_marches_noirs_de_donnees_extractivistes_eco_communalism
entite: reseau_des_marches_noirs_de_donnees_extractivistes
scenario: eco_communalism
statut: officialise_minimal

type_dans_scenario: réseau

role_dans_scenario: >
  Représente la pression extractiviste qui ronge les communautés de l'intérieur, en monétisant illicitement les données communes au profit d'intérêts extérieurs.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - technologie_information
  - frontieres_du_systeme
  - systeme_economique_redistribution

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Réseau des Marchés Noirs de Données Extractivistes

## Rôle dans [[eco_communalism]]
Représente la pression extractiviste qui ronge les communautés de l'intérieur, en monétisant illicitement les données communes au profit d'intérêts extérieurs.

## Variables influencées
- [[technologie_information]]
- [[frontieres_du_systeme]]
- [[systeme_economique_redistribution]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
