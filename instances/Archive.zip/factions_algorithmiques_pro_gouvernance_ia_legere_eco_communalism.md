---
name: Factions Algorithmiques Pro-Gouvernance IA Légère
type: instance
slug: factions_algorithmiques_pro_gouvernance_ia_legere_eco_communalism
entite: factions_algorithmiques_pro_gouvernance_ia_legere
scenario: eco_communalism
statut: officialise_minimal

type_dans_scenario: autre

role_dans_scenario: >
  Dans le scénario eco_communalism, ces factions exercent une pression idéologique sur les communautés locales pour automatiser certaines fonctions de gouvernance, créant une tension entre autonomie délibérative humaine et optimisation algorithmique.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - gouvernance_institutions
  - technologie_information
  - valeurs_culture_tempo_sociale

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Factions Algorithmiques Pro-Gouvernance IA Légère

## Rôle dans [[eco_communalism]]
Dans le scénario eco_communalism, ces factions exercent une pression idéologique sur les communautés locales pour automatiser certaines fonctions de gouvernance, créant une tension entre autonomie délibérative humaine et optimisation algorithmique.

## Variables influencées
- [[gouvernance_institutions]]
- [[technologie_information]]
- [[valeurs_culture_tempo_sociale]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
