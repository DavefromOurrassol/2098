---
name: Factions Internes Pro-Désaugmentation Totale
type: instance
slug: factions_internes_pro_desaugmentation_totale_policy_reform
entite: factions_internes_pro_desaugmentation_totale
scenario: policy_reform
statut: officialise_minimal

type_dans_scenario: organisation

role_dans_scenario: >
  Dans ce scénario de réforme des politiques, ces factions exercent une pression interne pour que la désaugmentation devienne une option réglementaire contraignante plutôt que facultative.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - sante_biotechnologies
  - valeurs_culture_tempo_sociale
  - gouvernance_institutions

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Factions Internes Pro-Désaugmentation Totale

## Rôle dans [[policy_reform]]
Dans ce scénario de réforme des politiques, ces factions exercent une pression interne pour que la désaugmentation devienne une option réglementaire contraignante plutôt que facultative.

## Variables influencées
- [[sante_biotechnologies]]
- [[valeurs_culture_tempo_sociale]]
- [[gouvernance_institutions]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
