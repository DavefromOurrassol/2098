---
name: Factions Technophiles de la Géo-Ingénierie Centralisée
type: instance
slug: factions_technophiles_de_la_geo_ingenierie_centralisee_eco_communalism
entite: factions_technophiles_de_la_geo_ingenierie_centralisee
scenario: eco_communalism
statut: officialise_minimal

type_dans_scenario: organisation

role_dans_scenario: >
  Dans le scénario eco_communalism, ils représentent la tension idéologique majeure face aux communautés autosuffisantes, en défendant des interventions technologiques centralisées sur le climat qui court-circuitent la souveraineté locale.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - climat_environnement_global
  - gouvernance_institutions
  - energie_ressources_critiques

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Factions Technophiles de la Géo-Ingénierie Centralisée

## Rôle dans [[eco_communalism]]
Dans le scénario eco_communalism, ils représentent la tension idéologique majeure face aux communautés autosuffisantes, en défendant des interventions technologiques centralisées sur le climat qui court-circuitent la souveraineté locale.

## Variables influencées
- [[climat_environnement_global]]
- [[gouvernance_institutions]]
- [[energie_ressources_critiques]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
