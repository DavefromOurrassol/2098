---
name: Mouvement pour la Souveraineté Territoriale Absolue
type: instance
slug: mouvement_pour_la_souverainete_territoriale_absolue_policy_reform
entite: mouvement_pour_la_souverainete_territoriale_absolue
scenario: policy_reform
statut: officialise_minimal

type_dans_scenario: organisation

role_dans_scenario: >
  Dans le scénario policy_reform, constitue une force de résistance aux réformes institutionnelles centralisées, mobilisant les communautés territoriales contre les transferts de souveraineté.

responsabilites: >
  (à développer en phase 2 — fiche créée par officialisation automatique)

impact_local: 1
impact_systemique_global: 1

variables_influencees:
  - organisation_territoires
  - gouvernance_institutions
  - frontieres_du_systeme

zone_geographique:
  - régionale

zone_systemique:
  - société

alliances: []

oppositions: []

type_relation_dominante: neutralité

annee_debut: 2026
annee_fin:

etat_temporel: actif
age_historique: émergent
generation: transition

injection:
  type: canonique
  annee_injection:
  contexte_injection:
  impact_sur_variables:
  propagation:
    via_matrice: false

description_journalistique: >
  (à développer en phase 2)

signes_distinctifs: >
  (à développer en phase 2)

tensions_narratives: >
  (à développer en phase 2)

date_creation: 2026-06-20
---

# Mouvement pour la Souveraineté Territoriale Absolue

## Rôle dans [[policy_reform]]
Dans le scénario policy_reform, constitue une force de résistance aux réformes institutionnelles centralisées, mobilisant les communautés territoriales contre les transferts de souveraineté.

## Variables influencées
- [[organisation_territoires]]
- [[gouvernance_institutions]]
- [[frontieres_du_systeme]]

## Notes
Fiche créée par officialisation automatique (officialize_alliances.py) à partir d'une mention en texte libre. À enrichir en phase 2.
